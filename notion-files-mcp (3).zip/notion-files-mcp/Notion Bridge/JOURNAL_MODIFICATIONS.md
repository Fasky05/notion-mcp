# Journal des modifications : notion-cli + bridge Notion MCP

Derniere mise a jour : 2026-10-11. Ce fichier sert de memoire a l'agent et a l'utilisateur.
Dossiers concernes : `notion-cli\` et `notion-mcp-tailscale\notion-mcp\notion-files-mcp (1)\Notion Bridge\`.

---
## 1. notion-cli

### Commandes du CLI
| Commande | Role |
|---|---|
| `/signup [N]` | Cree le compte Notion (parcours automatique). `N` = nombre de chats d'accueil a creer (defaut 1). Si l'adresse existe deja : connexion, suppression du compte, puis nouvelle inscription (refresh). |
| `/settings` | Etape reglages du compte (essai gratuit des connecteurs IA). |
| `/warp [on\|auto\|off\|status\|install]` | Gere WARP (voir section 3). |

### Fichiers `signup/`
`config.mjs` (valeurs par defaut), `browser.mjs` (navigateur Playwright + proxy), `ui.mjs` (helpers), `prompter.mjs` (questions CLI ou fichier `signup.answer`), `screens.mjs` (un handler par ecran Notion), `flow.mjs` (boucle de detection d'ecran), `index.mjs` (`runSignup`), `account.mjs`, `debug.mjs`, `refresh.mjs` (suppression de compte), `settings.mjs`, `warp.mjs`.

### Configuration `signup.config.json` (tout est optionnel)
`email`, `fullName`, `startUrl`, `headless`, `trace`, `allowDomainJoin`, `refreshExisting` (true), `welcomeChats` (1), `welcomeGapMs` (60), `warp` (`off`), `proxy` (`none`), `timeouts.total`, `questions`.

### Ce qui a ete fait / corrige
1. **Chats d'accueil multiples** : Notion cree un chat par clic sur le dernier "Skip for now" (ecran Desktop App). `desktopSkip` (screens.mjs) clique N fois (rafale toutes les `welcomeGapMs` ms). Pas teste de bout en bout avec N > 1.
2. **Refresh d'un compte existant** (`refresh.mjs`) : reglages (menu du workspace > Settings), bouton "Delete my account", saisie de l'email, confirmation, attente de la deconnexion, puis nouvelle inscription. **Verifie de bout en bout** sur `vincent.q8wa@fasky05.fr`. Bug corrige : le clic partait sur le bouton "Settings" d'une vue de base de donnees ; on cible maintenant le texte `Settings` dans `.notion-overlay-container`, apres attente de `.notion-sidebar-switcher`.
3. **Notion detecte le navigateur headless** : avec un vrai headless, `sendTemporaryPassword` renvoie 429 et l'inscription "Signup is not allowed", meme avec un autre domaine ou une autre IP. `browser.mjs` lance donc une vraie fenetre Edge placee hors ecran (`--window-position=-32000,-32000`, sans `--enable-automation`). La cle `headless: true` signifie maintenant "fenetre invisible hors ecran".
4. **Attente de la vraie reponse de Notion** (`submitEmail`) : Notion met 5 a 30 s a repondre. On attend la reponse reseau, puis l'apparition du champ du code ; 429 ou 400 declenchent une erreur claire (marquee `blocked`). Sinon l'adresse etait renvoyee (= nouveau code).
5. Ecran "Start from a blank page" : saute automatiquement.
6. Le log affiche l'IP sortante du navigateur et le proxy utilise.

### Limites constatees chez Notion
- La limite n'est pas liee a l'IP : meme avec l'IP Cloudflare (WARP) ou le VPN, le headless est refuse.
- Apres beaucoup de codes demandes pour une meme adresse, Notion repond 400 "Login is not allowed" (verifie pour `vincent.pro@fasky05.fr` et `vincent.ttr@fasky05.fr` le 2026-10-11, alors qu'une adresse neuve passait avec le meme navigateur). Duree inconnue. Utiliser une autre adresse ou attendre.
- `curl` seul (sans navigateur) recoit "Login is not allowed" pour toutes les adresses : ne pas s'en servir pour tester.

### Astuces pour tester (agent)
- `prompter.mjs` **supprime `signup.answer` au demarrage** : ecrire la reponse **apres** que l'invite est affichee (sinon la reponse est perdue, ou un code est pris pour l'adresse mail).
- Un harnais de test = script qui appelle `runSignup` avec un faux `rl` (`{ question: () => {} }`), `dir` dedie, reponses via `<dir>/signup.answer`. A supprimer ensuite.
- Ne pas tuer les processus avec un filtre sur `_rt` sans le limiter a `node.exe` (on tue sa propre commande PowerShell). Limiter a `Name='node.exe'`.
- Appels `run_shell` : au-dela de ~60 s le pont expire ("Request timed out") ; lancer en `Start-Process` et relire les sorties.
- PowerShell : `[IO.File]::WriteAllText` pour ecrire des fichiers ; les remplacements JS se font via un script `.cjs` temporaire et `String.replace` avec fonction.
- Sauvegardes : `cli.mjs.bak`, `cli.mjs.prewarp` (avant ajout de `/warp`), `session.json.bak`.

---
## 2. Bridge Notion MCP (dossier `Notion Bridge`)

### Probleme initial
Quand le VPN du PC (Proton VPN, gratuit : pas de split tunneling) est actif, la connexion Tailscale Funnel du bridge saute.

### Solution : tunnel Cloudflare au lieu de Tailscale
- Tunnel Cloudflare **`notion-mcp`** (existait deja, identifiant `c6e598fc-...`, identifiants dans `%USERPROFILE%\.cloudflared`).
- DNS ajoute : `notion-mcp.fasky05.fr` -> ce tunnel (`cloudflared tunnel route dns notion-mcp notion-mcp.fasky05.fr`).
- **URL a mettre dans Notion (Custom MCP) : `https://notion-mcp.fasky05.fr/mcp`** (jeton Bearer inchange, dans `config.json`, ne jamais l'afficher).
- Fichiers :
  - `run_cloudflare.py` (nouveau) : lance `cloudflared tunnel --no-autoupdate run --url http://127.0.0.1:8765 notion-mcp` et affiche l'URL.
  - `run_tunnel.py` (modifie) : en debut de `main()`, si `tunnel_provider.txt` contient `cloudflare`, appelle `run_cloudflare.main()` ; sinon comportement Tailscale d'origine.
  - `tunnel_provider.txt` (nouveau) : contient `cloudflare`. **Pour revenir a Tailscale : supprimer ce fichier.**
- `Start Notion Bridge.bat` / `start_all.bat` n'ont pas ete modifies : ils appellent `run_tunnel.py`, donc utilisent Cloudflare au prochain lancement. Un bridge deja lance reste tel quel jusqu'au redemarrage.
- Tailscale Funnel reste configure (`tailscale funnel reset` pour le couper).
- Les erreurs `stream N canceled by remote with error code 0` dans la fenetre cloudflared sont normales (Notion ferme lui-meme la requete).

---
## 3. WARP (Cloudflare) : IP differente pour le CLI uniquement

- Installe avec `winget install --id Cloudflare.Warp` (validation administrateur Windows). Configure en **mode proxy** : `socks5://127.0.0.1:40000` ; le reste du PC et le bridge ne sont pas touches.
- Commandes manuelles : `warp-cli --accept-tos mode proxy`, `warp-cli --accept-tos proxy port 40000`, `warp-cli --accept-tos connect | disconnect | status` (`C:\Program Files\Cloudflare\Cloudflare WARP\warp-cli.exe`).
- **Automatique, option `warp`** (cle de `signup.config.json`, reglable avec `/warp`) :
  - `off` (defaut) : jamais.
  - `auto` : si Notion bloque (429 / "Signup is not allowed"), `/signup` demarre WARP, supprime l'etat de reprise et **retente une fois** avec le proxy.
  - `on` : demarre WARP et l'utilise toujours.
  - `/warp status` affiche l'etat, `/warp install` installe WARP, `/warp off` le deconnecte.
- Code : `signup/warp.mjs` (`warpStatus`, `startWarp`, `stopWarp`, `installWarp`), branchement dans `signup/index.mjs` (`runSignup` -> `runOnce`).
- Cle `proxy` (autre mecanisme) : `none` (defaut), `auto` (utilise WARP s'il tourne deja), ou une URL `http://h:p` / `socks5://h:p`.
- Limite : le proxy WARP est parfois lent (chargement de page > 30 s constate) et ne contourne PAS la detection du navigateur headless ; il ne sert que si le blocage dependait de l'IP.
- Le VPN du telephone ne s'applique pas au PC via le partage de connexion iPhone.

---
### Retour a Tailscale (2026-10-21)
- Fichiers Cloudflare supprimes (`run_cloudflare.py`, `tunnel_provider.txt`) et override retiree de `run_tunnel.py` : le bridge utilise de nouveau `tailscale funnel 8765`.
- `config.json` : ajoute `"allow_full_shell": true` -> outil `run_shell` active (npm/npx/node/pip/python/git sans restriction, pipes, chaining). Les outils restreints `use_powershell`/`use_cmd` restent disponibles.

---
## 4. Etat actuel
- Tunnel : Tailscale Funnel (voir retour a Tailscale ci-dessus, 2026-10-21).
- Comptes : `vincent.q8wa@fasky05.fr` existe (onboarding fait) ; `vincent.pro` et `vincent.ttr` bloques cote Notion (voir section 1).
- Fichiers de test supprimes (`_rt.mjs`, `rt/`, `signup-debug/`).
- A refaire si besoin : test de `/signup N` avec N > 1 ; test de `/warp auto` en conditions reelles de blocage.