# MCP Router Notes

This is the source of truth for the local Notion MCP bridge and Roblox Studio controls. Read it before changing server routing or the shell policy.

## Keep the tool surface small

Do not add one Notion tool or shell command for every upstream MCP tool. The bridge exposes three stable generic tools for configured MCP servers:

- `mcp_servers`: show configured server IDs and whether their child process is running.
- `mcp_list_tools(server_id, offset=0, limit=20)`: ask one server for a page of tool names, descriptions, and argument schemas.
- `mcp_call(server_id, tool_name, arguments, timeout_seconds)`: call a discovered tool on that server.

For read-only MCP operations, the Notion agent lists servers, discovers the selected server's tools, then calls the chosen tool by its original name. For Roblox, use server ID `roblox`. `mcp_list_tools` returns a maximum of 20 schemas at a time; continue with `next_offset`. This keeps the generic catalogue small as MCP servers are added.

The HTTP bridge is stateless and returns standard Streamable HTTP JSON responses because its tools are synchronous. It logs only HTTP 429 and server-error responses, at most once per minute per route, without logging request bodies or credentials.

## Roblox Studio

New installs enable the official local `StudioMCP.exe` provider by default. The bridge discovers it in the installed Roblox version folders, or accepts an override through `ZS_STUDIO_MCP_PATH`. It speaks MCP JSON-RPC over stdio; Roblox Studio's own process connects to StudioMCP on loopback port 13469.

To use it, open a place in Roblox Studio and enable **Assistant Settings > MCP Servers > Enable Studio as MCP server**. The Notion connection exposes these Roblox-specific tools separately from the local Chrome website connector:

- `roblox_studio(action, arguments)`: project summary/tree/property/script inspection; build parts, instances, models, UI and VFX; modify, clone, delete and edit scripts; search scripts; inspect Output; take/list/restore snapshots.
- `roblox_native_tools(offset, limit)` and `roblox_native_call(tool_name, arguments, timeout_seconds)`: discover and call any other actual Roblox Studio MCP tool, such as play testing, asset generation/insertion, capture, navigation and Studio input.
- `roblox_execute_luau(code, datamodel_type, timeout_seconds, use_helpers, snapshot_paths)`: privileged Luau. The adapted `BW` helpers are prepended when code references `BW.*`; optional paths are snapshotted before execution.
- `roblox_workflow(category)`: Brickwire's general/build/scripting/UI/VFX/gameplay/debug playbooks.
- `roblox_project_memory(action, category, text, path)`: persistent, local per-place inventory, notes, changes, errors and snapshot references.

The action names and required arguments are visible in each tool description. Composite actions use safe Luau literals and resolve instance paths as segments instead of inserting user paths as executable code. If Studio advertises no tools yet, the bridge waits briefly and returns the setup instruction.

Calls to Roblox can change or execute Luau in the open place. The bridge serializes mutating Roblox calls through one Studio writer lock, so two changes cannot execute at the same time. Keep Notion **Always ask** enabled for `roblox_studio`, `roblox_native_call` and `roblox_execute_luau`. The direct agent has a separate page panel that asks for approval before each write; while its session owns the writer lock, Notion writes are rejected until that session stops. Direct sessions are likewise rejected while a Notion write is in progress. High-level writes and native writes with explicit paths are snapshotted in `ServerStorage.__BrickwireSnapshots`; raw Luau can only be snapshotted when the caller provides `snapshot_paths`. Raw Luau is privileged code, not a sandbox. `mcp_call` blocks Roblox native writes; use the Roblox wrappers so confirmation and snapshots apply. The Roblox native `http_get` and `store_image` tools remain hidden and blocked. Snapshots and local project memory are recovery aids, not guaranteed backups; save/publish the place normally.

## AI Chat Websites

The `websites` server is an in-process MCP client routed through the bundled Chrome extension. It uses the same generic `mcp_list_tools` and `mcp_call` interface; no shell command or separate Notion tool is added.

- `web_sites`: list DeepSeek, ChatGPT, Claude, Gemini, Qwen, Kimi, GLM, Arena and Notion AI with their support status.
- `web_agents(action="list")`: list only supported tabs the user explicitly enabled from the extension menu. Each result has an `agent_id` tied to one open tab.
- `web_agents(action="inspect", agent_id="...")`: inspect a specific enabled chat tab.
- `web_agents(action="run", agent_id="...", task="...")`: add the saved custom instructions, submit the task to that page's chat model, then wait for its visible response (up to 150 seconds).
- `web_agents(action="send"|"wait"|"read", agent_id="...")`: send a normal message, wait for generation, or read the last visible assistant response on that specific page.
- `web_chat`: compatibility tool for the current tab; the tab must also be explicitly enabled.

The extension popup's **Activer cet agent** button explicitly grants Notion access to that one supported tab; it also enables **Lancer directement**. Direct mode needs the local bridge token and Roblox Studio MCP active, but no Notion connection. It starts a structured Studio agent using that page's signed-in chat model; reads run automatically and every write requires approval in the page panel. Custom instructions are saved in the extension options and prepended to each task. The agent does not provide general autonomous browsing or arbitrary page controls. The extension does not forward website cookies or control non-listed pages. DeepSeek is beta; other providers are experimental, and Notion AI is disabled by default. Arena's Battle and side-by-side modes are blocked.

Only the Roblox MCP tools exposed by the local bridge can write to Studio. The one-shot `web_agents` task runner only asks for and reads a chat response; the separately launched direct mode can use Studio tools under the page's per-write approval panel. A shared writer lock rejects overlapping Notion and direct writes. Keep Notion's **Always ask** confirmations enabled. Both modes submit prompts to an external AI service using the user's existing browser session.

The full design reference supplied for the Roblox connection is `uploads/roblox_studio_mcp_contact_spec.md`.

## Add Another MCP

Add a trusted local MCP entry under `mcp_servers` in the local `config.json`, then restart the bridge. The built-in `websites` server is a special, in-process MCP client connected to the Chrome extension. Do not add new names to `command_tools.py` just to integrate another server.

Example for a trusted local stdio server:

```json
{
  "mcp_servers": {
    "roblox": {"type": "roblox_studio", "enabled": true},
    "websites": {"type": "browser_extension", "enabled": true},
    "project_docs": {
      "type": "stdio",
      "command": "C:\\Program Files\\Example MCP\\server.exe",
      "args": ["--stdio"],
      "cwd": ".",
      "enabled": true
    }
  }
}
```

Each ID uses letters, numbers, dots, underscores, or hyphens. `stdio` servers launch directly with an argument array and no shell; their working directory must stay inside the selected project folder. Installed executable paths may be absolute. Optional `env` entries are plain text in `config.json`, so do not put secrets there unless the file is protected. Only configure MCP servers you trust: their tools run with the Windows account's permissions.

The generic router lazily starts each configured child, performs the MCP `2024-11-05` initialize handshake, routes newline-delimited JSON-RPC by request ID, drains stderr, serializes calls per server, and closes child stdin gracefully when the bridge exits. It does not force-kill a child that remains open.

## Shell Policy Is Separate

Keep shell permissions small and purpose-specific. Current approved operations are recorded in the package README and tested in `test_command_tools.py`. In particular, shell access does not include `npx`, `curl`, PowerShell web requests, Git remotes (`clone`, `fetch`, `pull`, `push`, `remote`), deletion, `taskkill`, or generic command launchers. Git inspection and local history are restricted to `git -C rbx-proxy/mirror`.

Node/tsx and configured MCP servers are not OS-sandboxed. They can act with the Windows account's permissions; only configure trusted projects and servers, and leave Notion's confirmation prompts enabled.
