# Bridge MCP local pour les fichiers et Notion

Ce serveur donne a un **Notion Custom Agent** des outils de fichiers, de controle Roblox Studio et d'interaction avec plusieurs sites de chat IA via une extension Chrome locale.

## Avant de commencer

- Windows 10/11 et Python 3.11 ou plus recent (necessaire au bridge, pas expose comme commande shell).
- Google Chrome 116 ou plus recent pour l'extension de sites web.
- Notion Business ou Enterprise, avec la fonction Custom Agents et les serveurs MCP personnalises autorises par l'administrateur de l'espace.
- Le tunnel Cloudflare `notion-mcp` configure pour `notion-mcp.fasky05.fr`; Cloudflare Tunnel fournit le point d'entree public du Notion Custom Agent.
- L'agent doit etre un **Custom Agent**. Le chat Notion classique n'accepte pas directement un MCP local.

Notion documente les connexions MCP pour les Custom Agents et exige une URL de serveur MCP hebergee/publique. Cloudflare Tunnel fournit l'URL HTTPS publique vers le serveur qui tourne sur ton PC. Le tunnel expose le service a Internet; l'authentification Bearer reste obligatoire. La documentation precise que les MCP sont disponibles sur Business et Enterprise.

## Installation

1. Decompresse le ZIP tout-en-un sur ton ordinateur Windows. A la racine, tu trouveras un seul fichier a lancer et le dossier `Notion Bridge`.
2. Dans Chrome, ouvre `chrome://extensions`, active **Mode developpeur**, choisis **Charger l'extension non empaquetee** et selectionne le dossier `extension` decompresse.
3. Double-clique uniquement `Start Notion Bridge.bat` a la racine du ZIP extrait. Le lanceur verifie Python 3.11+, installe les composants necessaires et, au premier demarrage, demande quel dossier de projet partager. `cloudflared` et les identifiants du tunnel nomme `notion-mcp` doivent etre presents sur ce PC.
4. Le bridge demarre dans une fenetre minimisee. L'adresse MCP est `https://notion-mcp.fasky05.fr/mcp`.
5. Ouvre les options de l'extension et colle `web_extension_token` de `config.json`; laisse l'adresse locale par defaut. L'etat de l'extension doit indiquer **connected**.
6. Dans Notion, cree ou ouvre un Custom Agent. Dans **Settings → Tools & Access → Add connection → Custom MCP server**, configure:
   - URL: `https://notion-mcp.fasky05.fr/mcp`.
   - Authentification par en-tete: `Authorization` = `Bearer ` suivi du contenu de `config.json` sous `bearer_token`.
7. Ouvre un lieu dans Roblox Studio, puis active **Assistant Settings > MCP Servers > Enable Studio as MCP server**.
8. Connecte le serveur Notion. Laisse **Always ask / demander confirmation** pour `write_file`, `download_github_file`, `mcp_call`, `roblox_studio`, `roblox_native_call`, `roblox_execute_luau`, `use_powershell` et `use_cmd`.
9. Dans les instructions du Custom Agent, indique le nom de la connexion. Pour Roblox, commence par `roblox_studio(action="status", arguments={})`. Pour les sites, commence par `mcp_list_tools(server_id="websites")`.

Garde la fenetre minimisee du bridge et celle du tunnel ouvertes pendant l'utilisation. Le tunnel Cloudflare se reconnecte au meme hostname stable `notion-mcp.fasky05.fr`. Les scripts avances (`start_all.bat`, `start_bridge.bat`, `start_tunnel.bat`) restent dans le dossier `Notion Bridge`.

## Tunnel Cloudflare

Le lanceur utilise le tunnel nomme Cloudflare `notion-mcp` et le hostname public stable `notion-mcp.fasky05.fr`, avec `http://127.0.0.1:8765` comme origine. Il necessite `cloudflared` et son fichier de credentials dans `%USERPROFILE%\\.cloudflared`. Cloudflare Tunnel etablit une connexion sortante vers Cloudflare; il ne necessite ni port entrant ouvert ni Tailscale Funnel. Le service reste protege par `bearer_token`, et la fenetre du tunnel doit rester ouverte pendant l'utilisation. Si le fichier `tunnel_provider.txt` est absent ou ne contient pas `cloudflare`, le lanceur revient au mode Tailscale.

## Outils inclus

- `list_files`: liste le dossier choisi; option recursive disponible.
- `search_files`: recherche du texte dans les fichiers texte UTF-8.
- `read_file`: lit un fichier texte et renvoie son empreinte SHA-256.
- `write_file`: cree un fichier, ou remplace un fichier seulement si l'empreinte correspond encore a la version lue.
- `download_github_file`: telecharge un asset public ou une archive depuis GitHub; peut extraire une archive ZIP sure dans un nouveau dossier.
- `mcp_servers`: liste les connexions MCP locales configurees.
- `mcp_list_tools`: decouvre, par pages, les outils et schemas d'un serveur MCP (`roblox`, par exemple).
- `mcp_call`: appelle un outil decouvert sur un serveur configure. Pour Roblox, les outils d'ecriture restent limites aux outils specialises; pour les sites, utilise uniquement `websites` et garde la confirmation Notion active.
- Serveur MCP `websites`: `web_sites` liste les fournisseurs; `web_agents` liste et cible par `agent_id` les onglets que tu as activés depuis l'extension, et peut envoyer une tâche puis lire la réponse; `web_chat` reste disponible sur l'onglet actif activé.
- `roblox_studio`: inspection du projet, arbre des objets, proprietes, scripts, recherche, construction de parts/modeles/UI/VFX, edition, suppression, snapshots/restauration et erreurs Output.
- `roblox_native_tools` / `roblox_native_call`: decouverte et appel des outils natifs fournis par la version de Studio installee, par exemple playtest, capture d'ecran, navigation, saisie, generation ou insertion d'assets.
- `roblox_execute_luau`: execution Luau directe; charge la bibliotheque d'aides `BW` automatiquement lorsqu'elle est utilisee. Peut prendre un snapshot des chemins fournis.
- `roblox_workflow`: playbooks Roblox pour Build, Scripting, UI, VFX, Gameplay et Debug.
- `roblox_project_memory`: notes persistantes par lieu, inventaire des scripts/UI, changements, erreurs et snapshots.
- `use_powershell`: execute une seule commande PowerShell de la liste autorisee, depuis le dossier choisi.
- `use_cmd`: execute une seule commande CMD de la liste autorisee, depuis le dossier choisi.
- `run_shell`: disponible seulement si `config.json` contient `"allow_full_shell": true`. Execute n'importe quelle commande shell (npm, npx, node, pip, python, git, pipes, chaining) dans un sous-dossier du dossier choisi, avec un timeout plafonne a 1800 s. Ce n'est pas une sandbox: garde la confirmation Notion active.

Le bridge decouvre et lance `StudioMCP.exe` de Roblox Studio automatiquement. Les outils natifs sont ceux que Studio annonce reellement. Les outils Roblox `http_get` et `store_image` restent bloques. Les modifications via Roblox sont sauvegardees dans ServerStorage quand une cible explicite est disponible; pour le Luau libre, passe `snapshot_paths` si tu connais les objets a sauvegarder.

L'extension Chrome Web Chat ne controle que les domaines declares dans `extension/manifest.json`: DeepSeek, ChatGPT, Claude, Gemini, Qwen, Kimi, GLM (Z.ai), Arena et Notion AI. Depuis son menu, active chaque onglet separement; seuls ces onglets sont visibles par `web_agents`. Le bouton **Lancer directement** démarre un agent Roblox depuis le chat sélectionné, sans connexion Notion mais avec le bridge local et Roblox Studio activés. Il peut lire et modifier le lieu via les outils Studio; chaque écriture exige une approbation explicite dans le panneau de la page. Les instructions personnalisées des options sont ajoutées à la tâche. Ce n'est pas un agent de navigation général: aucun clic arbitraire, achat, suppression de conversation ni accès aux mots de passe n'est implémenté. Un verrou partagé garantit qu'un seul agent écrit dans Studio à la fois: les écritures Notion sont refusées pendant une session directe et les sessions directes sont refusées lorsqu'une écriture Notion est en cours. DeepSeek est classé beta; les autres adaptateurs sont expérimentaux. Arena est limité au mode Direct; Notion AI reste désactivé jusqu'à activation dans les options.

Les fichiers caches, dossiers de dependances/build, fichiers binaires et noms courants de secrets (`.env`, cles privees, fichiers credentials) sont exclus des outils de fichiers. Lecture plafonnee a 500 Ko par fichier; ecriture a 1 Mo. Il n'y a pas d'outil de suppression.

Les shells n'exposent aucune commande generique de telechargement/reseau (`curl`, commandes web PowerShell et Git distant sont bloquees). Pour GitHub, utilise `download_github_file`: il accepte uniquement HTTPS sur `github.com`, `codeload.github.com`, `api.github.com`, `gist.github.com` et les domaines `githubusercontent.com`, valide aussi chaque redirection, limite le fichier a 250 Mo et refuse d'ecraser un fichier. En extraction ZIP, il bloque les chemins qui sortent du dossier, les liens et fichiers speciaux; la limite extraite est de 512 Mo. Par exemple, une archive de depot comme `https://github.com/OWNER/REPO/archive/refs/heads/main.zip` peut etre extraite vers `rbx-proxy/mirror`; pour une release, donne le lien direct de l'asset `/releases/download/...`. Cela copie le contenu source, sans historique Git. Le code telecharge reste du code tiers: examine-le avant de l'executer.

Git est limite a `git -C rbx-proxy/mirror` et aux operations locales `init`, `add`, `commit`, `status`, `diff`, `log`, `show`, `restore`, `rev-parse` et `config user.name/user.email`. Les operations reseau Git (`clone`, `fetch`, `pull`, `push`, `remote`) sont bloquees. `restore` ne vise que des fichiers source Lua/Luau/JS/TS explicitement nommes. Les hooks Git et les diff externes sont desactives pour ces appels.

Node n'accepte que les points d'entree `rbx-proxy/node_modules/typescript/bin/tsc` et `rbx-proxy/node_modules/tsx/dist/cli.mjs`; `node -e` et les autres scripts sont bloques. `npm test` et `npm run` locaux restent disponibles, mais `npm install`, `npm ci`, `npm exec`, `npx` et les telechargements depuis le shell sont bloques. Les diagnostics sont limites aux filtres `StudioMCP.exe`/`RobloxStudioBeta.exe`, `netstat -ano` et `where`. Les executeurs facultatifs `bin/stylua`, `bin/selene`, `bin/luau-lsp` sont accessibles uniquement avec `--help`, `--version` ou sur des fichiers Lua/Luau; `bin/cbm` avec ces deux options ou un seul fichier existant du dossier choisi.

## Ajouter d'autres MCP plus tard

Le catalogue expose trois outils generiques pour les serveurs MCP configures, plus les outils specialises Roblox. `mcp_list_tools` renvoie au plus 20 schemas par page; utilise son `next_offset` pour continuer. Les sites passent par le serveur `websites` et l'extension; ne modifie pas les commandes shell pour les ajouter. Format, exemple et limites sont dans [`MCP_ROUTER.md`](MCP_ROUTER.md). Ne configure que des serveurs de confiance: ils s'executent avec les droits du compte Windows.

## Securite

- Le serveur ecoute uniquement sur `127.0.0.1`; Cloudflare Tunnel fournit l'acces HTTPS public. Chaque requete MCP reste protegee par `bearer_token`.
- Chaque requete MCP exige le jeton aleatoire de `config.json`. Ne partage jamais ce fichier ni le jeton.
- L'extension possede un jeton distinct `web_extension_token`. Garde-le prive: il autorise le relais aux pages de chat listees et les sessions directes qui peuvent modifier Roblox Studio. Il ne donne pas acces au dossier fichiers ni aux commandes shell.
- L'extension ne se connecte qu'au WebSocket local et n'expose pas les pages web a Funnel. N'active **Always ask** que si tu veux autoriser explicitement l'envoi de prompts a un site externe.
- N'active pas "Always allow permanently" pour l'ecriture. Garde la confirmation Notion.
- Garde aussi **Always ask** pour le telechargement GitHub, l'ecriture et les deux outils shell. `download_github_file` peut ajouter des fichiers choisis dans le dossier; Node/tsx et `npm run` executent le code du projet avec les droits de ta session Windows.
- Garde **Always ask** pour les appels Roblox declenches depuis Notion (`roblox_studio`, `roblox_native_call` et `roblox_execute_luau`). Le mode direct utilise aussi son propre panneau d'approbation avant chaque ecriture. Luau arbitraire n'est pas une sandbox; les snapshots n'incluent que les chemins fournis ou detectes.
- Git agit uniquement dans `rbx-proxy/mirror`; `add`, `commit` et `restore` modifient l'etat local de ce depot.
- Le dossier de travail n'est **pas une sandbox Windows**: Node/tsx ou un script du projet peut quand meme acceder aux fichiers et au reseau avec les droits de ta session. Les limites reduisent les commandes d'entree, mais ne remplacent pas une session Windows dediee. N'approuve que les actions et projets auxquels tu fais confiance.
- Garde le processus Cloudflare Tunnel actif pendant l'utilisation. Pour couper l'acces immediatement, arrete ce processus ou change le jeton dans `config.json`.
- Toute personne qui obtient a la fois l'adresse publique active et le `bearer_token` pourrait appeler les outils de fichiers et de commande pour ce dossier.

## Depannage

- Si Notion ne propose pas **Custom MCP server**, demande a l'administrateur d'activer les MCP personnalises et verifie le plan Business/Enterprise.
- Si aucun outil n'apparait, verifie que les fenetres tournent, que l'URL finit par `/mcp`, et que l'en-tete contient `Bearer ` avant le jeton.
- Si `mcp_call` indique que l'extension n'est pas connectee, ouvre ses options, recolle `web_extension_token` et verifie le port dans l'adresse WebSocket.
- Si Cloudflare ne se connecte pas, verifie que `cloudflared` est installe et que `%USERPROFILE%\\.cloudflared\\c6e598fc-5e18-43f3-8c74-27cdc02e4283.json` existe. L'URL a utiliser reste `https://notion-mcp.fasky05.fr/mcp`.
- Si `web_agents` ne voit aucun onglet, ouvre le chat fournisseur, puis active cet onglet dans le menu de l'extension. Si l'interface n'est pas detectee, connecte-toi et attends le chargement du compositeur; les sites experimentaux peuvent changer leur interface.
- Si tu as choisi un nouveau dossier, relance `setup_windows.bat`.

## Sources officielles consultees

- [Notion: MCP connections for Custom Agents](https://www.notion.com/help/mcp-connections-for-custom-agents)
- [Notion Developers: Get started with Notion MCP](https://developers.notion.com/guides/mcp/get-started-with-mcp)
- [Cloudflare Tunnel](https://developers.cloudflare.com/tunnel/get-started/)
- [Installer Tailscale](https://tailscale.com/download)

Le ZIP Brickwire fourni a servi de reference pour les outils Roblox, les fournisseurs web et les selecteurs d'interface. Les sites web sont pilotes par le serveur MCP `websites` et l'extension Chrome fournie; aucun site non liste dans l'extension n'est pris en charge.
