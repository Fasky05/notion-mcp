from __future__ import annotations

import asyncio
import hmac
import json
import queue
import secrets
import threading
from typing import Any, Callable


SITE_PROVIDERS = [
    {"id":"deepseek","name":"DeepSeek","hosts":["chat.deepseek.com"],"status":"beta","enabledByDefault":True,"maxMessageChars":60000},
    {"id":"chatgpt","name":"ChatGPT","hosts":["chatgpt.com","chat.openai.com"],"status":"experimental","enabledByDefault":True,"maxMessageChars":30000},
    {"id":"claude","name":"Claude","hosts":["claude.ai"],"status":"experimental","enabledByDefault":True,"maxMessageChars":40000},
    {"id":"gemini","name":"Gemini","hosts":["gemini.google.com"],"status":"experimental","enabledByDefault":True,"maxMessageChars":30000},
    {"id":"qwen","name":"Qwen","hosts":["chat.qwen.ai"],"status":"experimental","enabledByDefault":True,"maxMessageChars":30000},
    {"id":"kimi","name":"Kimi","hosts":["kimi.com","kimi.ai"],"status":"experimental","enabledByDefault":True,"maxMessageChars":30000},
    {"id":"glm","name":"GLM (Z.ai)","hosts":["chat.z.ai"],"status":"experimental","enabledByDefault":True,"maxMessageChars":30000},
    {"id":"arena","name":"Arena","hosts":["lmarena.ai","arena.ai"],"status":"experimental","enabledByDefault":True,"maxMessageChars":20000,"notes":"Direct mode only; Battle and side-by-side chats are unsupported."},
    {"id":"notion","name":"Notion AI","hosts":["notion.so","app.notion.com"],"status":"experimental","enabledByDefault":False,"maxMessageChars":12000,"notes":"Disabled by default; enable explicitly in the extension options."},
]


TOOL_DEFINITIONS = [
    {
        "name":"web_sites",
        "description":"List supported AI chat websites and their support status. Does not access the browser.",
        "inputSchema":{"type":"object","properties":{}},
    },
    {
        "name":"web_chat",
        "description":"Inspect, send a message to, wait for, or read the active supported website tab. The tab must be explicitly enabled as an agent in the extension. It uses only the recognized chat composer and Send control.",
        "inputSchema":{"type":"object","required":["action"],"properties":{
            "action":{"type":"string","enum":["inspect","send","wait","read"]},
            "text":{"type":"string","description":"Required for send; sent as a normal chat message."},
            "wait_seconds":{"type":"integer","minimum":1,"maximum":150,"description":"Maximum time for wait; defaults to 30 seconds."},
        }},
    },
    {
        "name":"web_agents",
        "description":"List and operate only AI chat tabs explicitly enabled with Activer cet agent in the browser extension. Each agent_id targets one specific open tab; run sends a task and waits for the page's AI response. Saved custom instructions are added to run tasks.",
        "inputSchema":{"type":"object","required":["action"],"properties":{
            "action":{"type":"string","enum":["list","inspect","run","send","wait","read"]},
            "agent_id":{"type":"string","description":"Required except for list; returned by the list action."},
            "task":{"type":"string","description":"Required for run; task to submit to this page's AI."},
            "text":{"type":"string","description":"Required for send; normal message sent to this page's AI."},
            "wait_seconds":{"type":"integer","minimum":1,"maximum":150,"description":"Maximum time to wait; defaults to 30 seconds."},
        }},
    },
]


class BrowserExtensionBroker:
    """Routes the websites MCP server to one authenticated local Chrome extension."""

    def __init__(self, token: str):
        self.token = token
        self._lock = threading.RLock()
        self._sender: Callable[[dict[str, Any]], None] | None = None
        self._connection_id: str | None = None
        self._pending: dict[str, queue.Queue[dict[str, Any]]] = {}

    @property
    def connected(self) -> bool:
        with self._lock:
            return self._sender is not None

    def attach(self, sender: Callable[[dict[str, Any]], None]) -> str:
        connection_id = secrets.token_hex(12)
        with self._lock:
            self._sender = sender
            self._connection_id = connection_id
        return connection_id

    def detach(self, connection_id: str) -> None:
        with self._lock:
            if self._connection_id == connection_id:
                self._sender = None
                self._connection_id = None
                pending = list(self._pending.values())
                self._pending.clear()
            else:
                pending = []
        for response in pending:
            try:
                response.put_nowait({"error":"Chrome extension disconnected."})
            except queue.Full:
                pass

    def respond(self, message: dict[str, Any]) -> None:
        request_id = message.get("id")
        if not isinstance(request_id, str):
            return
        with self._lock:
            response = self._pending.get(request_id)
        if response is not None:
            try:
                response.put_nowait(message.get("result") if isinstance(message.get("result"), dict) else {"error":"Invalid extension response."})
            except queue.Full:
                pass

    async def websocket(self, websocket) -> None:
        await websocket.accept()
        connection_id = None
        try:
            try:
                hello = await asyncio.wait_for(websocket.receive_json(), timeout=10)
            except (asyncio.TimeoutError, ValueError):
                await websocket.close(code=4401)
                return
            origin = websocket.headers.get("origin", "")
            if origin and not origin.startswith("chrome-extension://"):
                await websocket.close(code=4403)
                return
            if not isinstance(hello, dict) or hello.get("type") != "hello" or not isinstance(hello.get("token"), str) or not hmac.compare_digest(hello["token"], self.token):
                await websocket.close(code=4401)
                return

            loop = asyncio.get_running_loop()
            outgoing: asyncio.Queue[dict[str, Any]] = asyncio.Queue()

            def sender(payload: dict[str, Any]) -> None:
                loop.call_soon_threadsafe(outgoing.put_nowait, payload)

            connection_id = self.attach(sender)
            await websocket.send_json({"type":"ready","providers":[p["id"] for p in SITE_PROVIDERS]})

            async def send_requests() -> None:
                while True:
                    await websocket.send_json(await outgoing.get())

            async def read_responses() -> None:
                while True:
                    message = await websocket.receive_json()
                    if isinstance(message, dict) and message.get("type") == "response":
                        self.respond(message)

            tasks = [asyncio.create_task(send_requests()), asyncio.create_task(read_responses())]
            done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
            for task in pending:
                task.cancel()
            await asyncio.gather(*done, *pending, return_exceptions=True)
        except asyncio.CancelledError:
            pass
        except Exception:
            pass
        finally:
            if connection_id:
                self.detach(connection_id)

    def call(self, tool_name: str, arguments: dict[str, Any], timeout: int) -> dict[str, Any]:
        if tool_name == "web_sites":
            return {"providers": SITE_PROVIDERS, "extensionConnected": self.connected}
        if tool_name not in {"web_chat", "web_agents"}:
            raise ValueError(f"Unknown websites MCP tool '{tool_name}'")
        if not isinstance(arguments, dict):
            raise ValueError("arguments must be an object")
        action = arguments.get("action")
        allowed_actions = {"inspect", "send", "wait", "read"} if tool_name == "web_chat" else {"list", "inspect", "run", "send", "wait", "read"}
        if action not in allowed_actions:
            raise ValueError("unsupported action for " + tool_name)
        payload = dict(arguments)
        if tool_name == "web_agents" and action != "list":
            agent_id = payload.get("agent_id")
            if not isinstance(agent_id, str) or not agent_id.startswith("agent-"):
                raise ValueError("agent_id is required; call web_agents(action='list') first")
        if action in {"send", "run"}:
            text = payload.get("task") if action == "run" else payload.get("text")
            if not isinstance(text, str) or not text.strip():
                raise ValueError(f"{action} requires non-empty {'task' if action == 'run' else 'text'}")
            if len(text) > 60000:
                raise ValueError("text exceeds the 60,000-character limit")
        wait_seconds = payload.get("wait_seconds", 150 if action == "run" else 30)
        if not isinstance(wait_seconds, int) or not 1 <= wait_seconds <= 150:
            raise ValueError("wait_seconds must be between 1 and 150")

        response_queue: queue.Queue[dict[str, Any]] = queue.Queue(maxsize=1)
        request_id = secrets.token_hex(12)
        with self._lock:
            sender = self._sender
            if sender is None:
                raise RuntimeError("Chrome extension is not connected. Open its options, save the bridge token, then open a supported chat site.")
            self._pending[request_id] = response_queue
        try:
            sender({"type":"request","id":request_id,"tool":tool_name,"arguments":payload})
            try:
                wait_limit = wait_seconds + 5 if action in {"wait", "run"} else timeout
                result = response_queue.get(timeout=max(3, min(180, max(timeout, wait_limit))))
            except queue.Empty as exc:
                raise TimeoutError("Timed out waiting for the active chat tab. Check that Chrome is open and the extension is connected.") from exc
            if result.get("error"):
                raise RuntimeError(str(result["error"]))
            return result
        finally:
            with self._lock:
                self._pending.pop(request_id, None)


class BrowserExtensionMCPClient:
    def __init__(self, broker: BrowserExtensionBroker):
        self.broker = broker

    @property
    def running(self) -> bool:
        return self.broker.connected

    def list_tools(self, timeout: int = 15) -> list[dict[str, Any]]:
        return TOOL_DEFINITIONS

    def call_tool(self, name: str, arguments: dict[str, Any], timeout: int = 120) -> dict[str, Any]:
        result = self.broker.call(name, arguments, timeout)
        return {"content":[{"type":"text","text":json.dumps(result,ensure_ascii=False)}]}

    def close(self) -> None:
        return None
