from __future__ import annotations

import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path, PureWindowsPath


POWERSHELL_COMMANDS = {
    "get-childitem", "get-content", "select-string", "test-path", "get-command",
    "get-process", "get-filehash", "tasklist", "netstat", "where",
    "node", "npm", "git", "stylua.exe", "selene.exe", "luau-lsp.exe",
    "codebase-memory-mcp.exe", "ast-grep.exe",
}
CMD_COMMANDS = {
    "dir", "type", "findstr", "where", "where.exe", "tree", "mkdir",
    "tasklist", "netstat", "node", "npm", "git", "node.exe",
    "npm.cmd", "stylua.exe", "selene.exe", "luau-lsp.exe", "codebase-memory-mcp.exe", "ast-grep.exe",
}
POWERSHELL_META = set(";|&<>$`(){}\n\r\x00")
CMD_META = set("&|<>^%!()\n\r\x00")
SENSITIVE_PATH = re.compile(
    r"(?i)(?:\.env(?:\.[a-z0-9_-]+)?|id_rsa|id_ed25519|credentials(?:\.json)?|secrets?\.json|\.(?:pem|key|p12|pfx|kdbx))"
)
MAX_COMMAND_LENGTH = 4000
MAX_OUTPUT_LENGTH = 12000
# Approved project folders (casefolded). rbx-proxy is the old name of SecretScript_Main.
PROJECT_DIRS = {"rbx-proxy", "secretscript_main"}
NODE_ENTRYPOINTS = {
    f"{d}/node_modules/{entry}"
    for d in PROJECT_DIRS
    for entry in ("typescript/bin/tsc", "tsx/dist/cli.mjs")
}
MIRROR_DIRS = {f"{d}/mirror" for d in PROJECT_DIRS}
LOCAL_TOOLS = {
    "bin/stylua/stylua.exe": "stylua.exe",
    "bin/selene/selene.exe": "selene.exe",
    "bin/luau-lsp/luau-lsp.exe": "luau-lsp.exe",
    "bin/cbm/codebase-memory-mcp.exe": "codebase-memory-mcp.exe",
    "bin/ast-grep/ast-grep.exe": "ast-grep.exe",
}


def _tokens(command: str) -> list[str]:
    return [part.strip("\"'") for part in re.findall(r'"[^"\n]*"|\'[^\'\n]*\'|\S+', command)]


def validate_command(shell: str, command: str) -> tuple[str, str]:
    """Validate a single, allow-listed command with no shell composition."""
    shell = shell.lower().strip()
    command = str(command or "").strip()
    if shell not in ("powershell", "cmd"):
        raise ValueError("Shell must be powershell or cmd")
    if not command or len(command) > MAX_COMMAND_LENGTH:
        raise ValueError("Provide one command of at most 4000 characters")
    forbidden = POWERSHELL_META if shell == "powershell" else CMD_META
    if any(char in forbidden for char in command):
        raise ValueError("Pipes, command chaining, redirection, scripts, and shell expansion are disabled")
    if ".." in command or re.search(r"(?i)(?:^|[\s=\"'])(?:[a-z]:|\\\\|\\(?!\\)|~[\\/])", command):
        raise ValueError("Use paths relative to the selected project folder; parent and absolute paths are blocked")
    if SENSITIVE_PATH.search(command):
        raise ValueError("Commands that name common credential or secret files are blocked")

    parts = _tokens(command)
    if not parts:
        raise ValueError("Command is empty")
    original_executable = parts[0].lower().replace("/", "\\")
    local_executable = original_executable.removeprefix(".\\")
    local_key = local_executable.replace("\\", "/").casefold()
    local_tool = LOCAL_TOOLS.get(local_key)
    if local_tool:
        executable = local_tool
    elif local_executable.startswith(".notion-agent-tools\\"):
        local_name = local_executable.rsplit("\\", 1)[-1]
        if local_name != "node.exe":
            raise ValueError("Only the approved Node.js runtime may run from .notion-agent-tools")
        executable = "node"
    else:
        executable = {
            "node.exe": "node", "npm.cmd": "npm", "tasklist.exe": "tasklist",
            "netstat.exe": "netstat", "where.exe": "where",
        }.get(original_executable, original_executable)
    if executable in LOCAL_TOOLS.values() and not local_tool:
        raise ValueError("These analyzers are allowed only from their exact bin folder")
    if shell == "powershell" and original_executable == "where":
        raise ValueError("Use where.exe explicitly in PowerShell")

    slash_flags = {
        "tasklist": {"/fi"},
        "where": {"/f", "/q", "/t", "/r", "/?"},
    }.get(executable, set())
    if any(part.startswith("/") and part.lower() not in slash_flags for part in parts[1:]):
        raise ValueError("Rooted paths are blocked; use paths relative to the selected project folder")
    allowed = POWERSHELL_COMMANDS if shell == "powershell" else CMD_COMMANDS
    if executable not in allowed:
        raise ValueError(f"'{parts[0]}' is not an allowed {shell} command")

    raw_args = parts[1:]
    args = [part.lower() for part in raw_args]
    if executable == "node":
        if not raw_args or raw_args[0].replace("\\", "/").casefold() not in NODE_ENTRYPOINTS:
            raise ValueError("Node is limited to the approved TypeScript and tsx entry points under SecretScript_Main (or rbx-proxy)")
    if executable in {"tasklist"}:
        if len(raw_args) != 2 or args[0] != "/fi" or args[1] not in {
            "imagename eq studiomcp.exe", "imagename eq robloxstudiobeta.exe",
        }:
            raise ValueError("tasklist is limited to the StudioMCP.exe and RobloxStudioBeta.exe image filters")
    if executable == "netstat" and args != ["-ano"]:
        raise ValueError("netstat is limited to -ano")
    if executable == "npm":
        npm_args = [arg.lower() for arg in raw_args]
        if any(arg.split("=", 1)[0] in {"install", "ci", "exec", "view", "init", "pack"} for arg in npm_args):
            raise ValueError("npm install, ci, and network-capable operations must be run manually")
        if npm_args[:1] == ["--prefix"]:
            if len(npm_args) < 3 or npm_args[1].replace("\\", "/").strip("./") not in PROJECT_DIRS:
                raise ValueError("npm --prefix is limited to SecretScript_Main (or rbx-proxy)")
            npm_args = npm_args[2:]
        if not npm_args or npm_args[0] not in {"test", "run", "list", "ls", "root", "--version", "-v", "--help"}:
            raise ValueError("npm is limited to local tests, scripts, listing, and help")
    if local_tool:
        if args in [["--version"], ["--help"]]:
            pass
        elif local_tool in {"stylua.exe", "selene.exe"}:
            if not raw_args or any(arg.startswith("-") or PureWindowsPath(arg).suffix.lower() not in {".lua", ".luau"} for arg in raw_args):
                raise ValueError("Stylua and Selene accept only explicit Luau/Lua file paths")
        elif local_tool == "luau-lsp.exe":
            if len(raw_args) < 2 or args[0] != "analyze" or any(PureWindowsPath(arg).suffix.lower() not in {".lua", ".luau"} for arg in raw_args[1:]):
                raise ValueError("luau-lsp is limited to analyze on explicit Luau/Lua file paths")
        elif local_tool == "ast-grep.exe":
            _validate_ast_grep(raw_args)
        else:
            if len(raw_args) != 1 or raw_args[0].startswith("-") or not PureWindowsPath(raw_args[0]).suffix:
                raise ValueError("codebase-memory-mcp accepts only --version, --help, or one file path")
    if executable == "git":
        _validate_git_command(raw_args)
    return shell, command


def _validate_ast_grep(raw_args: list[str]) -> None:
    value_flags = {"--pattern", "-p", "--lang", "-l", "--rule"}
    bool_flags = {"--json"}
    sub = raw_args[0].lower() if raw_args else ""
    if sub not in {"run", "scan"}:
        raise ValueError("ast-grep is limited to --version, --help, run, or scan")
    rest = raw_args[1:]
    seen: set[str] = set()
    paths: list[str] = []
    i = 0
    while i < len(rest):
        arg = rest[i].lower()
        if arg in value_flags:
            if i + 1 >= len(rest):
                raise ValueError(f"ast-grep {arg} needs a value")
            seen.add(arg)
            i += 2
        elif arg in bool_flags:
            i += 1
        elif arg.startswith("-"):
            raise ValueError("ast-grep option is not allowed (rewrite, update-all, interactive and stdin are blocked)")
        else:
            paths.append(rest[i])
            i += 1
    if len(paths) > 1:
        raise ValueError("ast-grep accepts at most one relative path")
    if sub == "run" and not seen & {"--pattern", "-p"}:
        raise ValueError("ast-grep run requires --pattern")
    if sub == "scan" and "--rule" not in seen:
        raise ValueError("ast-grep scan requires --rule <file>")


def _validate_git_command(raw_args: list[str]) -> None:
    if len(raw_args) < 3 or raw_args[0].lower() != "-c" or raw_args[1].replace("\\", "/").casefold().strip("/") not in MIRROR_DIRS:
        raise ValueError("Git is limited to -C SecretScript_Main/mirror (or rbx-proxy/mirror)")
    operation = raw_args[2].lower()
    args = [arg.lower() for arg in raw_args[3:]]
    if operation == "init":
        valid = not args
    elif operation == "add":
        valid = bool(args) and all(
            arg in {".", "-a", "-A", "--all"}
            or (not arg.startswith("-") and not any(c in arg for c in "*?[]:"))
            for arg in args
        )
    elif operation == "commit":
        valid = len(args) == 2 and args[0] in {"-m", "--message"}
    elif operation in {"status", "diff", "log", "show", "rev-parse"}:
        flags = {
            "status": {"--short", "--branch", "--porcelain"},
            "diff": {"--cached", "--stat", "--check", "--name-only", "--name-status"},
            "log": {"--oneline", "--decorate", "--max-count=10", "-n", "10"},
            "show": {"--stat", "--oneline", "head", "head~1"},
            "rev-parse": {"--show-toplevel", "--is-inside-work-tree", "--verify", "head"},
        }[operation]
        valid = all(arg in flags for arg in args)
    elif operation == "restore":
        suffixes = {".js", ".jsx", ".mjs", ".cjs", ".ts", ".tsx", ".lua", ".luau"}
        valid = len(raw_args) >= 5 and args[0] == "--" and all(
            PureWindowsPath(path).suffix.lower() in suffixes and not any(c in path for c in "*?[]:")
            for path in raw_args[4:]
        )
    elif operation == "config":
        config_args = args[1:] if args[:1] == ["--local"] else args
        valid = len(config_args) in {1, 2} and config_args[0] in {"user.name", "user.email"} and all(
            not arg.startswith("-") for arg in config_args[1:]
        )
    else:
        valid = False
    if not valid:
        raise ValueError("Git operation or arguments are outside the approved local-only policy")


def _trim_output(value: str) -> str:
    if len(value) <= MAX_OUTPUT_LENGTH:
        return value
    keep = MAX_OUTPUT_LENGTH // 2
    omitted = len(value) - MAX_OUTPUT_LENGTH
    return value[:keep] + f"\n...[{omitted} characters omitted]...\n" + value[-keep:]


def run_command(root: str | Path, shell: str, command: str, timeout_seconds: int = 60) -> str:
    shell, command = validate_command(shell, command)
    if os.name != "nt":
        raise RuntimeError("PowerShell and CMD tools are available only on Windows")
    root = Path(root).resolve(strict=True)
    command_parts = _tokens(command)
    if command_parts[0].lower() in {"npm", "npm.cmd"}:
        for index, part in enumerate(command_parts[1:], start=1):
            if part.lower() == "--prefix" and index + 1 < len(command_parts):
                prefix = command_parts[index + 1]
            elif part.lower().startswith("--prefix="):
                prefix = part.split("=", 1)[1]
            else:
                continue
            prefix_path = (root / prefix.replace("\\", os.sep).replace("/", os.sep)).resolve()
            if not prefix_path.is_relative_to(root):
                raise ValueError("npm --prefix must stay inside the selected project folder")
    local_executable = command_parts[0].replace("/", "\\").casefold()
    if local_executable.startswith(".\\.notion-agent-tools\\") or local_executable.removeprefix(".\\").replace("\\", "/") in LOCAL_TOOLS:
        executable_path = (root / local_executable.replace("\\", os.sep)).resolve(strict=True)
        if not executable_path.is_relative_to(root) or not executable_path.is_file():
            raise ValueError("The local executable must exist inside the selected project folder")
    if command_parts[0].replace("/", "\\").removeprefix(".\\").replace("\\", "/").casefold() in LOCAL_TOOLS:
        tool = LOCAL_TOOLS[command_parts[0].replace("/", "\\").removeprefix(".\\").replace("\\", "/").casefold()]
        tool_args = command_parts[1:]
        if tool == "luau-lsp.exe":
            tool_args = tool_args[1:]
        if tool != "ast-grep.exe" and tool_args not in (["--version"], ["--help"]):
            for relative_path in tool_args:
                source = (root / relative_path.replace("\\", os.sep).replace("/", os.sep)).resolve(strict=True)
                if not source.is_relative_to(root) or not source.is_file():
                    raise ValueError("Analyzer inputs must be existing files inside the selected project folder")
    if command_parts[0].lower() == "git":
        project_dir = command_parts[2].replace("\\", "/").strip("/").split("/")[0]
        for path in (root / project_dir, root / project_dir / "mirror"):
            if path.is_symlink() or not path.resolve().is_relative_to(root):
                raise ValueError("Git cannot follow links outside the project mirror folder")
        operation = command_parts[3].lower()
        if operation in {"diff", "show"}:
            command += " --no-ext-diff --no-textconv"
    timeout = max(5, min(int(timeout_seconds), 180))
    if shell == "powershell":
        executable = shutil.which("powershell.exe") or shutil.which("pwsh.exe")
        if not executable:
            raise RuntimeError("PowerShell was not found on this computer")
        argv = [executable, "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", command]
    else:
        executable = shutil.which("cmd.exe")
        if not executable:
            raise RuntimeError("CMD was not found on this computer")
        argv = [executable, "/d", "/s", "/c", command]

    env = dict(os.environ)
    env["npm_config_global"] = "false"
    env["npm_config_cache"] = str(root / ".notion-agent-npm-cache")
    env["GIT_CONFIG_NOSYSTEM"] = "1"
    env["GIT_CONFIG_GLOBAL"] = os.devnull
    env["GIT_CONFIG_COUNT"] = "2"
    env["GIT_CONFIG_KEY_0"] = "core.hooksPath"
    env["GIT_CONFIG_VALUE_0"] = os.devnull
    env["GIT_CONFIG_KEY_1"] = "diff.external"
    env["GIT_CONFIG_VALUE_1"] = ""
    env["GIT_PAGER"] = ""
    env["PAGER"] = ""
    env["GIT_TERMINAL_PROMPT"] = "0"
    env.pop("NODE_OPTIONS", None)

    with tempfile.TemporaryFile() as stdout_file, tempfile.TemporaryFile() as stderr_file:
        process = subprocess.Popen(
            argv,
            cwd=str(root),
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=stdout_file,
            stderr=stderr_file,
            creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
        )
        timed_out = False
        try:
            process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(process.pid)],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=10,
                check=False,
            )
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        stdout_file.seek(0)
        stderr_file.seek(0)
        stdout = stdout_file.read().decode("utf-8", errors="replace")
        stderr = stderr_file.read().decode("utf-8", errors="replace")

    status = "timed out" if timed_out else f"exit code {process.returncode}"
    result = [f"Working directory: selected project folder", f"Command status: {status}"]
    if stdout.strip():
        result.extend(["stdout:", _trim_output(stdout)])
    if stderr.strip():
        result.extend(["stderr:", _trim_output(stderr)])
    if not stdout.strip() and not stderr.strip():
        result.append("(no output)")
    return "\n".join(result)
