from __future__ import annotations

import json
import re
import secrets
import threading
import time
from contextlib import contextmanager
from typing import Any, Iterator

from roblox_features import GUARDED_ROBLOX_TOOLS, RobloxStudioTools


STUDIO_ACTIONS = [
    "status", "project_info", "get_game_tree", "read_instance", "create_instance", "create_part",
    "create_instance_tree", "create_model", "create_ui", "create_vfx", "modify_instance",
    "delete_instance", "clone_instance", "create_script", "read_script", "set_script_source",
    "patch_script", "search_scripts", "delete_script", "take_snapshot", "list_snapshots",
    "restore_snapshot", "get_errors",
]
STUDIO_READS = {"status", "project_info", "get_game_tree", "read_instance", "read_script", "search_scripts", "list_snapshots", "get_errors"}
STUDIO_WRITES = set(STUDIO_ACTIONS) - STUDIO_READS
SESSION_TTL_SECONDS = 300
MAX_TOOL_CALLS = 50


class StudioWriterCoordinator:
    """Serializes Studio writes and reserves the writer for a direct-agent session when active."""

    def __init__(self):
        self._lock = threading.RLock()
        self._owner: str | None = None

    def claim(self, owner: str) -> None:
        with self._lock:
            if self._owner and self._owner != owner:
                raise RuntimeError("Roblox Studio is reserved by another agent. Stop it before starting this one.")
            self._owner = owner

    def release(self, owner: str) -> None:
        with self._lock:
            if self._owner == owner:
                self._owner = None

    @contextmanager
    def notion_write(self) -> Iterator[None]:
        with self._lock:
            if self._owner:
                raise RuntimeError("Roblox Studio is reserved by a direct agent. Stop that agent before asking Notion to make changes.")
            yield

    @contextmanager
    def direct_call(self, owner: str) -> Iterator[None]:
        with self._lock:
            if self._owner != owner:
                raise RuntimeError("This direct-agent session no longer owns the Roblox Studio writer lock.")
            yield


class DirectAgentService:
    """Small, approval-gated tool surface for the standalone browser agent."""

    def __init__(self, roblox: RobloxStudioTools, writer: StudioWriterCoordinator):
        self.roblox = roblox
        self.writer = writer
        self._lock = threading.RLock()
        self._session: dict[str, Any] | None = None

    def start(self, agent_id: str, provider: str, task: str) -> dict[str, Any]:
        if not isinstance(agent_id, str) or not re.fullmatch(r"agent-[0-9]+", agent_id):
            raise ValueError("A registered page agent is required")
        if provider not in {"deepseek", "chatgpt", "claude", "gemini", "qwen", "kimi", "glm", "arena", "notion"}:
            raise ValueError("Unsupported AI provider")
        if not isinstance(task, str) or not task.strip() or len(task) > 8000:
            raise ValueError("Task must contain 1-8,000 characters")
        self._expire()
        session_id = "direct_" + secrets.token_urlsafe(18)
        with self._lock:
            if self._session:
                raise RuntimeError("Another direct agent is already using Roblox Studio. Stop it first.")
            self.writer.claim(session_id)
            try:
                tools = json.loads(self.roblox.native_tools(0, 50)).get("tools", [])
            except Exception:
                self.writer.release(session_id)
                raise
            if not tools:
                self.writer.release(session_id)
                raise RuntimeError("Roblox Studio is not ready or has not advertised any MCP tools.")
            self._session = {
                "id": session_id, "agent_id": agent_id, "provider": provider,
                "task": task.strip(), "started": time.time(), "last_activity": time.time(), "tool_calls": 0,
                "native_names": {tool.get("name") for tool in tools if isinstance(tool, dict)},
            }
        return {
            "session_id": session_id,
            "provider": provider,
            "task": task.strip(),
            "studio_actions": STUDIO_ACTIONS,
            "native_tools": [
                {
                    "name": tool.get("name"),
                    "description": str(tool.get("description", ""))[:240],
                    "inputSchema": tool.get("inputSchema", {}),
                    "risk": "write" if GUARDED_ROBLOX_TOOLS.search(str(tool.get("name", ""))) else "read",
                }
                for tool in tools if isinstance(tool, dict)
            ],
            "max_tool_calls": MAX_TOOL_CALLS,
            "approval_policy": "Every mutating call requires a fresh explicit approval in the page panel.",
        }

    def heartbeat(self, session_id: str, agent_id: str) -> dict[str, bool]:
        session = self._get(session_id, agent_id)
        session["last_activity"] = time.time()
        return {"ok": True}

    def stop(self, session_id: str, agent_id: str) -> dict[str, bool]:
        with self._lock:
            if not self._session or self._session["id"] != session_id or self._session["agent_id"] != agent_id:
                return {"ok": True}
            self._session = None
            self.writer.release(session_id)
        return {"ok": True}

    def call(self, session_id: str, agent_id: str, tool: str, arguments: dict[str, Any], approved: bool = False) -> dict[str, Any]:
        session = self._get(session_id, agent_id)
        if not isinstance(arguments, dict):
            raise ValueError("Tool arguments must be an object")
        if session["tool_calls"] >= MAX_TOOL_CALLS:
            raise RuntimeError("This direct-agent session reached its 50-call limit. Stop and start a new task if needed.")

        risk, target = self._risk(tool, arguments, session)
        if risk != "read" and not approved:
            raise PermissionError("This change requires a fresh approval in the browser panel.")
        session["last_activity"] = time.time()
        session["tool_calls"] += 1
        with self.writer.direct_call(session_id):
            if tool == "roblox_studio":
                action = arguments.get("action")
                nested = arguments.get("arguments", {})
                if action not in STUDIO_ACTIONS or not isinstance(nested, dict):
                    raise ValueError("roblox_studio needs a supported action and an arguments object")
                result = self.roblox.run_action(action, nested, 60)
                if action in STUDIO_WRITES:
                    self._record(action, nested, result)
                return {"tool":tool,"action":action,"risk":risk,"result":result}
            if tool == "roblox_execute_luau":
                code = arguments.get("code")
                paths = arguments.get("snapshot_paths", [])
                if not isinstance(code, str) or len(code) > 30000:
                    raise ValueError("Luau code must be text no longer than 30,000 characters")
                if not isinstance(paths, list) or len(paths) > 50:
                    raise ValueError("snapshot_paths must be a list of at most 50 paths")
                result = self.roblox.execute_luau(code, "Edit", 60, True, paths)
                self.roblox.record_event("change", "execute_luau", {"path":",".join(map(str, paths))}, "Direct agent executed Luau; source omitted from local memory")
                return {"tool":tool,"risk":risk,"result":result}
            if tool == "roblox_native_call":
                name = arguments.get("tool_name")
                native_args = arguments.get("arguments", {})
                if name not in session["native_names"] or not isinstance(native_args, dict):
                    raise ValueError("Native tool is unavailable or its arguments are invalid")
                result = self.roblox.native_call(name, native_args, 60)
                if risk != "read":
                    self._record(name, native_args, result)
                return {"tool":tool,"native_tool":name,"risk":risk,"result":result}
        raise ValueError("Unknown direct-agent tool")

    def _get(self, session_id: str, agent_id: str) -> dict[str, Any]:
        self._expire()
        with self._lock:
            session = self._session
            if not session or session["id"] != session_id or session["agent_id"] != agent_id:
                raise RuntimeError("Direct-agent session expired or belongs to a different page")
            return session

    def _expire(self) -> None:
        with self._lock:
            if self._session and time.time() - self._session["last_activity"] > SESSION_TTL_SECONDS:
                owner = self._session["id"]
                self._session = None
                self.writer.release(owner)

    @staticmethod
    def _risk(tool: str, arguments: dict[str, Any], session: dict[str, Any]) -> tuple[str, str]:
        if tool == "roblox_studio":
            action = arguments.get("action")
            if action not in STUDIO_ACTIONS:
                raise ValueError("Unsupported roblox_studio action")
            nested = arguments.get("arguments", {})
            if not isinstance(nested, dict):
                raise ValueError("roblox_studio arguments must be an object")
            return ("read" if action in STUDIO_READS else "write", str(nested.get("path", "")))
        if tool == "roblox_execute_luau":
            return "destructive", "Luau execution"
        if tool == "roblox_native_call":
            name = arguments.get("tool_name")
            if not isinstance(name, str) or name not in session["native_names"]:
                raise ValueError("Native tool is unavailable")
            return ("write" if GUARDED_ROBLOX_TOOLS.search(name) else "read", name)
        raise ValueError("Only Roblox Studio tools are available to the direct agent")

    def _record(self, action: str, arguments: dict[str, Any], result: str) -> None:
        try:
            snapshot_id = json.loads(result).get("snapshotId")
        except (json.JSONDecodeError, AttributeError):
            snapshot_id = None
        self.roblox.record_event("change", action, arguments, snapshot_id=snapshot_id)
