# Extension Chrome Web Chat MCP

Cette extension relie le serveur MCP local a des onglets Chrome ouverts sur des fournisseurs pris en charge. Elle ne navigue pas et ne clique pas sur des commandes arbitraires.

## Installation

1. Utilise Chrome 116 ou plus recent.
2. Depuis le ZIP tout-en-un extrait, ouvre `chrome://extensions`, active **Mode developpeur**, puis clique **Charger l'extension non empaquetee**.
3. Selectionne `Notion Bridge/extension`.
4. Lance **Start Notion Bridge.bat** a la racine du ZIP, puis ouvre les options de l'extension et colle `web_extension_token` depuis `Notion Bridge/config.json`.
5. Confirme l'etat **connected** dans le menu de l'extension. Garde Chrome, le bridge et le tunnel ouverts pour Notion.

## Activer un agent par onglet

Ouvre un chat IA pris en charge, connecte-toi, puis ouvre le menu de l'extension et choisis **Activer cet agent**. Seuls les onglets que tu actives ainsi sont visibles dans Notion. L'identifiant obtenu reste lie a cet onglet; ferme-le ou desactive l'agent pour retirer l'acces.

Le bouton **Lancer directement** démarre un agent Roblox depuis le chat de l'onglet activé. Il nécessite le bridge local, Roblox Studio ouvert avec le serveur MCP activé et le `web_extension_token`, mais aucune connexion Notion. L'agent peut lire le lieu puis propose ses modifications dans un panneau sur la page; chaque écriture exige une approbation explicite. Un seul agent peut écrire dans Studio à la fois: les écritures Notion sont refusées pendant la session directe, et les sessions directes sont refusées lorsqu'une écriture Notion est en cours. Le bouton Stop libère le verrou. Des instructions personnalisées sont ajoutées à la tâche. Le navigateur n'est pas piloté librement.

## Utilisation depuis Notion

Decouvre les outils du serveur `websites` avec `mcp_list_tools`.

- `mcp_call(server_id="websites", tool_name="web_agents", arguments={"action":"list"})` liste les onglets explicitement actives et leurs `agent_id`.
- `mcp_call(server_id="websites", tool_name="web_agents", arguments={"action":"inspect","agent_id":"agent-123"})` inspecte l'onglet correspondant.
- `mcp_call(server_id="websites", tool_name="web_agents", arguments={"action":"run","agent_id":"agent-123","task":"Compare ces options et cite les incertitudes."})` envoie une tache puis attend la reponse.
- `mcp_call(server_id="websites", tool_name="web_agents", arguments={"action":"read","agent_id":"agent-123"})` lit la reponse visible la plus recente.
- `web_chat` conserve les actions `inspect`, `send`, `wait` et `read` sur l'onglet actif, a condition qu'il soit active.

Les conversations sont transmises au fournisseur avec ta session de navigateur deja connectee. Garde **Always ask** pour `mcp_call`.

DeepSeek est beta. ChatGPT, Claude, Gemini, Qwen, Kimi, GLM et Arena sont experimentaux; les sites peuvent modifier leur DOM. Arena Battle et Side-by-side ne sont pas pris en charge. Notion AI est experimental et doit etre active dans les options.
