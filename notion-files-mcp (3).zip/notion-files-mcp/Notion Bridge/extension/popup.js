const state = document.querySelector("#state");
const detail = document.querySelector("#detail");
const enable = document.querySelector("#enable");
const run = document.querySelector("#run");
const task = document.querySelector("#task");
const result = document.querySelector("#result");

async function refresh() {
  const [page, connection] = await Promise.all([
    chrome.runtime.sendMessage({type:"GET_ACTIVE_AGENT_STATE"}),
    chrome.runtime.sendMessage({type:"GET_WEB_MCP_STATUS"}),
  ]);
  if (!page?.info?.supported) {
    state.textContent = "Site non pris en charge";
    detail.textContent = page?.info?.reason || connection.connectionDetail || "Ouvre un chat IA compatible dans cet onglet.";
    enable.disabled = true;
    run.disabled = true;
    return;
  }
  state.textContent = `${page.info.name}${page.enabled ? " · agent activé" : " · agent désactivé"}`;
  detail.textContent = `Bridge local : ${connection.configured ? connection.connectionState || "déconnecté" : "jeton manquant"}. Le mode direct nécessite le bridge et Roblox Studio activé; Notion est facultatif.`;
  enable.textContent = page.enabled ? "Désactiver cet agent" : "Activer cet agent";
  enable.disabled = false;
  run.disabled = !page.enabled;
}

refresh();

enable.addEventListener("click", async () => {
  const response = await chrome.runtime.sendMessage({type:"TOGGLE_ACTIVE_AGENT"});
  if (response?.error) result.textContent = response.error;
  else result.textContent = response.enabled ? "Cet onglet est maintenant disponible dans web_agents." : "Agent désactivé pour cet onglet.";
  await refresh();
});

run.addEventListener("click", async () => {
  if (!task.value.trim()) { result.textContent = "Saisis une tâche d’abord."; return; }
  run.disabled = true;
  result.textContent = "La page IA traite la tâche…";
  try {
    const response = await chrome.runtime.sendMessage({type:"RUN_DIRECT_TASK",task:task.value.trim()});
    result.textContent = response.error || response.message || response.text || "La page n’a pas renvoyé de texte.";
  } catch (error) { result.textContent = String(error); }
  await refresh();
});

document.querySelector("#options").addEventListener("click", () => chrome.runtime.openOptionsPage());
