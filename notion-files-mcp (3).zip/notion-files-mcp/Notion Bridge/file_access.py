from __future__ import annotations

import hashlib
import os
import tempfile
from pathlib import Path


IGNORED_DIRS = {
    ".git", ".hg", ".svn", ".venv", "venv", "node_modules",
    "__pycache__", ".idea", ".vscode", "dist", "build", ".next",
}
SENSITIVE_NAMES = {
    ".env", ".env.local", "id_rsa", "id_ed25519", "credentials",
    "credentials.json", "secrets.json", "token.json",
}
SENSITIVE_SUFFIXES = {".pem", ".key", ".p12", ".pfx", ".kdbx"}
MAX_READ_BYTES = 512_000
MAX_WRITE_BYTES = 1_000_000


class WorkspaceFiles:
    """File operations confined to one user-selected directory."""

    def __init__(self, root: str | Path):
        self.root = Path(root).expanduser().resolve(strict=True)
        if not self.root.is_dir():
            raise ValueError("The workspace path must be a directory")

    @staticmethod
    def _is_sensitive(path: Path) -> bool:
        return any(part.lower() in SENSITIVE_NAMES for part in path.parts) or path.suffix.lower() in SENSITIVE_SUFFIXES

    def resolve(self, relative_path: str = ".") -> Path:
        raw = str(relative_path or ".").replace("\\", "/")
        candidate = Path(raw)
        if candidate.is_absolute() or ".." in candidate.parts:
            raise ValueError("Use a relative path inside the selected folder")
        if any(part.startswith(".") or part.lower() in IGNORED_DIRS for part in candidate.parts if part not in ("", ".")):
            raise ValueError("Hidden, dependency, and build folders are excluded")
        resolved = (self.root / candidate).resolve(strict=False)
        if not resolved.is_relative_to(self.root):
            raise ValueError("Path escapes the selected folder")
        if self._is_sensitive(candidate):
            raise ValueError("This path is excluded because it may contain credentials or secrets")
        return resolved

    @staticmethod
    def _display(path: Path, root: Path) -> str:
        return path.relative_to(root).as_posix() or "."

    def list_files(self, relative_path: str = ".", recursive: bool = False, limit: int = 200) -> str:
        directory = self.resolve(relative_path)
        if not directory.is_dir():
            raise ValueError("The requested path is not a directory")
        limit = max(1, min(int(limit), 500))
        found: list[str] = []

        def add_entry(path: Path) -> None:
            if path.name.startswith(".") or self._is_sensitive(path):
                return
            try:
                if path.is_symlink():
                    return
                if path.is_dir():
                    found.append(f"[folder] {self._display(path, self.root)}/")
                elif path.is_file():
                    found.append(f"[file]   {self._display(path, self.root)} ({path.stat().st_size} bytes)")
            except OSError:
                return

        if recursive:
            for current, dirs, files in os.walk(directory, followlinks=False):
                base = Path(current)
                dirs[:] = [
                    d for d in dirs
                    if d.lower() not in IGNORED_DIRS and not d.startswith(".")
                    and not self._is_sensitive(Path(d))
                ]
                for name in sorted(dirs) + sorted(files):
                    add_entry(base / name)
                    if len(found) >= limit:
                        return "\n".join(found) + f"\n[truncated at {limit} entries]"
        else:
            for entry in sorted(directory.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower())):
                add_entry(entry)
                if len(found) >= limit:
                    return "\n".join(found) + f"\n[truncated at {limit} entries]"
        return "\n".join(found) if found else "No visible files or folders found."

    def read_file(self, relative_path: str) -> str:
        path = self.resolve(relative_path)
        if not path.is_file():
            raise ValueError("The requested file does not exist")
        if path.stat().st_size > MAX_READ_BYTES:
            raise ValueError(f"File exceeds the {MAX_READ_BYTES}-byte read limit")
        data = path.read_bytes()
        if b"\x00" in data:
            raise ValueError("Binary files are not supported")
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError as exc:
            raise ValueError("File is not valid UTF-8 text") from exc
        digest = hashlib.sha256(data).hexdigest()
        return f"# {self._display(path, self.root)}\n# sha256: {digest}\n\n{text}"

    def search_files(self, query: str, relative_path: str = ".", max_results: int = 50) -> str:
        needle = str(query).casefold().strip()
        if not needle:
            raise ValueError("Search text cannot be empty")
        start = self.resolve(relative_path)
        if not start.is_dir():
            raise ValueError("The search path is not a directory")
        max_results = max(1, min(int(max_results), 100))
        results: list[str] = []
        scanned = 0
        truncated = False
        for current, dirs, files in os.walk(start, followlinks=False):
            base = Path(current)
            dirs[:] = [
                d for d in dirs
                if d.lower() not in IGNORED_DIRS and not d.startswith(".")
                and not self._is_sensitive(Path(d))
            ]
            for name in sorted(files):
                path = base / name
                if name.startswith(".") or self._is_sensitive(path) or path.is_symlink():
                    continue
                scanned += 1
                if scanned > 2000:
                    truncated = True
                    break
                try:
                    if path.stat().st_size > MAX_READ_BYTES:
                        continue
                    data = path.read_bytes()
                    if b"\x00" in data:
                        continue
                    text = data.decode("utf-8")
                except (OSError, UnicodeDecodeError):
                    continue
                for line_number, line in enumerate(text.splitlines(), 1):
                    if needle in line.casefold():
                        snippet = line.strip().replace("\t", " ")[:240]
                        results.append(f"{self._display(path, self.root)}:{line_number}: {snippet}")
                        if len(results) >= max_results:
                            truncated = True
                            break
                if len(results) >= max_results:
                    break
            if truncated:
                break
        if not results:
            return "No matches found." + (" Search stopped at the safety scan limit." if truncated else "")
        suffix = "\n[results limited for safety]" if truncated else ""
        return "\n".join(results) + suffix

    def write_file(self, relative_path: str, content: str, expected_sha256: str = "") -> str:
        path = self.resolve(relative_path)
        if path == self.root or not path.parent.is_dir():
            raise ValueError("The file's parent folder must already exist inside the selected folder")
        data = str(content).encode("utf-8")
        if len(data) > MAX_WRITE_BYTES:
            raise ValueError(f"Content exceeds the {MAX_WRITE_BYTES}-byte write limit")

        if path.exists():
            if not expected_sha256:
                raise ValueError("File already exists. Read it first, then pass its sha256 as expected_sha256 to confirm the exact version to replace")
            current = path.read_bytes()
            actual = hashlib.sha256(current).hexdigest()
            if actual != expected_sha256:
                raise ValueError("File changed since it was read; read it again before replacing")
        elif expected_sha256:
            raise ValueError("File does not exist; omit expected_sha256 to create it")

        fd, temporary = tempfile.mkstemp(prefix=".mcp-write-", dir=path.parent)
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write(data)
                stream.flush()
                os.fsync(stream.fileno())
            if expected_sha256:
                current = path.read_bytes()
                if hashlib.sha256(current).hexdigest() != expected_sha256:
                    raise ValueError("File changed while preparing the replacement; read it again before replacing")
                os.replace(temporary, path)
            else:
                # A hard link publishes the complete temporary file without
                # replacing a file created concurrently by another process.
                os.link(temporary, path)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
        digest = hashlib.sha256(data).hexdigest()
        action = "created" if not expected_sha256 else "replaced"
        return f"Successfully {action} {self._display(path, self.root)}. New sha256: {digest}"
