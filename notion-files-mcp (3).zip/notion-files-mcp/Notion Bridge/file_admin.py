from __future__ import annotations

import os
import shutil
import stat
from pathlib import Path


def _force_writable(func, path, *_):
    try:
        os.chmod(path, stat.S_IWRITE)
    except OSError:
        pass
    func(path)


def delete_path(root: str | Path, relative_path: str, recursive: bool = False, protected: list[Path] | None = None) -> str:
    """Delete one file or folder inside the selected root folder.

    The root itself and any protected folder (for example the running bridge) can never be deleted.
    """
    root = Path(root).resolve(strict=True)
    raw = str(relative_path or "").replace("\\", "/").strip().strip("/")
    if raw in ("", "."):
        raise ValueError("Refusing to delete the selected root folder")
    candidate = Path(raw)
    if candidate.is_absolute() or ".." in candidate.parts:
        raise ValueError("Use a relative path inside the selected folder")
    target = root / candidate
    if target.is_symlink():
        target.unlink()
        return f"Deleted link {candidate.as_posix()}"
    if not target.exists():
        raise ValueError("The requested path does not exist")
    target = target.resolve(strict=True)
    if target == root or not target.is_relative_to(root):
        raise ValueError("Path escapes the selected folder")
    for item in protected or []:
        item = Path(item).resolve()
        if item == target or item.is_relative_to(target):
            raise ValueError("Refusing to delete the folder of the running bridge. Start the bridge from the other folder first.")
    if target.is_dir():
        if not recursive and any(target.iterdir()):
            raise ValueError("Folder is not empty; pass recursive=true to delete it with its contents")
        try:
            shutil.rmtree(target, onexc=_force_writable)
        except TypeError:
            shutil.rmtree(target, onerror=_force_writable)
        return f"Deleted folder {candidate.as_posix()}"
    try:
        target.unlink()
    except PermissionError:
        os.chmod(target, stat.S_IWRITE)
        target.unlink()
    return f"Deleted file {candidate.as_posix()}"
