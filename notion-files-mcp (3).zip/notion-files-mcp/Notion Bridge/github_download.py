from __future__ import annotations

import hashlib
import os
import shutil
import stat
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

from file_access import WorkspaceFiles


MAX_DOWNLOAD_BYTES = 250 * 1024 * 1024
MAX_EXTRACTED_BYTES = 512 * 1024 * 1024
MAX_ARCHIVE_ENTRIES = 10_000
DOWNLOAD_TIMEOUT_SECONDS = 300
GITHUB_HOSTS = {"github.com", "www.github.com", "codeload.github.com", "api.github.com", "gist.github.com"}


def _validate_github_url(url: str) -> str:
    parsed = urllib.parse.urlsplit(str(url or "").strip())
    host = (parsed.hostname or "").lower().rstrip(".")
    try:
        port = parsed.port
    except ValueError as exc:
        raise ValueError("GitHub download URLs cannot include a custom port") from exc
    if (
        parsed.scheme.lower() != "https"
        or not host
        or (host not in GITHUB_HOSTS and not host.endswith(".githubusercontent.com"))
        or parsed.username is not None
        or parsed.password is not None
        or port not in (None, 443)
    ):
        raise ValueError("Use an HTTPS download link hosted by GitHub or githubusercontent.com")
    return urllib.parse.urlunsplit(parsed)


class _GitHubRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, response, code, message, headers, new_url):
        _validate_github_url(new_url)
        return super().redirect_request(request, response, code, message, headers, new_url)


def _extract_zip(archive: Path, destination: Path) -> tuple[int, int]:
    destination.mkdir()
    file_count = 0
    total_bytes = 0
    seen: dict[str, bool] = {}
    try:
        with zipfile.ZipFile(archive) as bundle:
            entries = bundle.infolist()
            if len(entries) > MAX_ARCHIVE_ENTRIES:
                raise ValueError("GitHub archive contains too many files")
            raw_paths: list[tuple[zipfile.ZipInfo, tuple[str, ...]]] = []
            first_parts = set()
            for info in entries:
                normalized = info.filename.replace("\\", "/")
                parts = tuple(part for part in normalized.split("/") if part not in ("", "."))
                if not parts or normalized.startswith("/") or any(part == ".." or ":" in part for part in parts):
                    raise ValueError("Archive contains an unsafe path")
                mode = (info.external_attr >> 16) & 0o170000
                if mode == stat.S_IFLNK or (mode not in (0, stat.S_IFREG, stat.S_IFDIR)):
                    raise ValueError("Archive links and special files are not supported")
                if info.flag_bits & 0x1:
                    raise ValueError("Encrypted ZIP entries are not supported")
                raw_paths.append((info, parts))
                first_parts.add(parts[0])
                total_bytes += info.file_size
                if total_bytes > MAX_EXTRACTED_BYTES:
                    raise ValueError("Extracted GitHub archive exceeds the 512 MB safety limit")

            strip_root = len(first_parts) == 1 and all(
                len(parts) > 1 or info.is_dir() for info, parts in raw_paths
            )
            for info, parts in raw_paths:
                output_parts = parts[1:] if strip_root else parts
                if not output_parts:
                    continue
                key = "/".join(output_parts).casefold()
                is_directory = info.is_dir()
                if key in seen and not (is_directory and seen[key]):
                    raise ValueError("Archive contains duplicate or conflicting file paths")
                seen[key] = is_directory
                output = destination.joinpath(*output_parts)
                if not output.resolve().is_relative_to(destination.resolve()):
                    raise ValueError("Archive path escapes the extraction folder")
                if is_directory:
                    output.mkdir(parents=True, exist_ok=True)
                    continue
                output.parent.mkdir(parents=True, exist_ok=True)
                written = 0
                with bundle.open(info) as source, output.open("xb") as target:
                    while chunk := source.read(1024 * 1024):
                        written += len(chunk)
                        if written > info.file_size or written > MAX_EXTRACTED_BYTES:
                            raise ValueError("Archive entry exceeded its declared size")
                        target.write(chunk)
                file_count += 1
            return file_count, total_bytes
    except BaseException:
        shutil.rmtree(destination, ignore_errors=True)
        raise


def download_github(files: WorkspaceFiles, url: str, destination: str, extract_zip: bool = False) -> str:
    """Download one GitHub-hosted file, optionally extracting a safe ZIP archive."""
    safe_url = _validate_github_url(url)
    target = files.resolve(destination)
    if target == files.root or not target.parent.is_dir():
        raise ValueError("The destination parent folder must already exist inside the selected folder")
    if target.exists():
        raise ValueError("The destination already exists; choose a new name so downloads never overwrite files")
    opener = urllib.request.build_opener(_GitHubRedirectHandler())
    request = urllib.request.Request(safe_url, headers={"User-Agent": "Notion-Local-Files-MCP/1.0"})
    started = time.monotonic()
    temporary_file = None
    try:
        with opener.open(request, timeout=30) as response:
            _validate_github_url(response.geturl())
            length = response.headers.get("Content-Length")
            if length and int(length) > MAX_DOWNLOAD_BYTES:
                raise ValueError("Download exceeds the 250 MB safety limit")
            hasher = hashlib.sha256()
            size = 0
            with tempfile.NamedTemporaryFile(prefix=".github-download-", dir=target.parent, delete=False) as stream:
                temporary_file = Path(stream.name)
                while chunk := response.read(1024 * 1024):
                    if time.monotonic() - started > DOWNLOAD_TIMEOUT_SECONDS:
                        raise TimeoutError("GitHub download exceeded the 5 minute time limit")
                    size += len(chunk)
                    if size > MAX_DOWNLOAD_BYTES:
                        raise ValueError("Download exceeds the 250 MB safety limit")
                    hasher.update(chunk)
                    stream.write(chunk)
        if extract_zip:
            try:
                with zipfile.ZipFile(temporary_file):
                    pass
            except zipfile.BadZipFile as exc:
                raise ValueError("The downloaded file is not a valid ZIP archive") from exc
            staging = Path(tempfile.mkdtemp(prefix=".github-extract-", dir=target.parent))
            staging.rmdir()
            count, expanded = _extract_zip(temporary_file, staging)
            if target.exists():
                shutil.rmtree(staging, ignore_errors=True)
                raise ValueError("The destination folder already exists")
            try:
                os.rename(staging, target)
            except OSError:
                shutil.rmtree(staging, ignore_errors=True)
                raise
            return (
                f"Extracted {count} GitHub files ({expanded} bytes) to "
                f"{target.relative_to(files.root).as_posix()}. Archive sha256: {hasher.hexdigest()}"
            )
        if not size:
            raise ValueError("GitHub returned an empty download")
        created_target = False
        try:
            with temporary_file.open("rb") as source, target.open("xb") as output:
                created_target = True
                shutil.copyfileobj(source, output, length=1024 * 1024)
        except BaseException:
            if created_target:
                target.unlink(missing_ok=True)
            raise
        return (
            f"Downloaded {size} bytes to {target.relative_to(files.root).as_posix()}. "
            f"sha256: {hasher.hexdigest()}"
        )
    except urllib.error.HTTPError as exc:
        raise ValueError(f"GitHub returned HTTP {exc.code} for this download") from exc
    except urllib.error.URLError as exc:
        raise ValueError(f"GitHub download failed: {exc.reason}") from exc
    finally:
        if temporary_file is not None:
            temporary_file.unlink(missing_ok=True)
