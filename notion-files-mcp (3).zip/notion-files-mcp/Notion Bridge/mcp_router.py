from __future__ import annotations

import json
import os
import queue
import re
import shutil
import subprocess
import threading
import time
from collections import deque
from pathlib import Path
from typing import Any

from browser_extension import BrowserExtensionBroker, BrowserExtensionMCPClient


PROTOCOL_VERSION = "2024-11-05"
MAX_RPC_LINE = 16 * 1024 * 1024
MAX_TOOL_TEXT = 20_000


def _compact_tool(tool: dict[str, Any]) -> dict[str, Any]:
    """Name, one-line summary and argument names (required marked with *)."""
    description = str(tool.get("description") or "")
    summary = next((line.strip() for line in description.splitlines() if line.strip()), "")
    if len(summary) > 140:
        summary = summary[:137].rstrip() + "..."
    schema = tool.get("inputSchema") if isinstance(tool.get("inputSchema"), dict) else {}
    props = schema.get("properties") if isinstance(schema.get("properties"), dict) else {}
    required = set(schema.get("required") or [])
    return {
        "name": tool.get("name", ""),
        "summary": summary,
        "args": [f"{name}*" if name in required else name for name in props],
    }
DEFAULT_SERVERS = {"roblox": {"type": "roblox_studio", "enabled": True}}
BLOCKED_ROBLOX_TOOLS = {"http_get", "store_image"}
GUARDED_ROBLOX_TOOLS = re.compile(r"(?:create|edit|modify|delete|remove|insert|upload|generate|set_|update|clone|multi_edit|execute_luau|start_stop_play|user_keyboard_input|user_mouse_input)", re.I)
SERVER_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,49}$")


def find_studio_mcp(env: dict[str, str] | None = None) -> Path:
    if env is None:
        env = os.environ
    override = env.get("ZS_STUDIO_MCP_PATH", "").strip().strip('"')
    if override:
        candidate = Path(override).expanduser()
        if candidate.is_dir():
            candidate /= "StudioMCP.exe"
        if candidate.is_file():
            return candidate.resolve()

    versions_roots = [
        Path(env[key]) / "Roblox" / "Versions"
        for key in ("LOCALAPPDATA", "ProgramFiles", "ProgramFiles(x86)")
        if env.get(key)
    ]
    candidates: list[Path] = []
    for versions in versions_roots:
        if not str(versions) or not versions.is_dir():
            continue
        try:
            for folder in versions.iterdir():
                mcp = folder / "StudioMCP.exe"
                has_studio = (folder / "RobloxStudioBeta.exe").is_file() or (folder / "RobloxStudio.exe").is_file()
                if mcp.is_file() and has_studio:
                    candidates.append(mcp)
        except OSError:
            continue
    if candidates:
        return max(candidates, key=lambda item: item.stat().st_mtime).resolve()
    raise RuntimeError(
        "Roblox Studio's StudioMCP.exe was not found. Install and open Roblox Studio, "
        "then enable Assistant Settings > MCP Servers > Enable Studio as MCP server. "
        "You may set ZS_STUDIO_MCP_PATH if Roblox is installed in a custom location."
    )


class StdioMCPClient:
    """Small persistent MCP stdio client; launches configured programs without a shell."""

    def __init__(self, command: str, args: list[str], cwd: Path, env: dict[str, str]):
        self.command = command
        self.args = args
        self.cwd = cwd
        self.env = env
        self.process: subprocess.Popen[str] | None = None
        self.initialized = False
        self.last_error = ""
        self.stderr_tail: deque[str] = deque(maxlen=8)
        self._operation_lock = threading.RLock()
        self._write_lock = threading.Lock()
        self._pending_lock = threading.Lock()
        self._pending: dict[int, queue.Queue[dict[str, Any] | None]] = {}
        self._next_id = 0
        self._reader_threads: list[threading.Thread] = []

    @property
    def running(self) -> bool:
        return self.process is not None and self.process.poll() is None

    def _start(self) -> None:
        with self._operation_lock:
            if self.running and self.initialized:
                return
            if self.running and not self.initialized:
                raise RuntimeError(self.last_error or "Previous MCP process did not initialize; it was not force-stopped")
            self.stderr_tail.clear()
            self.process = subprocess.Popen(
                [self.command, *self.args],
                cwd=str(self.cwd),
                env=self.env,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                encoding="utf-8",
                errors="replace",
                bufsize=1,
                shell=False,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            self.initialized = False
            self._reader_threads = [
                threading.Thread(target=self._read_stdout, daemon=True, name="mcp-stdout"),
                threading.Thread(target=self._read_stderr, daemon=True, name="mcp-stderr"),
            ]
            for thread in self._reader_threads:
                thread.start()
            try:
                initialized = self._request("initialize", {
                    "protocolVersion": PROTOCOL_VERSION,
                    "capabilities": {},
                    "clientInfo": {"name": "notion-mcp-router", "version": "1.0"},
                }, timeout=30)
                if initialized.get("protocolVersion") != PROTOCOL_VERSION:
                    raise RuntimeError("MCP server negotiated an unsupported protocol version")
                self._notify("notifications/initialized", {})
                self.initialized = True
                self.last_error = ""
            except Exception as exc:
                self.last_error = self._format_error(exc)
                self._close_stdin()
                raise RuntimeError(f"MCP server failed to initialize: {self.last_error}") from exc

    def _read_stdout(self) -> None:
        process = self.process
        if process is None or process.stdout is None:
            return
        try:
            while True:
                line = process.stdout.readline(MAX_RPC_LINE + 1)
                if not line:
                    break
                if len(line) > MAX_RPC_LINE and not line.endswith("\n"):
                    while line and not line.endswith("\n"):
                        line = process.stdout.readline(MAX_RPC_LINE + 1)
                    continue
                try:
                    message = json.loads(line)
                except (json.JSONDecodeError, TypeError):
                    continue
                request_id = message.get("id") if isinstance(message, dict) else None
                if isinstance(request_id, int):
                    with self._pending_lock:
                        waiter = self._pending.get(request_id)
                    if waiter:
                        waiter.put(message)
        finally:
            with self._pending_lock:
                pending = list(self._pending.values())
            for waiter in pending:
                try:
                    waiter.put_nowait(None)
                except queue.Full:
                    pass

    def _read_stderr(self) -> None:
        process = self.process
        if process is None or process.stderr is None:
            return
        for line in process.stderr:
            self.stderr_tail.append(line.rstrip()[:2000])

    def _write(self, payload: dict[str, Any]) -> None:
        process = self.process
        if process is None or process.poll() is not None or process.stdin is None:
            raise RuntimeError("MCP server process is not running")
        line = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
        if len(line) > MAX_RPC_LINE:
            raise ValueError("MCP request exceeds the 16 MB message limit")
        with self._write_lock:
            process.stdin.write(line + "\n")
            process.stdin.flush()

    def _request(self, method: str, params: dict[str, Any], timeout: int) -> dict[str, Any]:
        self._next_id += 1
        request_id = self._next_id
        waiter: queue.Queue[dict[str, Any] | None] = queue.Queue(maxsize=1)
        with self._pending_lock:
            self._pending[request_id] = waiter
        try:
            self._write({"jsonrpc": "2.0", "id": request_id, "method": method, "params": params})
            try:
                response = waiter.get(timeout=timeout)
            except queue.Empty as exc:
                raise TimeoutError(f"MCP request '{method}' timed out after {timeout} seconds") from exc
            if response is None:
                raise RuntimeError("MCP server closed its output" + self._stderr_suffix())
            if "error" in response:
                error = response["error"]
                message = error.get("message", error) if isinstance(error, dict) else error
                raise RuntimeError(str(message))
            result = response.get("result", {})
            if not isinstance(result, dict):
                raise RuntimeError(f"MCP server returned an invalid result for '{method}'")
            return result
        finally:
            with self._pending_lock:
                self._pending.pop(request_id, None)

    def _notify(self, method: str, params: dict[str, Any]) -> None:
        self._write({"jsonrpc": "2.0", "method": method, "params": params})

    def _stderr_suffix(self) -> str:
        return "\n" + "\n".join(self.stderr_tail) if self.stderr_tail else ""

    @staticmethod
    def _format_error(error: Exception) -> str:
        message = str(error).strip()
        return message[:2000] or type(error).__name__

    def list_tools(self, timeout: int = 15) -> list[dict[str, Any]]:
        with self._operation_lock:
            self._start()
            tools = []
            cursor = None
            for _ in range(20):
                params = {"cursor": cursor} if cursor else {}
                result = self._request("tools/list", params, timeout=timeout)
                page = result.get("tools", [])
                if not isinstance(page, list):
                    raise RuntimeError("MCP server returned an invalid tools/list response")
                tools.extend(page)
                cursor = result.get("nextCursor")
                if not cursor:
                    break
            return tools

    def call_tool(self, name: str, arguments: dict[str, Any], timeout: int = 120) -> dict[str, Any]:
        timeout = max(3, min(int(timeout), 180))
        with self._operation_lock:
            self._start()
            return self._request(
                "tools/call", {"name": name, "arguments": arguments}, timeout=timeout
            )

    def close(self) -> None:
        with self._operation_lock:
            process = self.process
            if process is None:
                return
            self._close_stdin()
            if process.poll() is None:
                try:
                    process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    self.last_error = "Process remained open after stdio closed; it was not force-stopped."
                    return
            for thread in self._reader_threads:
                thread.join(timeout=1)
            for stream in (process.stdout, process.stderr):
                if stream is not None:
                    stream.close()

    def _close_stdin(self) -> None:
        process = self.process
        if process is not None and process.stdin is not None:
            try:
                process.stdin.close()
            except OSError:
                pass


class MCPRegistry:
    """Config-driven MCP router; adding an MCP does not add shell commands or tools."""

    def __init__(self, root: str | Path, servers: dict[str, Any] | None = None, browser_extension: BrowserExtensionBroker | None = None):
        self.root = Path(root).resolve(strict=True)
        self.servers = DEFAULT_SERVERS.copy() if servers is None else servers
        if not isinstance(self.servers, dict):
            raise ValueError("mcp_servers must be a JSON object")
        for server_id in self.servers:
            if not isinstance(server_id, str) or not SERVER_ID.fullmatch(server_id):
                raise ValueError(f"Invalid MCP server id: {server_id!r}")
        self.browser_extension = browser_extension
        self.clients: dict[str, Any] = {}
        self.tool_cache: dict[str, set[str]] = {}
        self._lock = threading.Lock()

    def _definition(self, server_id: str) -> dict[str, Any]:
        if server_id not in self.servers:
            raise ValueError(f"MCP server '{server_id}' is not configured")
        definition = self.servers[server_id]
        if not isinstance(definition, dict):
            raise ValueError(f"Configuration for MCP server '{server_id}' must be an object")
        if definition.get("enabled", True) is False:
            raise ValueError(f"MCP server '{server_id}' is disabled in config.json")
        return definition

    def _client(self, server_id: str) -> StdioMCPClient:
        definition = self._definition(server_id)
        with self._lock:
            if server_id in self.clients:
                return self.clients[server_id]
            server_type = definition.get("type", "stdio")
            args = definition.get("args", [])
            if not isinstance(args, list) or not all(isinstance(arg, str) for arg in args):
                raise ValueError(f"MCP server '{server_id}' args must be a list of strings")
            env = dict(os.environ)
            extra_env = definition.get("env", {})
            if not isinstance(extra_env, dict) or not all(isinstance(k, str) and isinstance(v, str) for k, v in extra_env.items()):
                raise ValueError(f"MCP server '{server_id}' env must contain string values")
            env.update(extra_env)
            if server_type == "roblox_studio":
                command = str(find_studio_mcp())
                args = []
                cwd = self.root
            elif server_type == "stdio":
                command = definition.get("command")
                if not isinstance(command, str) or not command.strip():
                    raise ValueError(f"MCP server '{server_id}' needs a command")
                command = command.strip()
                cwd_value = definition.get("cwd", ".")
                if not isinstance(cwd_value, str):
                    raise ValueError(f"MCP server '{server_id}' cwd must be a relative path")
                cwd_candidate = Path(cwd_value)
                cwd = cwd_candidate.resolve(strict=True) if cwd_candidate.is_absolute() else (self.root / cwd_candidate).resolve(strict=True)
                if not cwd.is_dir() or not cwd.is_relative_to(self.root):
                    raise ValueError(f"MCP server '{server_id}' cwd must be a folder inside the selected project")
                if any(sep in command for sep in ("/", "\\")) and not Path(command).is_absolute():
                    command_path = (self.root / command).resolve(strict=True)
                    if not command_path.is_relative_to(self.root) or not command_path.is_file():
                        raise ValueError(f"MCP server '{server_id}' executable must be inside the selected project")
                    command = str(command_path)
                elif not Path(command).is_absolute():
                    command = shutil.which(command) or command
            elif server_type == "browser_extension":
                if self.browser_extension is None:
                    raise RuntimeError("Websites MCP is missing its authenticated Chrome extension broker")
                client = BrowserExtensionMCPClient(self.browser_extension)
                self.clients[server_id] = client
                return client
            else:
                raise ValueError(f"Unsupported MCP server type '{server_type}'")
            client = StdioMCPClient(command, args, cwd, env)
            self.clients[server_id] = client
            return client

    def list_servers(self) -> str:
        output = []
        for server_id, definition in self.servers.items():
            definition = definition if isinstance(definition, dict) else {}
            client = self.clients.get(server_id)
            is_extension = definition.get("type") == "browser_extension"
            output.append({
                "id": server_id,
                "type": definition.get("type", "stdio"),
                "enabled": definition.get("enabled", True) is not False,
                "process_running": self.browser_extension.connected if is_extension and self.browser_extension else bool(client and client.running),
                "last_error": client.last_error if client else "",
            })
        return json.dumps({"servers": output}, ensure_ascii=False)

    def list_tools(
        self, server_id: str, offset: int = 0, limit: int = 20,
        tool_names: list[str] | None = None, compact: bool = False,
    ) -> str:
        definition = self._definition(server_id)
        client = self._client(server_id)
        tools = client.list_tools()
        if server_id == "roblox":
            tools = [tool for tool in tools if not isinstance(tool, dict) or tool.get("name") not in BLOCKED_ROBLOX_TOOLS]
        if not tools and definition.get("type") == "roblox_studio":
            for _ in range(11):
                time.sleep(1)
                tools = client.list_tools()
                if tools:
                    break
            if not tools:
                self.tool_cache[server_id] = set()
                return json.dumps({
                    "server": server_id,
                    "tools": [],
                    "setup": "Open a place in Roblox Studio and enable Assistant Settings > MCP Servers > Enable Studio as MCP server, then list tools again.",
                }, ensure_ascii=False)
        if tool_names:
            wanted = [name for name in tool_names if isinstance(name, str)]
            by_name = {tool.get("name"): tool for tool in tools if isinstance(tool, dict)}
            selected = [by_name[name] for name in wanted if name in by_name]
            self.tool_cache.setdefault(server_id, set()).update(tool["name"] for tool in selected)
            output = json.dumps({
                "server": server_id,
                "tools": selected,
                "missing": [name for name in wanted if name not in by_name],
            }, ensure_ascii=False)
            if len(output) > MAX_TOOL_TEXT:
                output = json.dumps({"truncated": True, "preview": output[:MAX_TOOL_TEXT - 100]}, ensure_ascii=False)
            return output
        offset = max(0, int(offset))
        limit = max(1, min(int(limit), 100 if compact else 50))
        page = tools[offset:offset + limit]
        if compact:
            page = [_compact_tool(tool) for tool in page if isinstance(tool, dict)]
        names = {
            tool["name"] for tool in page if isinstance(tool, dict) and isinstance(tool.get("name"), str)
        }
        self.tool_cache.setdefault(server_id, set()).update(names)
        result = {
            "server": server_id,
            "total_tools": len(tools),
            "offset": offset,
            "next_offset": offset + len(page) if offset + len(page) < len(tools) else None,
            "tools": page,
        }
        if compact:
            result["hint"] = "args: * = required. For full schemas call mcp_list_tools(server_id, tool_names=[...])."
        output = json.dumps(result, ensure_ascii=False)
        if len(output) > MAX_TOOL_TEXT:
            compact = [
                {"name": tool.get("name", ""), "description": str(tool.get("description", ""))[:300]}
                for tool in page if isinstance(tool, dict)
            ]
            output = json.dumps({**result, "tools": compact, "schemas_omitted": True}, ensure_ascii=False)
        return output

    def call_tool(
        self, server_id: str, tool_name: str, arguments: dict[str, Any], timeout: int | None = None,
        *, internal: bool = False,
    ) -> str:
        if not isinstance(arguments, dict):
            raise ValueError("arguments must be a JSON object")
        if server_id == "roblox" and tool_name in BLOCKED_ROBLOX_TOOLS:
            raise ValueError(f"Roblox MCP tool '{tool_name}' is disabled by bridge policy")
        if server_id == "roblox" and tool_name == "execute_luau" and not internal:
            raise ValueError("Use roblox_execute_luau for Luau; raw execute_luau calls through mcp_call are blocked")
        if server_id == "roblox" and not internal and GUARDED_ROBLOX_TOOLS.search(tool_name):
            raise ValueError(f"Use roblox_studio or roblox_native_call for '{tool_name}' so Notion confirmation and snapshots can apply")
        if tool_name not in self.tool_cache.get(server_id, set()):
            raise ValueError("Discover this tool first with mcp_list_tools(server_id)")
        if timeout is None:
            timeout = 20 if server_id == "roblox" and tool_name == "execute_luau" else 120
        result = self._client(server_id).call_tool(tool_name, arguments, timeout)
        output = json.dumps(result, ensure_ascii=False, default=str)
        if len(output) > MAX_TOOL_TEXT:
            output = json.dumps({"truncated": True, "preview": output[:MAX_TOOL_TEXT - 100]}, ensure_ascii=False)
        return output

    def close(self) -> None:
        for client in list(self.clients.values()):
            client.close()
