from __future__ import annotations

import json
import os
import re
import secrets
import threading
import time
from pathlib import Path
from typing import Any

from mcp_router import GUARDED_ROBLOX_TOOLS, MCPRegistry


MAX_RESULT = 20_000
LUAU_OPEN = "BWJSON<<"
LUAU_CLOSE = ">>BWJSON"
BLOCKED_NATIVE = {"http_get", "store_image"}
UI_ROOTS = {"ScreenGui", "SurfaceGui", "BillboardGui", "Frame", "ScrollingFrame", "TextLabel", "TextButton", "TextBox", "ImageLabel", "ImageButton", "CanvasGroup", "ViewportFrame", "VideoFrame"}
VFX_ROOTS = {"ParticleEmitter", "Beam", "Trail", "Attachment", "PointLight", "SpotLight", "SurfaceLight", "Fire", "Smoke", "Sparkles", "Highlight", "Explosion", "Folder", "Part", "MeshPart"}
SCRIPT_CLASSES = {"Script", "LocalScript", "ModuleScript"}

LUAU_PRELUDE = r'''local HttpService = game:GetService("HttpService")
local ChangeHistoryService = game:GetService("ChangeHistoryService")
local function bw_resolve(segs)
	local cur = game
	for i = 2, #segs do
		local name = segs[i]
		local nxt = cur:FindFirstChild(name)
		if not nxt and cur == game then local ok, svc = pcall(function() return game:GetService(name) end); if ok then nxt = svc end end
		if not nxt then return nil, "not found: " .. tostring(name) end
		cur = nxt
	end
	return cur
end
local function bw_must(segs)
	local inst, err = bw_resolve(segs)
	if not inst then error(err, 0) end
	return inst
end
local function bw_path(inst)
	local parts, cur = {}, inst
	while cur and cur ~= game do
		table.insert(parts, 1, cur.Name)
		cur = cur.Parent
	end
	return "game." .. table.concat(parts, ".")
end
local function bw_decode(v)
	if type(v) ~= "table" or v["$type"] == nil then return v end
	local kind, a = v["$type"], v.value
	if kind == "Vector3" then return Vector3.new(a[1],a[2],a[3])
	elseif kind == "Vector2" then return Vector2.new(a[1],a[2])
	elseif kind == "Color3" then if type(a) == "string" then return Color3.fromHex(a) end; return Color3.fromRGB(a[1],a[2],a[3])
	elseif kind == "UDim2" then return UDim2.new(a[1],a[2],a[3],a[4])
	elseif kind == "UDim" then return UDim.new(a[1],a[2])
	elseif kind == "CFrame" then return CFrame.new(table.unpack(a))
	elseif kind == "Enum" then return Enum[v.enum][a]
	elseif kind == "BrickColor" then return BrickColor.new(a)
	elseif kind == "NumberRange" then return NumberRange.new(a[1],a[2] or a[1])
	elseif kind == "Ref" then return bw_must(v.segs) end
	error("unsupported typed value " .. tostring(kind), 0)
end
local function bw_enc(v)
	local kind = typeof(v)
	if kind == "Vector3" then return { ["$type"]="Vector3", value={v.X,v.Y,v.Z} }
	elseif kind == "Vector2" then return { ["$type"]="Vector2", value={v.X,v.Y} }
	elseif kind == "Color3" then return { ["$type"]="Color3", value={math.floor(v.R*255+0.5),math.floor(v.G*255+0.5),math.floor(v.B*255+0.5)} }
	elseif kind == "UDim2" then return { ["$type"]="UDim2", value={v.X.Scale,v.X.Offset,v.Y.Scale,v.Y.Offset} }
	elseif kind == "EnumItem" then return { ["$type"]="Enum", enum=tostring(v.EnumType), value=v.Name }
	elseif kind == "Instance" then return { ["$type"]="Ref", path=bw_path(v) }
	elseif kind == "BrickColor" then return { ["$type"]="BrickColor", value=v.Name }
	elseif kind == "number" and (v ~= v or v == math.huge or v == -math.huge) then return tostring(v) end
	return v
end
local function bw_coerce(inst, prop, raw)
	local v = bw_decode(raw)
	local ok, current = pcall(function() return inst[prop] end)
	if ok and type(v) == "table" and typeof(v) == "table" then
		local t = typeof(current)
		if t == "Vector3" then return Vector3.new(v[1],v[2],v[3])
		elseif t == "Vector2" then return Vector2.new(v[1],v[2])
		elseif t == "Color3" then return Color3.fromRGB(v[1],v[2],v[3])
		elseif t == "UDim2" then return UDim2.new(v[1],v[2],v[3],v[4])
		elseif t == "CFrame" then return CFrame.new(table.unpack(v)) end
	elseif ok and type(v) == "string" and typeof(current) == "Color3" and string.sub(v,1,1) == "#" then
		return Color3.fromHex(v)
	elseif ok and type(v) == "string" and typeof(current) == "BrickColor" then
		return BrickColor.new(v)
	end
	return v
end
local function bw_apply(inst, props)
	local errors = {}
	for prop, raw in pairs(props or {}) do
		if prop ~= "Parent" and prop ~= "ClassName" then
			local ok, err = pcall(function() inst[prop] = bw_coerce(inst, prop, raw) end)
			if not ok then table.insert(errors, {property=prop,error=tostring(err)}) end
		end
	end
	return errors
end
local function bw_create_tree(node, parent, created, errors)
	local inst = Instance.new(node.className)
	if node.name ~= nil then inst.Name = node.name end
	for _, err in ipairs(bw_apply(inst, node.properties)) do err.path = node.name or node.className; table.insert(errors, err) end
	for k, v in pairs(node.attributes or {}) do local ok, err = pcall(function() inst:SetAttribute(k,bw_decode(v)) end); if not ok then table.insert(errors,{attribute=k,error=tostring(err)}) end end
	if node.source ~= nil and inst:IsA("LuaSourceContainer") then inst.Source = node.source end
	for _, child in ipairs(node.children or {}) do bw_create_tree(child, inst, created, errors) end
	inst.Parent = parent
	table.insert(created, bw_path(inst))
	return inst
end
'''

WORKFLOWS = {
    "general": "Inspecte d'abord le lieu, annonce un plan court, travaille par petites étapes et vérifie chaque changement avec une lecture distincte avant de conclure.",
    "build": "Construis dans un Model nommé; ancre les pièces par défaut, calcule les coordonnées depuis une origine et vérifie nombre de pièces, dimensions et hauteur au sol.",
    "scripting": "Lis le script avant modification. Serveur dans ServerScriptService, client dans StarterPlayerScripts/StarterGui, code partagé dans ReplicatedStorage. Valide les données RemoteEvent côté serveur et teste les changements.",
    "ui": "Place les ScreenGui dans StarterGui, préfère des dimensions en Scale, vérifie l'arborescence et garde les actions serveur derrière des RemoteEvents validés.",
    "vfx": "Attache les émetteurs et lumières aux pièces ou Attachments. Limite le débit et la durée de vie des particules, puis vérifie les instances créées.",
    "gameplay": "Planifie scripts serveur, remotes et UI; garde monnaie, dégâts, statistiques et manches sous l'autorité du serveur; teste et vérifie les erreurs.",
    "debug": "Lis les erreurs Output, inspecte le script autour de la ligne signalée et cherche les références. Corrige au minimum puis relance un test et confirme la disparition de l'erreur.",
}


def _luau_string(value: str) -> str:
    out = ['"']
    for char in value:
        code = ord(char)
        if char == "\\": out.append("\\\\")
        elif char == '"': out.append('\\"')
        elif char == "\n": out.append("\\n")
        elif char == "\r": out.append("\\r")
        elif char == "\t": out.append("\\t")
        elif code < 32 or code == 127: out.append("\\" + str(code).rjust(3, "0"))
        else: out.append(char)
    out.append('"')
    return "".join(out)


def _to_luau(value: Any, depth: int = 0) -> str:
    if depth > 40:
        raise ValueError("Roblox arguments are nested too deeply")
    if value is None: return "nil"
    if value is True: return "true"
    if value is False: return "false"
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if isinstance(value, float) and (value != value or value in (float("inf"), float("-inf"))):
            raise ValueError("Roblox arguments cannot contain non-finite numbers")
        return repr(value)
    if isinstance(value, str): return _luau_string(value)
    if isinstance(value, list): return "{" + ",".join(_to_luau(x, depth + 1) for x in value) + "}"
    if isinstance(value, dict):
        items = []
        for key, item in value.items():
            if not isinstance(key, str): raise ValueError("Roblox object keys must be strings")
            items.append(f"[{_luau_string(key)}]={_to_luau(item, depth + 1)}")
        return "{" + ",".join(items) + "}"
    raise ValueError(f"Unsupported Roblox argument type: {type(value).__name__}")


def _path_segments(path: str) -> list[str]:
    if not isinstance(path, str) or not path.strip():
        raise ValueError("path must be a non-empty Roblox instance path")
    path = path.strip()
    match = re.match(r"^game\s*:\s*GetService\s*\(\s*['\"]([^'\"]+)['\"]\s*\)", path)
    if match: path = "game." + match.group(1) + path[match.end():]
    parts: list[str] = []
    i = 0
    current = ""
    while i < len(path):
        ch = path[i]
        if ch == ".":
            if current: parts.append(current); current = ""
            i += 1
        elif ch == "[":
            if current: parts.append(current); current = ""
            if i + 1 >= len(path) or path[i + 1] not in "\"'": raise ValueError(f"Invalid bracket path near {path[i:i+12]!r}")
            quote = path[i + 1]
            j = i + 2
            chars = []
            while j < len(path):
                if path[j] == "\\" and j + 1 < len(path): chars.append(path[j + 1]); j += 2
                elif path[j] == quote: break
                else: chars.append(path[j]); j += 1
            if j + 1 >= len(path) or path[j + 1] != "]": raise ValueError("Unterminated bracket path")
            parts.append("".join(chars)); i = j + 2
        else:
            current += ch; i += 1
    if current: parts.append(current)
    if not parts: raise ValueError("path must name a Roblox instance")
    if parts[0] != "game": parts.insert(0, "game")
    if any(not part for part in parts): raise ValueError("path contains an empty segment")
    return parts


def _prep_value(value: Any) -> Any:
    if isinstance(value, list): return [_prep_value(item) for item in value]
    if isinstance(value, dict):
        if value.get("$type") == "Ref" and isinstance(value.get("path"), str):
            return {"$type": "Ref", "segs": _path_segments(value["path"])}
        return {key: _prep_value(item) for key, item in value.items()}
    return value


def _prep_node(node: Any, depth: int = 0, count: list[int] | None = None) -> dict[str, Any]:
    if count is None: count = [0]
    if depth > 25: raise ValueError("instance tree is too deep (maximum 25 levels)")
    count[0] += 1
    if count[0] > 500: raise ValueError("instance tree is too large (maximum 500 instances)")
    if not isinstance(node, dict): raise ValueError("every tree node must be an object")
    cls = node.get("className")
    if not isinstance(cls, str) or not re.fullmatch(r"[A-Za-z][A-Za-z0-9]*", cls): raise ValueError("every tree node needs a valid className")
    out: dict[str, Any] = {"className": cls}
    for key in ("name", "source"):
        if key in node:
            if not isinstance(node[key], str): raise ValueError(f"tree {key} must be text")
            out[key] = node[key]
    for key in ("properties", "attributes"):
        if key in node:
            if not isinstance(node[key], dict): raise ValueError(f"tree {key} must be an object")
            out[key] = _prep_value(node[key])
    children = node.get("children", [])
    if not isinstance(children, list): raise ValueError("tree children must be a list")
    out["children"] = [_prep_node(child, depth + 1, count) for child in children]
    return out


def _wrapped_luau(arguments: dict[str, Any], body: str) -> str:
    if len(_to_luau(arguments)) > 2_000_000:
        raise ValueError("Roblox operation arguments exceed 2 MB")
    return (
        "-- Roblox Studio MCP composite\nlocal ARGS = " + _to_luau(arguments) + "\n" + LUAU_PRELUDE +
        "\nlocal __ok, __res = pcall(function()\n" + body +
        "\nend)\nlocal __out = if __ok then {ok=true,result=__res} else {ok=false,error=tostring(__res)}\n" +
        "local __json = HttpService:JSONEncode(__out)\nlocal __s = \"" + LUAU_OPEN + "\" .. __json .. \"" + LUAU_CLOSE + "\"\n" +
        "pcall(function() ChangeHistoryService:SetWaypoint(\"Roblox MCP change\") end)\nprint(__s)\nreturn __s"
    )


class RobloxStudioTools:
    """Roblox-only workflows layered over the official Studio MCP tools."""

    def __init__(self, registry: MCPRegistry, data_dir: str | Path, helpers_path: str | Path):
        self.registry = registry
        self.data_dir = Path(data_dir)
        self.helpers_path = Path(helpers_path)
        self._lock = threading.RLock()
        self._catalogue: list[dict[str, Any]] = []
        self._catalogue_at = 0.0
        self._project: dict[str, Any] | None = None

    def _discover(self, refresh: bool = False) -> list[dict[str, Any]]:
        with self._lock:
            if self._catalogue and not refresh and time.monotonic() - self._catalogue_at < 10:
                return self._catalogue
            all_tools: list[dict[str, Any]] = []
            offset = 0
            for _ in range(20):
                page = json.loads(self.registry.list_tools("roblox", offset=offset, limit=5))
                all_tools.extend(page.get("tools", []))
                next_offset = page.get("next_offset")
                if next_offset is None: break
                offset = int(next_offset)
            self._catalogue = [t for t in all_tools if isinstance(t, dict) and t.get("name") not in BLOCKED_NATIVE]
            self._catalogue_at = time.monotonic()
            return self._catalogue

    def native_tools(self, offset: int = 0, limit: int = 30) -> str:
        tools = self._discover()
        offset = max(0, int(offset))
        limit = max(1, min(50, int(limit)))
        page = tools[offset:offset + limit]
        return json.dumps({"server": "roblox", "total_tools": len(tools), "offset": offset,
                           "next_offset": offset + len(page) if offset + len(page) < len(tools) else None,
                           "tools": page}, ensure_ascii=False)

    def _native(self, name: str, arguments: dict[str, Any], timeout: int = 30, refresh: bool = False) -> dict[str, Any]:
        tools = self._discover(refresh=refresh)
        tool = next((item for item in tools if item.get("name") == name), None)
        if tool is None:
            raise ValueError(f"Roblox Studio does not currently provide '{name}'. Call roblox_native_tools to inspect available tools.")
        args = dict(arguments)
        props = (tool.get("inputSchema") or {}).get("properties", {})
        required = (tool.get("inputSchema") or {}).get("required", [])
        if "studio_id" in props and "studio_id" not in args and name != "list_roblox_studios":
            studio_id = self._selected_studio_id()
            if studio_id is not None:
                args["studio_id"] = studio_id
            elif "studio_id" in required:
                raise RuntimeError("No Roblox Studio instance is attached. Open a place and enable Studio as an MCP server.")
        if "datamodel_type" in props and "datamodel_type" not in args:
            enum = props["datamodel_type"].get("enum", [])
            args["datamodel_type"] = "Edit" if "Edit" in enum else (enum[0] if enum else "Edit")
        if "datamodel_type" in props:
            enum = props["datamodel_type"].get("enum", [])
            if enum and args.get("datamodel_type") not in enum:
                raise ValueError(f"datamodel_type must be one of {', '.join(map(str, enum))}")
        missing = [key for key in required if key not in args]
        if missing: raise ValueError(f"Roblox tool '{name}' needs arguments: {', '.join(missing)}")
        raw = json.loads(self.registry.call_tool("roblox", name, args, timeout=timeout, internal=True))
        if raw.get("isError"):
            text = "\n".join(item.get("text", "") for item in raw.get("content", []) if isinstance(item, dict))
            raise RuntimeError(text or f"Roblox tool {name} failed")
        return raw

    def _selected_studio_id(self) -> str | None:
        try:
            tools = self._discover()
            if not any(tool.get("name") == "list_roblox_studios" for tool in tools): return None
            raw = self._native("list_roblox_studios", {}, timeout=8)
            candidates: list[Any] = [raw.get("structuredContent")]
            candidates.extend(item.get("text", "") for item in raw.get("content", []) if isinstance(item, dict))
            def visit(value: Any) -> str | None:
                if isinstance(value, str):
                    try: return visit(json.loads(value))
                    except json.JSONDecodeError:
                        match = re.search(r"(\[[\s\S]*\]|\{[\s\S]*\})", value)
                        if match:
                            try: return visit(json.loads(match.group(1)))
                            except json.JSONDecodeError: pass
                        match = re.search(r"studio[_ ]?id[\"'\s:=]+([A-Za-z0-9-_{}]+)", value, re.I)
                        return match.group(1) if match else None
                if isinstance(value, list):
                    for item in value:
                        found = visit(item)
                        if found: return found
                if isinstance(value, dict):
                    identifier = next((value[k] for k in ("studio_id", "studioId", "instance_id", "instanceId", "id") if k in value), None)
                    if identifier is not None and isinstance(identifier, (str, int)): return str(identifier)
                    for child in value.values():
                        found = visit(child)
                        if found: return found
                return None
            for candidate in candidates:
                found = visit(candidate)
                if found: return found
        except Exception:
            return None
        return None

    @staticmethod
    def _text(result: dict[str, Any]) -> str:
        return "\n".join(item.get("text", "") for item in result.get("content", [])
                           if isinstance(item, dict) and item.get("type") == "text")

    def _execute_luau(self, code: str, timeout: int = 20, helpers: bool = False, datamodel_type: str = "Edit") -> tuple[str, dict[str, Any]]:
        if not isinstance(code, str) or not code.strip(): raise ValueError("Luau code must not be empty")
        if len(code) > 1_500_000: raise ValueError("Luau code exceeds the 1.5 MB limit")
        if helpers and re.search(r"\bBW\s*[.:]", code):
            if not self.helpers_path.is_file(): raise RuntimeError("Roblox helper library is missing from this installation")
            prelude = self.helpers_path.read_text(encoding="utf-8")
            helper_lines = prelude.count("\n") + 1
            code = prelude + "\n" + code
        tool = next((item for item in self._discover() if item.get("name") == "execute_luau"), None)
        if tool is None: raise ValueError("Roblox Studio does not currently provide execute_luau")
        props = (tool.get("inputSchema") or {}).get("properties", {})
        code_key = next((key for key in ("code", "source", "luau", "script", "command") if key in props), None)
        if code_key is None:
            code_key = next((key for key, schema in props.items() if schema.get("type") == "string" and not re.search(r"studio_id|datamodel", key, re.I)), "code")
        args: dict[str, Any] = {code_key: code}
        if "datamodel_type" in props: args["datamodel_type"] = datamodel_type
        try:
            result = self._native("execute_luau", args, timeout=timeout)
        except Exception as exc:
            message = str(exc)
            if helpers and re.search(r"\bBW\s*[.:]", code):
                def remap(match: re.Match[str]) -> str:
                    line = int(match.group(2))
                    return f"{match.group(1)}{line - helper_lines}:" if line > helper_lines else f"{match.group(1)}BW-helper:"
                message = re.sub(r"(\]|\.luau|\"|'|\w):(\d+):", remap, message)
            raise RuntimeError(message) from exc
        return self._text(result), result

    def execute_luau(self, code: str, datamodel_type: str = "Edit", timeout_seconds: int = 20, use_helpers: bool = True, snapshot_paths: list[str] | None = None) -> str:
        snapshot_id = None
        if snapshot_paths:
            if not isinstance(snapshot_paths, list) or len(snapshot_paths) > 50: raise ValueError("snapshot_paths must be a list of at most 50 paths")
            snapshot_id = self._take_snapshot([str(path) for path in snapshot_paths], "before raw Luau").get("snapshotId")
        text, result = self._execute_luau(code, max(3, min(180, int(timeout_seconds))), use_helpers, datamodel_type)
        return json.dumps({"text": text, "structuredContent": result.get("structuredContent"),
                           "isError": bool(result.get("isError")), "helpers_loaded": bool(use_helpers and re.search(r"\bBW\s*[.:]", code)),
                           "snapshotId": snapshot_id}, ensure_ascii=False)

    def native_call(self, tool_name: str, arguments: dict[str, Any], timeout_seconds: int = 30) -> str:
        if not isinstance(arguments, dict): raise ValueError("arguments must be an object")
        if tool_name == "execute_luau": raise ValueError("Use roblox_execute_luau so helper loading and limits are applied")
        snapshot_id = None
        targets = self._native_snapshot_targets(tool_name, arguments)
        if targets and GUARDED_ROBLOX_TOOLS.search(tool_name):
            snapshot_id = self._take_snapshot(targets[:50], "auto before " + tool_name).get("snapshotId")
        result = self._native(tool_name, arguments, timeout=max(3, min(180, int(timeout_seconds))))
        content, images = [], []
        for item in result.get("content", []):
            if not isinstance(item, dict): continue
            if item.get("type") == "image":
                images.append({"mimeType":item.get("mimeType"),"approxKB":round(len(item.get("data", ""))*0.75/1024)})
            elif item.get("type") == "text":
                text = str(item.get("text", ""))
                content.append(text[:MAX_RESULT] + ("...[truncated]" if len(text)>MAX_RESULT else ""))
            else:
                content.append(json.dumps(item,ensure_ascii=False,default=str)[:2000])
        output={"tool":tool_name,"text":"\n".join(content),"images":images,"isError":bool(result.get("isError")),"snapshotId":snapshot_id}
        if "structuredContent" in result:
            structured = json.dumps(result["structuredContent"],ensure_ascii=False,default=str)
            output["structuredContent"] = result["structuredContent"] if len(structured) <= MAX_RESULT else {"truncated":True,"preview":structured[:MAX_RESULT]}
        return json.dumps(output,ensure_ascii=False,default=str)

    @staticmethod
    def _native_snapshot_targets(tool_name: str, arguments: dict[str, Any]) -> list[str]:
        targets: list[str] = []
        def visit(value: Any, key: str = "") -> None:
            if isinstance(value, dict):
                for child_key, child in value.items(): visit(child, str(child_key))
            elif isinstance(value, list):
                for child in value: visit(child, key)
            elif isinstance(value, str) and re.search(r"path|script|target|instance", key, re.I) and re.match(r"^(?:game[.:]|Workspace[.\[])\S+", value):
                targets.append(value)
        visit(arguments)
        if not targets and arguments.get("parent") and arguments.get("name") and re.match(r"^(?:game[.:]|Workspace[.\[])\S+", str(arguments["parent"])):
            targets.append(str(arguments["parent"]).rstrip(".") + "." + str(arguments["name"]))
        return list(dict.fromkeys(targets))

    def _run_composite(self, body: str, args: dict[str, Any], timeout: int = 30) -> Any:
        code = _wrapped_luau(args, body)
        text, result = self._execute_luau(code, timeout=timeout)
        start, end = text.rfind(LUAU_OPEN), text.rfind(LUAU_CLOSE)
        if start < 0 or end < start:
            raise RuntimeError(f"Studio did not return the composite result (output: {text[:600]})")
        try: payload = json.loads(text[start + len(LUAU_OPEN):end])
        except json.JSONDecodeError as exc: raise RuntimeError("Studio returned malformed composite JSON") from exc
        if not payload.get("ok"):
            raise RuntimeError(str(payload.get("error", "Roblox operation failed")))
        self._project = payload.get("result") if isinstance(payload.get("result"), dict) and "placeName" in payload["result"] else self._project
        return payload.get("result")

    @staticmethod
    def _required(args: dict[str, Any], *names: str) -> None:
        missing = [name for name in names if name not in args]
        if missing: raise ValueError("Missing required arguments: " + ", ".join(missing))

    def _snapshot_targets(self, action: str, a: dict[str, Any]) -> list[str]:
        if action in {"modify_instance", "delete_instance", "delete_script", "set_script_source", "patch_script"}:
            return [str(a["path"])] if a.get("path") else []
        if action in {"create_script", "create_part", "create_instance", "create_instance_tree", "create_model", "create_ui", "create_vfx"}:
            parent = str(a.get("parent", "game.Workspace" if action in {"create_part", "create_model"} else "game.StarterGui" if action == "create_ui" else ""))
            node = a.get("tree") if "tree" in a else a
            name = node.get("name") if isinstance(node, dict) else None
            if name and parent: return [parent.rstrip(".") + "." + str(name)]
        if action == "clone_instance" and a.get("name") and a.get("parent"):
            return [str(a["parent"]).rstrip(".") + "." + str(a["name"])]
        if action == "modify_instance" and isinstance(a.get("path"), str): return [a["path"]]
        return []

    def _take_snapshot(self, paths: list[str], label: str) -> dict[str, Any]:
        snap_id = "snap_" + time.strftime("%Y%m%d_%H%M%S") + "_" + secrets.token_hex(3)
        segs = [_path_segments(path) for path in paths[:50]]
        args = {"id": snap_id, "label": label[:120], "paths": paths[:50], "segsList": segs}
        body = r'''local ss = game:GetService("ServerStorage")
local store = ss:FindFirstChild("__BrickwireSnapshots")
if not store then store = Instance.new("Folder"); store.Name = "__BrickwireSnapshots"; store.Parent = ss end
local snap = Instance.new("Folder"); snap.Name = ARGS.id; snap:SetAttribute("Label", ARGS.label); snap:SetAttribute("CreatedAt", os.time())
local entries = {}
for i, segs in ipairs(ARGS.segsList) do
	local inst = bw_resolve(segs)
	local entry = {index=i, path=ARGS.paths[i], segs=segs, absent=inst == nil, saved=false}
	if inst then
		entry.parentSegs = {}; for j=1,#segs-1 do table.insert(entry.parentSegs,segs[j]) end
		entry.name = inst.Name
		local ok, clone = pcall(function() return inst:Clone() end)
		if ok and clone then
			clone.Name = tostring(i); clone:SetAttribute("BW_OriginalName", inst.Name)
			for _, d in ipairs(clone:GetDescendants()) do if d:IsA("BaseScript") then d:SetAttribute("BW_WasDisabled",d.Disabled); d.Disabled=true end end
			if clone:IsA("BaseScript") then clone:SetAttribute("BW_WasDisabled",clone.Disabled); clone.Disabled=true end
			clone.Parent=snap; entry.saved=true
		else entry.reason="not archivable" end
	end
	table.insert(entries,entry)
end
snap:SetAttribute("Entries",HttpService:JSONEncode(entries)); snap.Parent=store
return {snapshotId=ARGS.id, label=ARGS.label, entries=entries}'''
        return self._run_composite(body, args)

    def run_action(self, action: str, arguments: dict[str, Any] | None = None, timeout_seconds: int = 30) -> str:
        a = arguments or {}
        if not isinstance(a, dict): raise ValueError("arguments must be an object")
        timeout = max(3, min(180, int(timeout_seconds)))
        snapshot_id = None
        with self._lock:
            if action == "status":
                try:
                    studios = self._native("list_roblox_studios", {}, timeout=10)
                    state = self._native("get_studio_state", {}, timeout=10)
                    return json.dumps({"studios": studios, "studio_state": state}, ensure_ascii=False)
                except Exception as exc:
                    return json.dumps({"connected": False, "reason": str(exc), "setup": "Open a place in Roblox Studio, then enable Assistant Settings > MCP Servers > Enable Studio as MCP server."}, ensure_ascii=False)
            if action == "get_errors":
                try:
                    result = self._native("get_console_output", {}, timeout=timeout)
                    text = self._text(result)
                    lines = [line for line in text.splitlines() if re.search(r"error|exception|stack begin|traceback|attempt to|expected|failed|warn", line, re.I)]
                    return json.dumps({"errorCount": len(lines), "lines": lines[-max(1, min(200, int(a.get("limit", 50)))):]}, ensure_ascii=False)
                except (ValueError, RuntimeError):
                    body = r'''local history=game:GetService("LogService"):GetLogHistory(); local out={}
for i=#history,1,-1 do local e=history[i]; local n=e.messageType and e.messageType.Name or "MessageOutput"; if n=="MessageError" or n=="MessageWarning" then table.insert(out,1,"["..n.."] "..e.message); if #out>=ARGS.limit then break end end end
return {lines=out,count=#out}'''
                    return json.dumps(self._run_composite(body, {"limit": max(1, min(200, int(a.get("limit", 50))))}), ensure_ascii=False)
            if action == "list_snapshots":
                body = r'''local store=game:GetService("ServerStorage"):FindFirstChild("__BrickwireSnapshots"); local out={}
if store then for _,s in ipairs(store:GetChildren()) do local ok,e=pcall(function() return HttpService:JSONDecode(s:GetAttribute("Entries") or "[]") end); table.insert(out,{id=s.Name,label=s:GetAttribute("Label"),createdAt=s:GetAttribute("CreatedAt"),entries=if ok then e else {}}) end end
return {snapshots=out}'''
                return json.dumps(self._run_composite(body, {}), ensure_ascii=False)
            if action == "restore_snapshot":
                self._required(a, "snapshotId")
                body = r'''local store=game:GetService("ServerStorage"):FindFirstChild("__BrickwireSnapshots"); local snap=store and store:FindFirstChild(ARGS.id); if not snap then error("snapshot not found",0) end
local entries=HttpService:JSONDecode(snap:GetAttribute("Entries") or "[]"); local restored,removed,failed={},{},{}
for _,e in ipairs(entries) do local current=bw_resolve(e.segs)
	if e.absent then if current then current:Destroy(); table.insert(removed,e.path) end
	elseif e.saved then local saved=snap:FindFirstChild(tostring(e.index)); local parent=bw_resolve(e.parentSegs)
		if not saved or not parent then table.insert(failed,e.path) else
			if current then current:Destroy() end
			local c=saved:Clone(); c.Name=saved:GetAttribute("BW_OriginalName") or c.Name; c:SetAttribute("BW_OriginalName",nil)
			local all=c:GetDescendants(); table.insert(all,c); for _,d in ipairs(all) do if d:IsA("BaseScript") then local was=d:GetAttribute("BW_WasDisabled"); if was~=nil then d.Disabled=was; d:SetAttribute("BW_WasDisabled",nil) end end end
			c.Parent=parent; table.insert(restored,e.path)
		end
	end
end
return {snapshotId=ARGS.id,restored=restored,removed=removed,failed=failed}'''
                result = self._run_composite(body, {"id": str(a["snapshotId"])}, timeout)
                return json.dumps(result, ensure_ascii=False)

            if action == "take_snapshot":
                self._required(a, "paths")
                if not isinstance(a["paths"], list) or not a["paths"]: raise ValueError("paths must be a non-empty list")
                if len(a["paths"]) > 50: raise ValueError("paths is limited to 50 instances per snapshot")
                if any(len(_path_segments(str(path))) < 3 for path in a["paths"]): raise ValueError("snapshots must target an instance below a service, not game or a service itself")
                result = self._take_snapshot([str(path) for path in a["paths"]], str(a.get("label", "manual snapshot")))
                return json.dumps(result, ensure_ascii=False)
            if action == "project_info":
                body = r'''local names={"Workspace","ReplicatedStorage","ReplicatedFirst","ServerScriptService","ServerStorage","StarterGui","StarterPack","StarterPlayer","Lighting","SoundService","Teams"}
local out={placeName=game.Name,placeId=game.PlaceId,gameId=game.GameId,creatorId=game.CreatorId,services={},scripts={},guis={},remotes=0,scriptCount=0}
for _,name in ipairs(names) do local ok,svc=pcall(function() return game:GetService(name) end); if ok then out.services[name]={children=#svc:GetChildren(),descendants=#svc:GetDescendants()}; for _,d in ipairs(svc:GetDescendants()) do if d:IsA("LuaSourceContainer") then out.scriptCount+=1; if #out.scripts<ARGS.maxScripts then table.insert(out.scripts,{path=bw_path(d),class=d.ClassName}) end end end end end
for _,g in ipairs(game:GetService("StarterGui"):GetChildren()) do table.insert(out.guis,{path=bw_path(g),class=g.ClassName,descendants=#g:GetDescendants()}) end
for _,d in ipairs(game:GetService("ReplicatedStorage"):GetDescendants()) do if d:IsA("RemoteEvent") or d:IsA("RemoteFunction") or d:IsA("UnreliableRemoteEvent") then out.remotes+=1 end end
return out'''
                result = self._run_composite(body, {"maxScripts": max(0, min(2000, int(a.get("maxScripts", 300))))}, timeout)
                self._save_scan(result)
                return json.dumps(result, ensure_ascii=False)

            if action == "get_game_tree":
                path = str(a.get("path", "game.Workspace")); depth = max(0, min(6, int(a.get("depth", 2)))); max_nodes = max(1, min(1500, int(a.get("maxNodes", 300))))
                body = r'''local root=bw_must(ARGS.segs); local count=0
local function walk(inst,depth) count+=1; local kids=inst:GetChildren(); local node={name=inst.Name,class=inst.ClassName,childCount=#kids}
	if depth<ARGS.depth and #kids>0 then node.children={}; for _,c in ipairs(kids) do if count>=ARGS.maxNodes then node.truncated=true; break end; table.insert(node.children,walk(c,depth+1)) end end
	return node
end
local tree=walk(root,0); return {path=bw_path(root),nodes=count,truncated=count>=ARGS.maxNodes,tree=tree}'''
                return json.dumps(self._run_composite(body, {"segs": _path_segments(path), "depth": depth, "maxNodes": max_nodes}, timeout), ensure_ascii=False)

            if action == "read_instance":
                self._required(a, "path")
                props = a.get("properties")
                if props is not None and (not isinstance(props, list) or len(props) > 100): raise ValueError("properties must be a list of at most 100 names")
                body = r'''local inst=bw_must(ARGS.segs); local props=ARGS.properties; local explicit=props~=nil
if not props then props={"Name","ClassName"}; local more={}; if inst:IsA("BasePart") then more={"Size","Position","Color","Material","Anchored","CanCollide","Transparency"} elseif inst:IsA("LuaSourceContainer") then more={"Source"}; if inst:IsA("BaseScript") then table.insert(more,"Disabled") end elseif inst:IsA("GuiObject") then more={"Size","Position","Visible","BackgroundColor3","Text"} elseif inst:IsA("LayerCollector") then more={"Enabled","ResetOnSpawn"} end; for _,p in ipairs(more) do table.insert(props,p) end end
local out={path=bw_path(inst),className=inst.ClassName,properties={},attributes={},children={}}
for _,p in ipairs(props) do local ok,v=pcall(function() return inst[p] end); if ok then if p=="Source" and type(v)=="string" and #v>20000 then v=string.sub(v,1,20000).."\\n-- truncated; use read_script" end; out.properties[p]=bw_enc(v) elseif explicit then out.properties[p]="<error: "..tostring(v)..">" end end
for k,v in pairs(inst:GetAttributes()) do out.attributes[k]=bw_enc(v) end
for i,c in ipairs(inst:GetChildren()) do if i>200 then break end; table.insert(out.children,c.Name.." ("..c.ClassName..")") end
return out'''
                return json.dumps(self._run_composite(body, {"segs": _path_segments(str(a["path"])), "properties": props}, timeout), ensure_ascii=False)

            if action == "read_script":
                self._required(a, "path")
                body = r'''local s=bw_must(ARGS.segs); if not s:IsA("LuaSourceContainer") then error("not a script",0) end
local lines=string.split(s.Source,"\n"); local first=math.max(1,ARGS.fromLine); local last=math.min(#lines,ARGS.toLine>0 and ARGS.toLine or #lines); local out,size,truncated={},0,false
for i=first,last do local line=string.format("%4d| %s",i,lines[i]); if size+#line>ARGS.maxChars then truncated=true; break end; table.insert(out,line); size+=#line+1 end
return {path=bw_path(s),className=s.ClassName,lineCount=#lines,fromLine=first,toLine=last,source=table.concat(out,"\n"),truncated=truncated}'''
                return json.dumps(self._run_composite(body, {"segs": _path_segments(str(a["path"])), "fromLine": max(1, int(a.get("fromLine", 1))), "toLine": max(0, int(a.get("toLine", 0))), "maxChars": max(1000, min(MAX_RESULT, int(a.get("maxChars", MAX_RESULT))))}, timeout), ensure_ascii=False)

            if action == "search_scripts":
                self._required(a, "text")
                if not isinstance(a["text"], str) or not a["text"]: raise ValueError("text must be a non-empty string")
                body = r'''local hits,total={},0
for _,d in ipairs(game:GetDescendants()) do if d:IsA("LuaSourceContainer") then local ok,src=pcall(function() return d.Source end); if ok then for i,line in ipairs(string.split(src,"\n")) do if string.find(line,ARGS.text,1,true) then total+=1; if #hits<ARGS.limit then table.insert(hits,{path=bw_path(d),line=i,text=string.sub(line,1,240)}) end end end end end end
return {total=total,hits=hits}'''
                return json.dumps(self._run_composite(body, {"text": str(a["text"]), "limit": max(1, min(200, int(a.get("limit", 40))))}, timeout), ensure_ascii=False)

            if action in {"create_instance", "create_part", "create_instance_tree", "create_model", "create_ui", "create_vfx", "create_script"}:
                if action == "create_instance_tree": self._required(a, "parent", "tree")
                elif action == "create_model": self._required(a, "tree")
                elif action == "create_ui": self._required(a, "tree")
                elif action == "create_vfx": self._required(a, "parent", "tree")
                elif action == "create_script": self._required(a, "parent", "name", "source")
                elif action == "create_part": self._required(a, "name")
                else: self._required(a, "parent", "className")
                if action == "create_part":
                    shape = str(a.get("shape", "Block")); cls = {"Wedge":"WedgePart","CornerWedge":"CornerWedgePart"}.get(shape, "Part")
                    if shape not in {"Block", "Ball", "Cylinder", "Wedge", "CornerWedge"}: raise ValueError("shape must be Block, Ball, Cylinder, Wedge or CornerWedge")
                    props = dict(a.get("properties") or {}); props["Anchored"] = a.get("anchored", True)
                    if "size" in a: props["Size"] = {"$type":"Vector3","value":a["size"]}
                    if "position" in a: props["Position"] = {"$type":"Vector3","value":a["position"]}
                    if "color" in a: props["Color"] = {"$type":"Color3","value":a["color"]}
                    if "material" in a: props["Material"] = {"$type":"Enum","enum":"Material","value":a["material"]}
                    if cls == "Part" and shape != "Block": props["Shape"] = {"$type":"Enum","enum":"PartType","value":shape}
                    node = {"className":cls,"name":str(a["name"]),"properties":_prep_value(props)}; parent = str(a.get("parent","game.Workspace"))
                elif action == "create_script":
                    cls = str(a.get("className", "Script"));
                    if cls not in SCRIPT_CLASSES: raise ValueError("className must be Script, LocalScript or ModuleScript")
                    node = {"className":cls,"name":str(a["name"]),"source":str(a["source"])}; parent = str(a["parent"])
                elif action == "create_instance":
                    node = {k:a[k] for k in ("className","name","properties","attributes") if k in a}; parent = str(a["parent"])
                else:
                    node = a["tree"]
                    default_parent = "game.Workspace" if action == "create_model" else "game.StarterGui" if action == "create_ui" else ""
                    parent = str(a.get("parent", default_parent))
                node = _prep_node(node)
                if action == "create_model" and node["className"] != "Model": raise ValueError("create_model root must be a Model")
                if action == "create_ui" and node["className"] not in UI_ROOTS: raise ValueError("create_ui root must be a GUI class")
                if action == "create_vfx" and node["className"] not in VFX_ROOTS: raise ValueError("create_vfx root class is not an approved VFX/part class")
                args = {"parentSegs":_path_segments(parent),"tree":node,"replace":bool(a.get("replaceExisting",False)),"label":action}
                body = r'''local parent=bw_must(ARGS.parentSegs); local tree=ARGS.tree
if tree.name then local old=parent:FindFirstChild(tree.name); if old then if ARGS.replace then old:Destroy() else error("already exists: "..old:GetFullName().." — choose another name or pass replaceExisting",0) end end end
local created,errors={},{}; local root=bw_create_tree(tree,parent,created,errors); return {path=bw_path(root),className=root.ClassName,created=created,propertyErrors=errors}'''
                targets = self._snapshot_targets(action, {**a, "tree": node, "parent": parent, "name": node.get("name")})
                if targets: snapshot_id = self._take_snapshot(targets, "auto before " + action).get("snapshotId")
                result = self._run_composite(body, args, timeout)
                return json.dumps({"snapshotId":snapshot_id,"result":result}, ensure_ascii=False)

            if action == "modify_instance":
                self._required(a, "path")
                if not isinstance(a.get("properties", {}), dict) or not isinstance(a.get("attributes", {}), dict): raise ValueError("properties and attributes must be objects")
                snapshot_id = self._ensure_snapshot(action, a)
                body = r'''local inst=bw_must(ARGS.segs); local before,after={},{}
for prop,_ in pairs(ARGS.properties) do local ok,v=pcall(function() return inst[prop] end); before[prop]=if ok then bw_enc(v) else nil end
local errors=bw_apply(inst,ARGS.properties); for k,v in pairs(ARGS.attributes) do local ok,e=pcall(function() inst:SetAttribute(k,bw_decode(v)) end); if not ok then table.insert(errors,{attribute=k,error=tostring(e)}) end end
if ARGS.name~=nil then inst.Name=ARGS.name end
for prop,_ in pairs(ARGS.properties) do local ok,v=pcall(function() return inst[prop] end); after[prop]=if ok then bw_enc(v) else nil end end
return {path=bw_path(inst),before=before,after=after,errors=errors}'''
                result = self._run_composite(body, {"segs":_path_segments(str(a["path"])),"properties":_prep_value(a.get("properties",{})),"attributes":_prep_value(a.get("attributes",{})),"name":a.get("name")}, timeout)
                return json.dumps({"snapshotId":snapshot_id,"result":result}, ensure_ascii=False)

            if action in {"delete_instance", "delete_script"}:
                self._required(a, "path")
                segs = _path_segments(str(a["path"]))
                if len(segs) < 3: raise ValueError("refusing to delete game or a service")
                snapshot_id = self._ensure_snapshot(action, a)
                if action == "delete_script":
                    body = r'''local s=bw_must(ARGS.segs); if not s:IsA("LuaSourceContainer") then error("target is not a script",0) end; local p=bw_path(s); s:Destroy(); return {deleted=p}'''
                else:
                    body = r'''local inst=bw_must(ARGS.segs); if inst.Parent==game then error("refusing to delete a service",0) end; local result={deleted=bw_path(inst),className=inst.ClassName,descendants=#inst:GetDescendants()}; inst:Destroy(); return result'''
                return json.dumps({"snapshotId":snapshot_id,"result":self._run_composite(body,{"segs":segs},timeout)},ensure_ascii=False)

            if action == "clone_instance":
                self._required(a, "path"); snapshot_id=self._ensure_snapshot(action, a)
                body = r'''local src=bw_must(ARGS.segs); local parent=if ARGS.parentSegs then bw_must(ARGS.parentSegs) else src.Parent; local clone=src:Clone(); if not clone then error("instance is not Archivable",0) end; if ARGS.name then clone.Name=ARGS.name end; clone.Parent=parent; return {path=bw_path(clone),className=clone.ClassName}'''
                args = {"segs":_path_segments(str(a["path"])),"parentSegs":_path_segments(str(a["parent"])) if a.get("parent") else None,"name":a.get("name")}
                return json.dumps({"snapshotId":snapshot_id,"result":self._run_composite(body,args,timeout)},ensure_ascii=False)

            if action == "set_script_source":
                self._required(a,"path","source"); snapshot_id=self._ensure_snapshot(action,a)
                body = r'''local s=bw_must(ARGS.segs); if not s:IsA("LuaSourceContainer") then error("target is not a script",0) end; local old=#s.Source; s.Source=ARGS.source; return {path=bw_path(s),oldLength=old,newLength=#s.Source}'''
                result=self._run_composite(body,{"segs":_path_segments(str(a["path"])),"source":str(a["source"])},timeout)
                return json.dumps({"snapshotId":snapshot_id,"result":result},ensure_ascii=False)

            if action == "patch_script":
                self._required(a,"path","find","replace")
                if not isinstance(a["find"], str) or not a["find"]: raise ValueError("find must be a non-empty string")
                snapshot_id=self._ensure_snapshot(action,a)
                body = r'''local s=bw_must(ARGS.segs); if not s:IsA("LuaSourceContainer") then error("target is not a script",0) end; local src=s.Source; local out,count,pos={},0,1
while true do local first,last=string.find(src,ARGS.find,pos,true); if not first or (ARGS.maxCount>0 and count>=ARGS.maxCount) then break end; table.insert(out,string.sub(src,pos,first-1)); table.insert(out,ARGS.replace); pos=last+1; count+=1 end
if count==0 then error("patch text not found",0) end; table.insert(out,string.sub(src,pos)); s.Source=table.concat(out); return {path=bw_path(s),replacements=count}'''
                args={"segs":_path_segments(str(a["path"])),"find":str(a["find"]),"replace":str(a["replace"]),"maxCount":max(0,int(a.get("maxCount",0)))}
                return json.dumps({"snapshotId":snapshot_id,"result":self._run_composite(body,args,timeout)},ensure_ascii=False)

            if action == "create_script":  # covered by the create branch; left for clearer unknown-action errors
                raise AssertionError("unreachable")
            raise ValueError(f"Unknown Roblox Studio action '{action}'. See roblox_workflow and roblox_native_tools for supported operations.")

    def _ensure_snapshot(self, action: str, args: dict[str, Any]) -> str | None:
        targets = self._snapshot_targets(action, args)
        if not targets: return None
        return str(self._take_snapshot(targets, "auto before " + action).get("snapshotId"))

    def _memory_record(self) -> tuple[Path, dict[str, Any], dict[str, Any]]:
        if not self._project:
            self._project = json.loads(self.run_action("project_info", {"maxScripts": 300}))
        project = self._project
        name, place_id = str(project.get("placeName", "Untitled place")), project.get("placeId")
        key = str(place_id) if place_id not in (None, 0, "0", "") else re.sub(r"[^A-Za-z0-9_-]+", "_", name)[:60]
        self.data_dir.mkdir(parents=True, exist_ok=True)
        file = self.data_dir / "roblox-project-memory.json"
        try: database = json.loads(file.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError): database = {}
        if not isinstance(database, dict): database = {}
        defaults = {"placeName":name,"placeId":place_id,"place":{},"scan":None,"notes":[],"importantScripts":[],"importantGuis":[],"systems":[],"dependencies":[],"preferences":[],"changes":[],"errors":[],"snapshots":[]}
        memory = database.setdefault(key, defaults)
        for field, value in defaults.items(): memory.setdefault(field, value)
        memory["placeName"], memory["placeId"] = name, place_id
        return file, database, memory

    @staticmethod
    def _save_memory_file(file: Path, database: dict[str, Any]) -> None:
        temp = file.with_suffix(".tmp")
        temp.write_text(json.dumps(database, ensure_ascii=False, indent=2), encoding="utf-8")
        os.replace(temp, file)

    def _save_scan(self, project: dict[str, Any]) -> None:
        self._project = project
        file, database, memory = self._memory_record()
        memory["place"] = {key:project.get(key) for key in ("placeName","placeId","gameId","creatorId","services","remotes")}
        memory["scan"] = {"at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"scripts":project.get("scripts",[]),"scriptCount":project.get("scriptCount",0),"guis":project.get("guis",[]),"remotes":project.get("remotes",0)}
        self._save_memory_file(file, database)

    def record_event(self, kind: str, tool: str, arguments: dict[str, Any], message: str = "", snapshot_id: str | None = None) -> None:
        try:
            file, database, memory = self._memory_record()
            target = arguments.get("path") or arguments.get("name") or arguments.get("snapshotId") or ""
            item = {"at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"tool":tool,"summary":str(message or target or tool)[:300]}
            field = "changes" if kind == "change" else "errors"
            if kind != "change": item["message"] = str(message)[:400]
            memory[field].append(item)
            del memory[field][:-300 if field == "changes" else -150]
            if kind == "change" and snapshot_id:
                memory["snapshots"].append({"id":snapshot_id,"tool":tool,"at":item["at"]})
                del memory["snapshots"][:-60]
            self._save_memory_file(file, database)
        except Exception:
            return

    def project_memory(self, action: str, category: str = "note", text: str = "", path: str = "") -> str:
        file, database, memory = self._memory_record()
        name = memory["placeName"]
        if action == "note":
            valid = {"note","important_script","important_gui","system","dependency","preference"}
            if category not in valid: raise ValueError("category must be one of " + ", ".join(sorted(valid)))
            if not text.strip(): raise ValueError("text must not be empty")
            field = {"important_script":"importantScripts","important_gui":"importantGuis"}.get(category, "notes" if category == "note" else category + "s")
            items = memory.setdefault(field, [])
            entry = {"text":text[:2000],"path":path[:500] if path else "","updatedAt":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())}
            existing = next((item for item in items if path and item.get("path")==path), None)
            if existing: existing.update(entry)
            else: items.append(entry)
            del items[:-200]
            self._save_memory_file(file, database)
        elif action != "get":
            raise ValueError("action must be get or note")
        return json.dumps({"project":name,"memory":memory},ensure_ascii=False)


def roblox_tool_actions() -> tuple[str, ...]:
    return (
        "status", "project_info", "get_game_tree", "read_instance", "create_instance", "create_part",
        "create_instance_tree", "create_model", "create_ui", "create_vfx", "modify_instance",
        "delete_instance", "clone_instance", "create_script", "read_script", "set_script_source",
        "patch_script", "search_scripts", "delete_script", "take_snapshot", "list_snapshots",
        "restore_snapshot", "get_errors",
    )
