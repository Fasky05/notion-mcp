from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path


TUNNEL_ID = "c6e598fc-5e18-43f3-8c74-27cdc02e4283"
PUBLIC_URL = "https://notion-mcp.fasky05.fr"
ORIGIN_URL = "http://127.0.0.1:8765"


def find_cloudflared() -> str | None:
    executable = shutil.which("cloudflared.exe") or shutil.which("cloudflared")
    if executable:
        return executable
    roots = {
        os.environ.get("ProgramFiles", r"C:\Program Files"),
        os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
    }
    candidates = [Path(root) / "cloudflared" / "cloudflared.exe" for root in roots]
    candidates.extend(Path(root) / "cloudflared.exe" for root in roots)
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate)
    return None


def credentials_file() -> Path:
    return Path.home() / ".cloudflared" / f"{TUNNEL_ID}.json"


def main(popen=subprocess.Popen) -> int:
    executable = find_cloudflared()
    if not executable:
        print("cloudflared was not found. Install it from https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/.")
        return 1

    credentials = credentials_file()
    if not credentials.is_file():
        print(f"The saved Cloudflare tunnel credentials are missing: {credentials}")
        print("Restore the existing tunnel credentials or configure a new named tunnel before starting the bridge.")
        return 1

    print("Starting the existing Cloudflare tunnel for the local bridge on port 8765...")
    print("Notion MCP URL:")
    print(f"  {PUBLIC_URL}/mcp")
    process = popen(
        [
            executable,
            "tunnel",
            "--no-autoupdate",
            "run",
            "--url",
            ORIGIN_URL,
            TUNNEL_ID,
        ],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        bufsize=1,
    )
    try:
        assert process.stdout is not None
        for line in process.stdout:
            print(line.rstrip(), flush=True)
        return_code = process.wait()
    except KeyboardInterrupt:
        if process.poll() is None:
            process.terminate()
            process.wait()
        print("\nCloudflare Tunnel stopped. Run Start Notion Bridge.bat again to reconnect.")
        return 0
    finally:
        if process.stdout:
            process.stdout.close()

    if return_code:
        print("Cloudflare Tunnel stopped with an error. Check the message above and confirm the tunnel credentials are valid.")
        return return_code
    print("Cloudflare Tunnel stopped. Run Start Notion Bridge.bat again to reconnect.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
