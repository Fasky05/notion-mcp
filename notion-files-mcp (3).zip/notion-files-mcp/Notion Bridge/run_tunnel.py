from __future__ import annotations

import os
import re
import shutil
import subprocess
from pathlib import Path

import run_cloudflare


FUNNEL_URL = re.compile(r"https://[a-z0-9-]+(?:\.[a-z0-9-]+)*\.ts\.net", re.IGNORECASE)


def find_tailscale() -> str | None:
    executable = shutil.which("tailscale.exe") or shutil.which("tailscale")
    if executable:
        return executable
    roots = {
        os.environ.get("ProgramFiles", r"C:\Program Files"),
        os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
    }
    for root in roots:
        candidate = Path(root) / "Tailscale" / "tailscale.exe"
        if candidate.is_file():
            return str(candidate)
    return None


def main(popen=subprocess.Popen) -> int:
    provider_file = Path(__file__).resolve().parent / "tunnel_provider.txt"
    provider = provider_file.read_text(encoding="utf-8").strip().lower() if provider_file.is_file() else "tailscale"
    if provider == "cloudflare":
        return run_cloudflare.main(popen=popen)
    if provider != "tailscale":
        print(f"Unknown tunnel provider in {provider_file.name}: {provider!r}. Use 'cloudflare' or 'tailscale'.")
        return 1

    executable = find_tailscale()
    if not executable:
        print("Tailscale was not found. Install it from https://tailscale.com/download and sign in.")
        return 1

    print("Resetting existing Tailscale Funnel and Serve routes before configuring the bridge...")
    for subcommand in ("funnel", "serve"):
        reset = subprocess.run(
            [executable, subcommand, "reset"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        if reset.returncode:
            detail = (reset.stderr or reset.stdout).strip()
            print(f"Could not reset the existing Tailscale {subcommand} configuration.")
            if detail:
                print(detail)
            return 1

    print("Starting Tailscale Funnel on public HTTPS port 443 for the local bridge on port 8765...")
    process = popen(
        [executable, "funnel", "--bg", "--https=443", "127.0.0.1:8765"],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        encoding="utf-8",
        errors="replace",
        bufsize=1,
    )
    public_url = None
    try:
        assert process.stdout is not None
        for line in process.stdout:
            print(line.rstrip(), flush=True)
            if public_url is None:
                match = FUNNEL_URL.search(line)
                if match:
                    public_url = match.group(0)
                    show_connection_steps(public_url)
        return_code = process.wait()
    except KeyboardInterrupt:
        if process.poll() is None:
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.terminate()
                process.wait()
        print("\nTailscale Funnel stopped. Run Start Notion Bridge.bat again to reconnect.")
        return 0
    finally:
        if process.stdout:
            process.stdout.close()

    if not public_url or return_code:
        print("Tailscale Funnel did not start. Check that Tailscale is signed in and Funnel is enabled for your tailnet.")
        return 1
    return 0


def show_connection_steps(public_url: str) -> None:
    folder = Path(__file__).resolve().parent.name
    print("\nSECURE CONNECTION READY\n")
    print("Copy this full address into your Notion Custom MCP connection (HTTPS port 443):")
    print(f"  {public_url}/mcp\n")
    print("Finish setup in this order:")
    print(f"  1. In Chrome, load the unpacked extension from {folder}\\extension (one time).")
    print(f"  2. In extension Options, paste web_extension_token from {folder}\\config.json.")
    print(f"  3. In Notion, use the URL above and Authorization: Bearer <bearer_token> from {folder}\\config.json.")
    print("  4. For Roblox, open a place and enable Studio MCP in Assistant Settings.\n")
    print("Funnel is configured in the background and survives closing this window and PC restarts.")
    print("Keep the minimized Notion Bridge window open while using Notion.")
    print("To stop public access, run: tailscale funnel reset")


if __name__ == "__main__":
    raise SystemExit(main())
