from __future__ import annotations

import atexit
import functools
import hmac
import inspect
import json
import secrets
import time
from contextlib import nullcontext
from pathlib import Path
from typing import Literal

import uvicorn
from mcp.server.fastmcp import FastMCP
from mcp.server.transport_security import TransportSecuritySettings
from starlette.responses import JSONResponse
from starlette.requests import Request
from starlette.routing import Route, WebSocketRoute
from starlette.concurrency import run_in_threadpool

from browser_extension import BrowserExtensionBroker
from command_tools import run_command
from file_access import WorkspaceFiles
from file_admin import delete_path as delete_workspace_path
from shell_tools import run_shell as run_full_shell
from github_download import download_github as download_from_github
from mcp_router import MCPRegistry
from roblox_features import GUARDED_ROBLOX_TOOLS, RobloxStudioTools, WORKFLOWS
from direct_agent import DirectAgentService, StudioWriterCoordinator


HERE = Path(__file__).resolve().parent
CONFIG_PATH = HERE / "config.json"
CODEBASE_MEMORY_ID = "codebase_memory"
CODEBASE_MEMORY_EXE = "bin/cbm/codebase-memory-mcp.exe"
AST_GREP_ID = "ast_grep"
AST_GREP_DIR = "ast-grep-mcp"
AST_GREP_PYTHON = "ast-grep-mcp/.venv/Scripts/python.exe"
AST_GREP_EXE = "ast-grep-mcp/bin/ast-grep.exe"


def add_codebase_memory(servers: dict, root: Path) -> dict:
    """Register the local codebase-memory-mcp binary (stdio) when it is present.

    The executable is only launched, never modified. A user entry with the same id in
    config.json (for example {"enabled": false}) always takes precedence.
    """
    if CODEBASE_MEMORY_ID in servers or not (Path(root) / CODEBASE_MEMORY_EXE).is_file():
        return servers
    return {**servers, CODEBASE_MEMORY_ID: {
        "type": "stdio", "command": CODEBASE_MEMORY_EXE, "args": [], "cwd": ".", "enabled": True,
    }}


def add_ast_grep(servers: dict, root: Path) -> dict:
    """Register the local ast-grep MCP server (stdio) when it is installed.

    Uses ast-grep-mcp/.venv (Python 3.13) and the bundled ast-grep CLI in
    ast-grep-mcp/bin. A user entry with the same id in config.json always wins.
    """
    root = Path(root)
    if AST_GREP_ID in servers or not (root / AST_GREP_PYTHON).is_file() or not (root / AST_GREP_EXE).is_file():
        return servers
    return {**servers, AST_GREP_ID: {
        "type": "stdio", "command": AST_GREP_PYTHON, "args": ["main.py"], "cwd": AST_GREP_DIR, "enabled": True,
        "env": {"AST_GREP_PATH": str((root / AST_GREP_EXE).resolve())},
    }}


def load_config() -> dict:
    if not CONFIG_PATH.is_file():
        raise SystemExit("Configuration missing. Run start_all.bat first, or setup_windows.bat for manual setup.")
    config = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    if not config.get("bearer_token") or not config.get("root_directory"):
        raise SystemExit("Configuration is incomplete. Run start_all.bat again, or setup_windows.bat for manual setup.")
    changed = False
    if not config.get("web_extension_token"):
        config["web_extension_token"] = secrets.token_urlsafe(40)
        changed = True
    if not isinstance(config.get("mcp_servers"), dict):
        config["mcp_servers"] = {"roblox":{"type":"roblox_studio","enabled":True}}
        changed = True
    if "websites" not in config["mcp_servers"]:
        config["mcp_servers"]["websites"] = {"type":"browser_extension","enabled":True}
        changed = True
    if changed:
        CONFIG_PATH.write_text(json.dumps(config, indent=2), encoding="utf-8")
        try:
            CONFIG_PATH.chmod(0o600)
        except OSError:
            pass
    return config


class BearerAuth:
    """Protect every MCP request with the per-installation secret token."""

    def __init__(self, app, token: str, extension_token: str = ""):
        self.app = app
        self.expected = f"Bearer {token}".encode("utf-8")
        self.extension_expected = f"Bearer {extension_token}".encode("utf-8") if extension_token else b""

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        headers = dict(scope.get("headers", []))
        supplied = headers.get(b"authorization", b"")
        direct_agent_route = scope.get("path", "").startswith("/direct-agent/")
        expected = self.extension_expected if direct_agent_route else self.expected
        if not expected or not hmac.compare_digest(supplied, expected):
            response = JSONResponse(
                {"error": "Unauthorized"},
                status_code=401,
                headers={"WWW-Authenticate": "Bearer"},
            )
            return await response(scope, receive, send)
        await self.app(scope, receive, send)


class HTTPStatusDiagnostics:
    """Log only repeated server errors, without recording request bodies or secrets."""

    def __init__(self, app):
        self.app = app
        self.state = getattr(app, "state", None)
        self._last_logged: dict[tuple[int, str], float] = {}

    def _log(self, status: int, scope) -> None:
        if status != 429 and status < 500:
            return
        path = scope.get("path", "/")
        key = (status, path)
        now = time.monotonic()
        if now - self._last_logged.get(key, 0) < 60:
            return
        self._last_logged[key] = now
        print(f"Bridge returned HTTP {status} for {scope.get('method', 'HTTP')} {path}.", flush=True)

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        status = None

        async def tracked_send(message):
            nonlocal status
            if message["type"] == "http.response.start":
                status = message["status"]
            await send(message)

        await self.app(scope, receive, tracked_send)
        if status is not None:
            self._log(status, scope)


def main() -> None:
    config = load_config()
    port = int(config.get("port", 8765))
    app = build_app(config)
    print(f"MCP server ready at http://127.0.0.1:{port}/mcp")
    print(f"Approved folder: {Path(config['root_directory']).expanduser().resolve()}")
    if config.get("allow_full_shell"):
        print("Full shell tool is ENABLED (allow_full_shell=true in config.json).")
    if config.get("allow_delete"):
        print("Delete tool is ENABLED (allow_delete=true in config.json).")
    print("Keep this window open while the Notion Agent is using your files.")
    uvicorn.run(app, host="127.0.0.1", port=port, log_level="warning")


def build_app(config: dict):
    files = WorkspaceFiles(config["root_directory"])
    token = config["bearer_token"]
    extension_token = config.get("web_extension_token") or secrets.token_urlsafe(40)
    extension = BrowserExtensionBroker(extension_token)
    servers = config.get("mcp_servers")
    if servers is None:
        servers = {"roblox":{"type":"roblox_studio","enabled":True}}
    if isinstance(servers, dict) and "websites" not in servers:
        servers = {**servers, "websites":{"type":"browser_extension","enabled":True}}
    if isinstance(servers, dict):
        servers = add_codebase_memory(servers, files.root)
        servers = add_ast_grep(servers, files.root)
    registry = MCPRegistry(files.root, servers, browser_extension=extension)
    atexit.register(registry.close)
    roblox = RobloxStudioTools(registry, HERE / "data", HERE / "roblox_helpers.luau")
    studio_writer_lock = StudioWriterCoordinator()
    direct_agent = DirectAgentService(roblox, studio_writer_lock)
    mcp = FastMCP(
        "Local files",
        log_level="WARNING",
        json_response=True,
        stateless_http=True,
        # The public hostname is a temporary tunnel URL; the bridge is
        # loopback-only and every request is separately protected by BearerAuth.
        transport_security=TransportSecuritySettings(enable_dns_rebinding_protection=False),
    )

    # Multi-client: FastMCP runs plain `def` tools directly on the event loop, so one long
    # run_shell/roblox call froze every other AI. Run them in worker threads instead.
    # Shared state (Studio, MCP router, browser extension) already has its own locks.
    _orig_tool = mcp.tool

    def _threaded_tool(*targs, **tkwargs):
        register = _orig_tool(*targs, **tkwargs)

        def deco(fn):
            if inspect.iscoroutinefunction(fn):
                return register(fn)

            @functools.wraps(fn)
            async def runner(*a, **k):
                return await run_in_threadpool(fn, *a, **k)

            register(runner)
            return fn

        return deco

    mcp.tool = _threaded_tool

    @mcp.tool()
    def list_files(path: str = ".", recursive: bool = False, limit: int = 200) -> str:
        """List visible files in the approved folder. Paths are relative to that folder."""
        return files.list_files(path, recursive, limit)

    @mcp.tool()
    def read_file(path: str) -> str:
        """Read one UTF-8 text file (up to 500 KB). Credentials and hidden files are excluded."""
        return files.read_file(path)

    @mcp.tool()
    def search_files(query: str, path: str = ".", max_results: int = 50) -> str:
        """Search visible UTF-8 text files for a phrase; common dependency/build folders are skipped."""
        return files.search_files(query, path, max_results)

    @mcp.tool()
    def write_file(path: str, content: str, expected_sha256: str = "") -> str:
        """Create a file, or replace it only when expected_sha256 matches its current contents."""
        return files.write_file(path, content, expected_sha256)

    if config.get("allow_delete"):
        @mcp.tool()
        def delete_path(path: str, recursive: bool = False) -> str:
            """Delete one file or folder inside the approved folder. Folders with content need recursive=true. The root and the running bridge folder are protected. Destructive: keep Notion confirmation enabled."""
            return delete_workspace_path(files.root, path, recursive, protected=[HERE])

    @mcp.tool()
    def download_github_file(url: str, destination: str, extract_zip: bool = False) -> str:
        """Download a public GitHub release asset or repository archive by direct HTTPS URL into the selected folder; optionally extract a safe ZIP into a new folder."""
        return download_from_github(files, url, destination, extract_zip)

    @mcp.tool()
    def mcp_servers() -> str:
        """Start here: compact overview of connected MCP servers, built-in tool groups, and the 3 main commands."""
        overview = json.loads(registry.list_servers())
        try:
            names = sorted(tool.name for tool in mcp._tool_manager.list_tools())
        except Exception:
            names = []
        router_tools = {"mcp_servers", "mcp_list_tools", "mcp_call"}
        overview["built_in"] = {
            "local_pc_access": [n for n in names if not n.startswith("roblox_") and n not in router_tools],
            "roblox_studio": [n for n in names if n.startswith("roblox_")],
        }
        overview["usage"] = [
            "mcp_list_tools(server_id) -> compact tool names, summaries, arg names",
            "mcp_list_tools(server_id, tool_names=[...]) -> full schemas for only those tools",
            "mcp_call(server_id, tool_name, arguments) -> run a listed tool",
        ]
        return json.dumps(overview, ensure_ascii=False)

    @mcp.tool()
    def mcp_list_tools(server_id: str, tool_names: list[str] | None = None, offset: int = 0, limit: int = 100) -> str:
        """List one server's tools compactly (name, summary, args). Pass tool_names to get full schemas for just those tools. Listed tools can then be used with mcp_call."""
        return registry.list_tools(server_id, offset, limit, tool_names=tool_names, compact=not tool_names)

    @mcp.tool()
    def mcp_call(server_id: str, tool_name: str, arguments: dict, timeout_seconds: int | None = None) -> str:
        """Call one tool on a configured MCP server by its server id and discovered tool name. Keep Notion confirmation enabled."""
        return registry.call_tool(server_id, tool_name, arguments, timeout_seconds)

    @mcp.tool()
    def roblox_studio(
        action: Literal[
            "status", "project_info", "get_game_tree", "read_instance", "create_instance", "create_part",
            "create_instance_tree", "create_model", "create_ui", "create_vfx", "modify_instance",
            "delete_instance", "clone_instance", "create_script", "read_script", "set_script_source",
            "patch_script", "search_scripts", "delete_script", "take_snapshot", "list_snapshots",
            "restore_snapshot", "get_errors",
        ],
        arguments: dict,
        timeout_seconds: int = 30,
    ) -> str:
        """Control only the open Roblox Studio place. In arguments use path strings such as game.Workspace.Part; get_game_tree accepts path/depth/maxNodes, read_instance accepts path/properties, and read_script accepts path/fromLine/toLine. Create actions accept a parent plus tree={className,name,properties,attributes,source,children}; create_part accepts name/parent/size/position/color/material/shape. modify_instance accepts path/properties/attributes/name; set_script_source accepts path/source; patch_script accepts path/find/replace/maxCount; snapshot actions use paths/label or snapshotId. New trees are limited to 500 instances. Writes snapshot target paths when possible; deletes and arbitrary Luau are destructive. Keep Notion Always ask enabled."""
        writes = {"create_instance", "create_part", "create_instance_tree", "create_model", "create_ui", "create_vfx", "modify_instance", "delete_instance", "clone_instance", "create_script", "set_script_source", "patch_script", "delete_script", "take_snapshot", "restore_snapshot"}
        with studio_writer_lock.notion_write() if action in writes else nullcontext():
            try:
                result = roblox.run_action(action, arguments, timeout_seconds)
            except Exception as exc:
                roblox.record_event("error", action, arguments, str(exc))
                raise
            if action in writes:
                try: snapshot_id = json.loads(result).get("snapshotId")
                except (json.JSONDecodeError, AttributeError): snapshot_id = None
                roblox.record_event("change", action, arguments, snapshot_id=snapshot_id)
        return result

    @mcp.tool()
    def roblox_native_tools(offset: int = 0, limit: int = 20) -> str:
        """List Roblox Studio's real native MCP tools and schemas. Continues with next_offset. Web fetching and local-image file reading are intentionally excluded."""
        return roblox.native_tools(offset, limit)

    @mcp.tool()
    def roblox_native_call(tool_name: str, arguments: dict, timeout_seconds: int = 30) -> str:
        """Call an available native Roblox Studio MCP tool (for play tests, screen capture, asset generation, Studio input, and other Studio operations). Only tools actually advertised by Roblox Studio are callable. Keep Notion Always ask enabled."""
        with studio_writer_lock.notion_write() if GUARDED_ROBLOX_TOOLS.search(tool_name) else nullcontext():
            try:
                result = roblox.native_call(tool_name, arguments, timeout_seconds)
            except Exception as exc:
                if GUARDED_ROBLOX_TOOLS.search(tool_name): roblox.record_event("error", tool_name, arguments, str(exc))
                raise
            if GUARDED_ROBLOX_TOOLS.search(tool_name):
                try: snapshot_id = json.loads(result).get("snapshotId")
                except (json.JSONDecodeError, AttributeError): snapshot_id = None
                roblox.record_event("change", tool_name, arguments, snapshot_id=snapshot_id)
        return result

    @mcp.tool()
    def roblox_execute_luau(code: str, datamodel_type: str = "Edit", timeout_seconds: int = 20, use_helpers: bool = True, snapshot_paths: list[str] | None = None) -> str:
        """Run privileged Luau in Roblox Studio; it can change or delete any project content. Read first; pass snapshot_paths for automatic recovery copies of known targets. The BW helper library loads when code uses BW.*. Keep Notion Always ask enabled."""
        with studio_writer_lock.notion_write():
            try:
                result = roblox.execute_luau(code, datamodel_type, timeout_seconds, use_helpers, snapshot_paths)
            except Exception as exc:
                roblox.record_event("error", "execute_luau", {"path":",".join(snapshot_paths or [])}, str(exc))
                raise
            try: snapshot_id = json.loads(result).get("snapshotId")
            except (json.JSONDecodeError, AttributeError): snapshot_id = None
            roblox.record_event("change", "execute_luau", {"path":",".join(snapshot_paths or [])}, "Luau executed; source omitted from local memory", snapshot_id)
        return result

    @mcp.tool()
    def roblox_workflow(category: Literal["general", "build", "scripting", "ui", "vfx", "gameplay", "debug"]) -> str:
        """Get Brickwire's Roblox-specific workflow guidance for a task category; no chat-site or browser support is included."""
        if category not in WORKFLOWS:
            raise ValueError("Unknown Roblox workflow category")
        return WORKFLOWS[category]

    @mcp.tool()
    def roblox_project_memory(action: Literal["get", "note"], category: str = "note", text: str = "", path: str = "") -> str:
        """Read or save per-place Roblox project notes (important scripts/GUIs, systems, dependencies, preferences). Stored locally beside the bridge, not in Roblox cloud."""
        return roblox.project_memory(action, category, text, path)

    @mcp.tool()
    def use_powershell(command: str, timeout_seconds: int = 60) -> str:
        """Run one allow-listed PowerShell command from the selected project folder. Keep Notion confirmation enabled; this is not an OS sandbox."""
        return run_command(files.root, "powershell", command, timeout_seconds)

    @mcp.tool()
    def use_cmd(command: str, timeout_seconds: int = 60) -> str:
        """Run one allow-listed CMD command from the selected project folder. Keep Notion confirmation enabled; this is not an OS sandbox."""
        return run_command(files.root, "cmd", command, timeout_seconds)

    if config.get("allow_full_shell"):
        @mcp.tool()
        def run_shell(command: str, shell: Literal["powershell", "cmd"] = "powershell", cwd: str = ".", timeout_seconds: int = 120) -> str:
            """Run any shell command (pipes, chaining, redirection, scripts, npm/npx/node/pip/python/git) with cwd as a relative folder inside the approved folder; timeout up to 1800 s. Not a sandbox: keep Notion confirmation enabled. For servers that must keep running, start them detached (cmd: start \"\" ...; PowerShell: Start-Process)."""
            return run_full_shell(files.root, shell, command, timeout_seconds, cwd)

    async def direct_response(fn, *args):
        try:
            return JSONResponse(await run_in_threadpool(fn, *args))
        except PermissionError as exc:
            return JSONResponse({"error": str(exc)}, status_code=403)
        except ValueError as exc:
            return JSONResponse({"error": str(exc)}, status_code=400)
        except RuntimeError as exc:
            return JSONResponse({"error": str(exc)}, status_code=409)
        except Exception as exc:
            return JSONResponse({"error": str(exc)}, status_code=500)

    async def direct_start(request: Request):
        body = await request.json()
        return await direct_response(direct_agent.start, body.get("agent_id"), body.get("provider"), body.get("task"))

    async def direct_tool(request: Request):
        body = await request.json()
        return await direct_response(direct_agent.call, body.get("session_id"), body.get("agent_id"), body.get("tool"), body.get("arguments"), body.get("approved", False))

    async def direct_heartbeat(request: Request):
        body = await request.json()
        return await direct_response(direct_agent.heartbeat, body.get("session_id"), body.get("agent_id"))

    async def direct_stop(request: Request):
        body = await request.json()
        return await direct_response(direct_agent.stop, body.get("session_id"), body.get("agent_id"))

    # This server is intentionally bound to loopback. The tunnel provides HTTPS
    # externally; MCP and direct-agent calls each use their own random bearer token.
    app = mcp.streamable_http_app()
    app.state.browser_extension = extension
    app.state.direct_agent = direct_agent
    app.routes.append(WebSocketRoute("/extension/ws", extension.websocket))
    app.routes.extend([
        Route("/direct-agent/start", direct_start, methods=["POST"]),
        Route("/direct-agent/tool", direct_tool, methods=["POST"]),
        Route("/direct-agent/heartbeat", direct_heartbeat, methods=["POST"]),
        Route("/direct-agent/stop", direct_stop, methods=["POST"]),
    ])
    return BearerAuth(HTTPStatusDiagnostics(app), token, extension_token)


if __name__ == "__main__":
    main()
