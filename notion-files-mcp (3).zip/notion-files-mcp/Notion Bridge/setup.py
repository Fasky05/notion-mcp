from __future__ import annotations

import json
import secrets
import sys
from pathlib import Path
from tkinter import Tk, filedialog, messagebox


HERE = Path(__file__).resolve().parent


def main() -> None:
    if sys.version_info < (3, 11):
        raise SystemExit("Python 3.11 or later is required. Install it from python.org and try again.")
    root = Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    folder = filedialog.askdirectory(title="Choose the folder the Notion Agent may access")
    root.destroy()
    if not folder:
        print("No folder selected. Setup cancelled.")
        return

    config = {
        "root_directory": str(Path(folder).resolve()),
        "port": 8765,
        "bearer_token": secrets.token_urlsafe(40),
        "web_extension_token": secrets.token_urlsafe(40),
        "mcp_servers": {
            "roblox": {"type": "roblox_studio", "enabled": True},
            "websites": {"type": "browser_extension", "enabled": True},
        },
    }
    config_path = HERE / "config.json"
    config_path.write_text(json.dumps(config, indent=2), encoding="utf-8")
    try:
        config_path.chmod(0o600)
    except OSError:
        pass
    print("Setup complete.")
    print(f"Approved folder: {config['root_directory']}")
    print("Private MCP and Chrome extension tokens are saved in config.json in this folder.")
    print("Do not share config.json. Use bearer_token in Notion and web_extension_token in the Chrome extension options.")
    try:
        root = Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        messagebox.showinfo(
            "Setup complete",
            "Folder, Roblox and websites MCP tools are configured.\n\nFrom the all-in-one ZIP, load Notion Bridge/extension in Chrome at chrome://extensions, then paste web_extension_token from Notion Bridge/config.json into the extension options. In each AI chat tab, choose Activer cet agent in the extension menu before using web_agents from Notion or launching a direct Roblox agent.\n\nFor direct mode, open a place in Roblox Studio and enable Assistant Settings > MCP Servers > Enable Studio as MCP server. Launching directly requires the local bridge and asks for approval before every Studio write. Only one agent can write to Studio at a time; overlapping Notion writes are rejected during a direct session, and direct sessions are rejected while a Notion write is in progress. Keep Notion Always ask enabled for mcp_call and all Notion-driven changes. Start the bridge with Start Notion Bridge.bat at the ZIP root.",
        )
        root.destroy()
    except Exception:
        pass


if __name__ == "__main__":
    main()
