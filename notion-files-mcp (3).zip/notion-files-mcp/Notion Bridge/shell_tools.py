from __future__ import annotations

import os
import shutil
import subprocess
import tempfile
from pathlib import Path

from command_tools import _trim_output

MAX_COMMAND_LENGTH = 20000


def run_shell(root: str | Path, shell: str, command: str, timeout_seconds: int = 120, cwd: str = ".") -> str:
    """Run a full shell command (pipes, chaining, redirection, scripts, npm/npx/pip/git allowed).

    The working directory is always inside the selected root folder. This is NOT a sandbox:
    it is only enabled when config.json has "allow_full_shell": true.
    """
    if os.name != "nt":
        raise RuntimeError("The shell tool is available only on Windows")
    shell = str(shell or "").lower().strip()
    if shell not in ("powershell", "cmd"):
        raise ValueError("Shell must be powershell or cmd")
    command = str(command or "").strip()
    if not command or len(command) > MAX_COMMAND_LENGTH:
        raise ValueError(f"Provide a command of at most {MAX_COMMAND_LENGTH} characters")
    root = Path(root).resolve(strict=True)
    rel = str(cwd or ".").replace("\\", "/")
    if Path(rel).is_absolute() or ".." in Path(rel).parts:
        raise ValueError("cwd must be a relative folder inside the selected folder")
    workdir = (root / rel).resolve(strict=True)
    if not workdir.is_relative_to(root) or not workdir.is_dir():
        raise ValueError("cwd must be an existing folder inside the selected folder")
    timeout = max(5, min(int(timeout_seconds), 1800))
    if shell == "powershell":
        executable = shutil.which("powershell.exe") or shutil.which("pwsh.exe")
        if not executable:
            raise RuntimeError("PowerShell was not found on this computer")
        argv = [executable, "-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", command]
    else:
        executable = shutil.which("cmd.exe")
        if not executable:
            raise RuntimeError("CMD was not found on this computer")
        argv = [executable, "/d", "/s", "/c", command]
    env = dict(os.environ)
    env["GIT_TERMINAL_PROMPT"] = "0"
    env["npm_config_yes"] = "true"
    env["PIP_NO_INPUT"] = "1"
    with tempfile.TemporaryFile() as stdout_file, tempfile.TemporaryFile() as stderr_file:
        process = subprocess.Popen(
            argv, cwd=str(workdir), env=env, stdin=subprocess.DEVNULL,
            stdout=stdout_file, stderr=stderr_file,
            creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
        )
        timed_out = False
        try:
            process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(process.pid)], stdin=subprocess.DEVNULL,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10, check=False)
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        stdout_file.seek(0)
        stderr_file.seek(0)
        stdout = stdout_file.read().decode("utf-8", errors="replace")
        stderr = stderr_file.read().decode("utf-8", errors="replace")
    status = "timed out" if timed_out else f"exit code {process.returncode}"
    result = [f"Working directory: {workdir.relative_to(root).as_posix() or '.'}", f"Command status: {status}"]
    if stdout.strip():
        result.extend(["stdout:", _trim_output(stdout)])
    if stderr.strip():
        result.extend(["stderr:", _trim_output(stderr)])
    if not stdout.strip() and not stderr.strip():
        result.append("(no output)")
    return "\n".join(result)
