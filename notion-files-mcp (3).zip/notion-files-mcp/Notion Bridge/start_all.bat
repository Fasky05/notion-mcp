@echo off
setlocal
cd /d "%~dp0"
title Notion + Roblox Bridge
set "SETUP_LOG=%TEMP%\notion-bridge-setup.log"
type nul >"%SETUP_LOG%"
echo ==========================================================
echo   NOTION + ROBLOX BRIDGE
echo ==========================================================
echo This window will show setup steps and the one URL to copy.
echo Keep this window open while using the bridge.
echo.

echo STEP 1 OF 4 - Preparing the bridge
echo Checking for Python 3.11 or newer...
where py >nul 2>nul
if not errorlevel 1 (
  set "PY=py -3"
) else (
  where python >nul 2>nul
  if errorlevel 1 goto no_python
  set "PY=python"
)
%PY% -c "import sys; raise SystemExit(0 if sys.version_info >= (3,11) else 1)"
if errorlevel 1 goto old_python

if not exist ".venv\Scripts\python.exe" (
  echo Creating its private Python environment...
  %PY% -m venv .venv >>"%SETUP_LOG%" 2>&1
  if errorlevel 1 goto setup_failed
)

echo Checking the required components...
".venv\Scripts\python.exe" -c "import mcp, uvicorn"
if errorlevel 1 (
  echo Installing the required components. This may take a few minutes...
  ".venv\Scripts\python.exe" -m pip install -q -r requirements.txt >>"%SETUP_LOG%" 2>&1
  if errorlevel 1 goto setup_failed
)

if not exist "config.json" (
  echo.
  echo STEP 2 OF 4 - Choose your project folder
  echo A folder picker will open. Choose the folder Notion may access.
  ".venv\Scripts\python.exe" setup.py
  if errorlevel 1 goto setup_failed
)
if not exist "config.json" goto setup_cancelled

echo.
echo STEP 3 OF 4 - Secure connection
if exist "tunnel_provider.txt" (
  set /p TUNNEL_PROVIDER=<"tunnel_provider.txt"
) else (
  set "TUNNEL_PROVIDER=tailscale"
)
if /i "%TUNNEL_PROVIDER%"=="cloudflare" goto check_cloudflare
where tailscale.exe >nul 2>nul
if errorlevel 1 if not exist "%ProgramFiles%\Tailscale\tailscale.exe" if not exist "%ProgramFiles(x86)%\Tailscale\tailscale.exe" goto tailscale_missing
goto tunnel_ready

:check_cloudflare
where cloudflared.exe >nul 2>nul
if errorlevel 1 if not exist "%ProgramFiles%\cloudflared\cloudflared.exe" if not exist "%ProgramFiles(x86)%\cloudflared\cloudflared.exe" goto cloudflared_missing
".venv\Scripts\python.exe" -c "from pathlib import Path; import os; tid='c6e598fc-5e18-43f3-8c74-27cdc02e4283'; p=Path.home()/'.cloudflared'/(tid+'.json'); raise SystemExit(0 if p.is_file() else 1)"
if errorlevel 1 goto cloudflare_credentials_missing

goto tunnel_ready

:tunnel_ready

echo.
echo STEP 4 OF 4 - Starting the local bridge
echo Closing any old bridge and tunnel still using port 8765...
powershell -NoProfile -Command "$ids = @(); $ids += Get-NetTCPConnection -LocalPort 8765 -State Listen -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess; $ids += Get-NetTCPConnection -RemotePort 8765 -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess; $ids | Where-Object { $_ -and $_ -ne $PID -and $_ -ne 0 } | Sort-Object -Unique | ForEach-Object { Write-Host ('  stopping old process ' + $_); Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }"
set "PORT_FREE="
for /l %%I in (1,1,15) do (
  powershell -NoProfile -Command "$c=New-Object Net.Sockets.TcpClient; try{$c.Connect('127.0.0.1',8765);exit 1}catch{exit 0}finally{$c.Close()}" >nul 2>nul
  if not errorlevel 1 set "PORT_FREE=1"
  if defined PORT_FREE goto port_free
  timeout /t 1 >nul
)
echo Port 8765 is still in use by another program. Close it in Task Manager and run this file again.
pause
exit /b 1

:port_free
echo The bridge runs in a minimized window. Leave it open.
start "Notion Bridge - leave open" /min /D "%CD%" "%ComSpec%" /k ""%CD%\.venv\Scripts\python.exe" "%CD%\server.py""

echo Waiting for the bridge to be ready...
set "PORT_READY="
for /l %%I in (1,1,30) do (
  powershell -NoProfile -Command "$c=New-Object Net.Sockets.TcpClient; try{$c.Connect('127.0.0.1',8765);exit 0}catch{exit 1}finally{$c.Close()}" >nul 2>nul
  if not errorlevel 1 set "PORT_READY=1"
  if defined PORT_READY goto start_tunnel
  timeout /t 1 >nul
)
echo The local bridge did not start. Check the minimized Notion Bridge window.
pause
exit /b 1

:start_tunnel
echo.
echo Starting a secure connection with Tailscale Funnel.
echo.
".venv\Scripts\python.exe" run_tunnel.py

:tunnel_ended
if errorlevel 1 echo The secure connection did not start. Check the message above and try again.
echo.
echo To stop the bridge too, close the minimized "Notion Bridge - leave open" window.
pause
exit /b 0

:no_python
echo Python 3.11 or newer is required. Install it from https://www.python.org/downloads/ and run this file again.
start "" "https://www.python.org/downloads/"
pause
exit /b 1

:old_python
echo Python 3.11 or newer is required. Install a newer version and run this file again.
start "" "https://www.python.org/downloads/"
pause
exit /b 1

:setup_failed
echo Setup could not finish. Check your internet connection, then run this file again.
echo If it keeps failing, setup details are in: %SETUP_LOG%
pause
exit /b 1

:setup_cancelled
echo Setup was cancelled or no project folder was selected.
pause
exit /b 1

:tailscale_missing
echo Tailscale is required. Install it from https://tailscale.com/download and sign in, then run this file again.
start "" "https://tailscale.com/download"
pause
exit /b 1

:cloudflared_missing
echo cloudflared is required for the selected Cloudflare tunnel. Install it from https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/.
start "" "https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/"
pause
exit /b 1

:cloudflare_credentials_missing
echo The existing Cloudflare tunnel credentials are missing from %%USERPROFILE%%\.cloudflared.
echo Restore the credentials or configure a new named tunnel before starting the bridge.
pause
exit /b 1
