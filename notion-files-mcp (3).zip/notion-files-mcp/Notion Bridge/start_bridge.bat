@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo First run Start Notion Bridge.bat.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" server.py
pause
