@echo off
setlocal
cd /d "%~dp0"
where tailscale.exe >nul 2>nul
if errorlevel 1 if not exist "%ProgramFiles%\Tailscale\tailscale.exe" if not exist "%ProgramFiles(x86)%\Tailscale\tailscale.exe" (
  echo Tailscale is not installed or not on PATH. Install it from https://tailscale.com/download.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo First run Start Notion Bridge.bat to prepare the local components.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" run_tunnel.py
pause
