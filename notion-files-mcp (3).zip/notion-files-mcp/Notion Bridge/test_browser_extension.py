import json
import queue
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from starlette.testclient import TestClient
from starlette.websockets import WebSocketDisconnect

from browser_extension import BrowserExtensionBroker, BrowserExtensionMCPClient, SITE_PROVIDERS, TOOL_DEFINITIONS
from mcp_router import MCPRegistry
from server import build_app


class BrowserExtensionTests(unittest.TestCase):
    def test_provider_catalogue_matches_brickwire_websites(self):
        ids = {provider["id"] for provider in SITE_PROVIDERS}
        self.assertEqual(ids, {"deepseek", "chatgpt", "claude", "gemini", "qwen", "kimi", "glm", "arena", "notion"})
        notion = next(provider for provider in SITE_PROVIDERS if provider["id"] == "notion")
        self.assertFalse(notion["enabledByDefault"])
        manifest = json.loads((Path(__file__).parent / "extension" / "manifest.json").read_text(encoding="utf-8"))
        patterns = {pattern.removeprefix("https://").removesuffix("/*") for pattern in manifest["content_scripts"][0]["matches"]}
        self.assertTrue({host for provider in SITE_PROVIDERS for host in provider["hosts"]} <= patterns)

    def test_web_sites_works_without_extension_and_web_chat_validates(self):
        broker = BrowserExtensionBroker("token")
        client = BrowserExtensionMCPClient(broker)
        sites = json.loads(client.call_tool("web_sites", {}, 10)["content"][0]["text"])
        self.assertFalse(sites["extensionConnected"])
        self.assertEqual(len(sites["providers"]), 9)
        with self.assertRaisesRegex(ValueError, "non-empty text"):
            broker.call("web_chat", {"action":"send","text":" "}, 10)
        with self.assertRaisesRegex(ValueError, "wait_seconds"):
            broker.call("web_chat", {"action":"wait","wait_seconds":200}, 10)
        with self.assertRaisesRegex(RuntimeError, "not connected"):
            broker.call("web_chat", {"action":"inspect"}, 10)
        with self.assertRaisesRegex(ValueError, "agent_id is required"):
            broker.call("web_agents", {"action":"inspect"}, 10)
        with self.assertRaisesRegex(ValueError, "non-empty task"):
            broker.call("web_agents", {"action":"run","agent_id":"agent-12","task":" "}, 10)

    def test_web_agents_routes_selected_tab_and_lists_agents(self):
        broker = BrowserExtensionBroker("token")
        requests = queue.Queue()
        broker.attach(requests.put)
        with ThreadPoolExecutor(max_workers=1) as pool:
            pending = pool.submit(broker.call, "web_agents", {"action":"run","agent_id":"agent-12","task":"Review this"}, 10)
            request = requests.get(timeout=2)
            self.assertEqual(request["arguments"]["agent_id"], "agent-12")
            self.assertEqual(request["arguments"]["task"], "Review this")
            broker.respond({"type":"response","id":request["id"],"result":{"site":"deepseek","text":"Reviewed"}})
            self.assertEqual(pending.result(timeout=2), {"site":"deepseek","text":"Reviewed"})
        self.assertIn("web_agents", {tool["name"] for tool in TOOL_DEFINITIONS})

    def test_broker_routes_tool_request_and_returns_extension_result(self):
        with tempfile.TemporaryDirectory() as folder:
            broker = BrowserExtensionBroker("token")
            requests = queue.Queue()
            broker.attach(requests.put)
            registry = MCPRegistry(folder, {"websites":{"type":"browser_extension"}}, browser_extension=broker)
            try:
                registry.list_tools("websites")
                with ThreadPoolExecutor(max_workers=1) as pool:
                    pending = pool.submit(registry.call_tool, "websites", "web_chat", {"action":"inspect"}, 10)
                    request = requests.get(timeout=2)
                    broker.respond({"type":"response","id":request["id"],"result":{"site":"deepseek","composer":True}})
                    result = json.loads(pending.result(timeout=2))
                self.assertEqual(json.loads(result["content"][0]["text"]), {"site":"deepseek","composer":True})
            finally:
                registry.close()

    def test_authenticated_extension_websocket_and_mcp_catalogue(self):
        with tempfile.TemporaryDirectory() as folder:
            config = {
                "root_directory":folder,
                "bearer_token":"mcp-secret",
                "web_extension_token":"extension-secret",
                "mcp_servers":{"websites":{"type":"browser_extension","enabled":True}},
            }
            app = build_app(config)
            with TestClient(app) as client:
                headers = {
                    "Authorization":"Bearer mcp-secret",
                    "Accept":"application/json, text/event-stream",
                    "MCP-Protocol-Version":"2025-03-26",
                }
                self.assertEqual(client.post("/direct-agent/start",json={},headers={"Authorization":"Bearer mcp-secret"}).status_code,401)
                direct = client.post("/direct-agent/start",json={},headers={"Authorization":"Bearer extension-secret"})
                self.assertEqual(direct.status_code,400,direct.text)
                with client.websocket_connect("/extension/ws") as socket:
                    socket.send_json({"type":"hello","token":"extension-secret"})
                    self.assertEqual(socket.receive_json()["type"], "ready")
                    discovery = client.post("/mcp", json={"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"mcp_list_tools","arguments":{"server_id":"websites"}}}, headers=headers)
                    self.assertEqual(discovery.status_code, 200, discovery.text)
                    self.assertIn("web_chat", discovery.text)
                    self.assertIn("web_agents", discovery.text)
                    broker = app.app.state.browser_extension
                    with ThreadPoolExecutor(max_workers=1) as pool:
                        pending = pool.submit(broker.call, "web_chat", {"action":"inspect"}, 10)
                        request = socket.receive_json()
                        self.assertEqual(request["tool"], "web_chat")
                        socket.send_json({"type":"response","id":request["id"],"result":{"site":"deepseek","composer":True}})
                        self.assertEqual(pending.result(timeout=3), {"site":"deepseek","composer":True})
                with self.assertRaises(WebSocketDisconnect):
                    with client.websocket_connect("/extension/ws") as socket:
                        socket.send_json({"type":"hello","token":"wrong-token"})
                        socket.receive_json()


if __name__ == "__main__":
    unittest.main()
