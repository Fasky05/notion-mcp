from pathlib import Path

from server import CODEBASE_MEMORY_EXE, CODEBASE_MEMORY_ID, add_codebase_memory


def test_codebase_memory_registered_when_binary_exists(tmp_path: Path):
    exe = tmp_path / CODEBASE_MEMORY_EXE
    exe.parent.mkdir(parents=True)
    exe.write_bytes(b"")
    servers = add_codebase_memory({"websites": {"type": "browser_extension"}}, tmp_path)
    entry = servers[CODEBASE_MEMORY_ID]
    assert entry["type"] == "stdio"
    assert entry["command"] == CODEBASE_MEMORY_EXE
    assert entry["args"] == [] and entry["cwd"] == "."


def test_codebase_memory_skipped_without_binary(tmp_path: Path):
    assert CODEBASE_MEMORY_ID not in add_codebase_memory({}, tmp_path)


def test_codebase_memory_user_config_wins(tmp_path: Path):
    exe = tmp_path / CODEBASE_MEMORY_EXE
    exe.parent.mkdir(parents=True)
    exe.write_bytes(b"")
    servers = add_codebase_memory({CODEBASE_MEMORY_ID: {"enabled": False}}, tmp_path)
    assert servers[CODEBASE_MEMORY_ID] == {"enabled": False}
