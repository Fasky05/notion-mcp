import unittest

from command_tools import validate_command


class CommandValidationTests(unittest.TestCase):
    def test_allows_approved_node_git_diagnostics_and_tools(self):
        allowed = [
            ("cmd", "node rbx-proxy/node_modules/typescript/bin/tsc --noEmit"),
            ("powershell", "node rbx-proxy/node_modules/tsx/dist/cli.mjs --test"),
            ("cmd", 'git -C rbx-proxy/mirror init'),
            ("cmd", 'git -C rbx-proxy/mirror add .'),
            ("cmd", 'git -C rbx-proxy/mirror add --all'),
            ("powershell", 'git -C rbx-proxy/mirror commit -m "phase two"'),
            ("cmd", "git -C rbx-proxy/mirror status --short"),
            ("cmd", "git -C rbx-proxy/mirror diff --cached"),
            ("cmd", "git -C rbx-proxy/mirror log --oneline"),
            ("cmd", "git -C rbx-proxy/mirror show --stat"),
            ("cmd", "git -C rbx-proxy/mirror rev-parse --verify HEAD"),
            ("cmd", 'git -C rbx-proxy/mirror config user.name "Example User"'),
            ("cmd", 'git -C rbx-proxy/mirror config --local user.name "Example User"'),
            ("cmd", "git -C rbx-proxy/mirror config user.email person@example.com"),
            ("cmd", "git -C rbx-proxy/mirror restore -- src\\main.luau"),
            ("cmd", 'tasklist /FI "IMAGENAME eq StudioMCP.exe"'),
            ("powershell", 'tasklist.exe /FI "IMAGENAME eq RobloxStudioBeta.exe"'),
            ("cmd", "netstat -ano"),
            ("cmd", "where anything-at-all"),
            ("cmd", "where /R rbx-proxy node.exe"),
            ("cmd", "mkdir tests"),
            ("powershell", r".\bin\stylua\stylua.exe src\main.luau"),
            ("cmd", r".\bin\selene\selene.exe src\main.lua"),
            ("cmd", r".\bin\luau-lsp\luau-lsp.exe analyze src\main.luau"),
            ("cmd", r".\bin\cbm\codebase-memory-mcp.exe --version"),
            ("cmd", r".\bin\cbm\codebase-memory-mcp.exe src\main.luau"),
            ("cmd", r".\bin\ast-grep\ast-grep.exe --version"),
            ("cmd", r".\bin\ast-grep\ast-grep.exe run --pattern console.log --lang js src"),
            ("powershell", r".\bin\ast-grep\ast-grep.exe scan --rule rules\x.yml src"),
            ("cmd", "npm test"),
            ("cmd", "npm --prefix rbx-proxy run build"),
            ("powershell", "Get-ChildItem rbx-proxy"),
        ]
        for shell, command in allowed:
            with self.subTest(shell=shell, command=command):
                self.assertEqual(validate_command(shell, command)[1], command)

    def test_blocks_network_install_and_repository_remote_commands(self):
        blocked = [
            ("cmd", "curl.exe -L -o app.zip https://github.com/a/b/releases/latest"),
            ("powershell", "Invoke-WebRequest https://github.com/a/b"),
            ("powershell", "Invoke-RestMethod https://github.com/a/b"),
            ("cmd", "bitsadmin /transfer job https://github.com/a/b"),
            ("cmd", "git -C rbx-proxy/mirror clone https://github.com/a/b"),
            ("cmd", "git -C rbx-proxy/mirror fetch"),
            ("cmd", "git -C rbx-proxy/mirror pull"),
            ("cmd", "git -C rbx-proxy/mirror push"),
            ("cmd", "git -C rbx-proxy/mirror remote add origin https://github.com/a/b"),
            ("cmd", "npm install better-sqlite3"),
            ("cmd", "npm ci"),
            ("cmd", "npm exec untrusted-package"),
            ("cmd", "npx tool"),
        ]
        for shell, command in blocked:
            with self.subTest(shell=shell, command=command), self.assertRaises(ValueError):
                validate_command(shell, command)

    def test_blocks_node_escape_and_unapproved_launchers(self):
        blocked = [
            ("cmd", 'node -e "console.log(process.env)"'),
            ("cmd", "node arbitrary-script.js"),
            ("cmd", "node rbx-proxy/src/server.ts"),
            ("cmd", "node rbx-proxy/node_modules/tsx/dist/cli.mjs ..\\outside.ts"),
            ("cmd", "cmd /c whoami"),
            ("cmd", "powershell -Command Get-Process"),
            ("cmd", "pwsh -Command Get-Process"),
            ("cmd", "start app.exe"),
            ("cmd", "call setup.bat"),
            ("cmd", "wscript script.vbs"),
            ("cmd", "cscript script.vbs"),
            ("cmd", "mshta payload"),
            ("cmd", "rundll32 payload"),
        ]
        for shell, command in blocked:
            with self.subTest(shell=shell, command=command), self.assertRaises(ValueError):
                validate_command(shell, command)

    def test_blocks_deletion_process_and_system_commands(self):
        blocked_names = [
            "del x", "erase x", "rmdir x", "rd x", "Remove-Item x", "rm x",
            "taskkill /F /IM StudioMCP.exe", "Stop-Process -Name StudioMCP",
            "reg query HKCU", "schtasks /Query", "sc query", "setx A B",
            "icacls x", "takeown /F x", "runas /user:x app", "net user",
            "wmic process list", "Expand-Archive file.zip",
        ]
        for command in blocked_names:
            with self.subTest(command=command), self.assertRaises(ValueError):
                validate_command("cmd", command)

    def test_scopes_git_and_local_tools_to_exact_arguments(self):
        blocked = [
            "git status",
            "git -C other status",
            "git -C rbx-proxy/mirror clone url",
            "git -C rbx-proxy/mirror config --global user.name Alice",
            "git -C rbx-proxy/mirror restore -- README.md",
            "git -C rbx-proxy/mirror restore -- src\\*.luau",
            "git -C rbx-proxy/mirror restore -- ..\\outside.luau",
            "git -C rbx-proxy/mirror commit --amend",
            "git -C rbx-proxy/mirror init --template=other",
            "stylua.exe --version",
            r".\bin\stylua\stylua.exe --config-path arbitrary.toml",
            r".\bin\luau-lsp\luau-lsp.exe check src\main.luau",
            r".\bin\cbm\codebase-memory-mcp.exe src\main.luau src\other.luau",
            r".\bin\ast-grep\ast-grep.exe run --pattern x --lang js --rewrite y src",
            r".\bin\ast-grep\ast-grep.exe run src",
            r".\bin\ast-grep\ast-grep.exe run --pattern x --update-all src",
            r".\bin\ast-grep\ast-grep.exe new",
            "ast-grep.exe --version",
            "tasklist",
            'tasklist /FI "IMAGENAME eq chrome.exe"',
            "tasklist /S another-computer",
            "netstat -ab",
            "where C:\\Windows",
            "python --version",
            "cargo check",
            "rojo build",
        ]
        for command in blocked:
            with self.subTest(command=command), self.assertRaises(ValueError):
                validate_command("cmd", command)

    def test_rejects_shell_composition_and_rooted_paths(self):
        for shell, command in [
            ("cmd", "dir & del file.txt"),
            ("powershell", "Get-ChildItem; Remove-Item file.txt"),
            ("cmd", "type ..\\private.txt"),
            ("powershell", "Get-Content C:\\Users\\private.txt"),
            ("cmd", "type \\Windows\\win.ini"),
            ("powershell", "Get-Content .env.local"),
        ]:
            with self.subTest(shell=shell, command=command), self.assertRaises(ValueError):
                validate_command(shell, command)


if __name__ == "__main__":
    unittest.main()
