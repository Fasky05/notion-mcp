import json
import time
import unittest

from direct_agent import DirectAgentService, StudioWriterCoordinator


class FakeRoblox:
    def __init__(self):
        self.calls = []
        self.events = []
        self.tools = [
            {"name":"get_game_tree","description":"Read the instance tree","inputSchema":{"type":"object","properties":{"path":{"type":"string"}}}},
            {"name":"create_instance","description":"Create an instance","inputSchema":{"type":"object","properties":{"name":{"type":"string"}}}},
        ]

    def native_tools(self, offset=0, limit=50):
        return json.dumps({"tools":self.tools[offset:offset + limit]})

    def run_action(self, action, arguments, timeout):
        self.calls.append(("studio",action,arguments,timeout))
        return json.dumps({"ok":True,"snapshotId":"snap-1"})

    def native_call(self, name, arguments, timeout):
        self.calls.append(("native",name,arguments,timeout))
        return json.dumps({"ok":True,"snapshotId":"snap-native"})

    def execute_luau(self, code, datamodel, timeout, helpers, paths):
        self.calls.append(("luau",code,datamodel,timeout,helpers,paths))
        return json.dumps({"ok":True})

    def record_event(self, *args, **kwargs):
        self.events.append((args,kwargs))


class DirectAgentTests(unittest.TestCase):
    def setUp(self):
        self.roblox = FakeRoblox()
        self.writer = StudioWriterCoordinator()
        self.service = DirectAgentService(self.roblox,self.writer)
        self.session = self.service.start("agent-17","deepseek","Build a small test part")

    def tearDown(self):
        self.service.stop(self.session["session_id"],"agent-17")

    def call(self, tool, arguments, approved=False):
        return self.service.call(self.session["session_id"],"agent-17",tool,arguments,approved)

    def test_session_reserves_studio_until_stop(self):
        with self.assertRaisesRegex(RuntimeError,"reserved by a direct agent"):
            with self.writer.notion_write():
                self.fail("Notion acquired the reserved Studio writer")
        self.assertTrue(self.service.stop(self.session["session_id"],"agent-17")["ok"])
        with self.writer.notion_write():
            pass

    def test_start_requires_a_numeric_tab_agent_id(self):
        with self.assertRaisesRegex(ValueError,"registered page agent"):
            self.service.start("agent-not-a-tab","deepseek","Do something")

    def test_read_tool_runs_without_approval_and_write_requires_it(self):
        result = self.call("roblox_studio",{"action":"get_game_tree","arguments":{"path":"game.Workspace"}})
        self.assertEqual(result["risk"],"read")
        with self.assertRaises(PermissionError):
            self.call("roblox_studio",{"action":"create_part","arguments":{"name":"Test"}})
        self.assertEqual(len(self.roblox.calls),1)
        changed = self.call("roblox_studio",{"action":"create_part","arguments":{"name":"Test"}},approved=True)
        self.assertEqual(changed["risk"],"write")
        self.assertEqual(len(self.roblox.events),1)

    def test_native_tools_are_allowlisted_and_mutations_are_gated(self):
        with self.assertRaisesRegex(ValueError,"unavailable"):
            self.call("roblox_native_call",{"tool_name":"not_advertised","arguments":{}},approved=True)
        with self.assertRaises(PermissionError):
            self.call("roblox_native_call",{"tool_name":"create_instance","arguments":{}})
        result = self.call("roblox_native_call",{"tool_name":"create_instance","arguments":{"name":"Test"}},approved=True)
        self.assertEqual(result["risk"],"write")

    def test_malformed_nested_arguments_are_rejected(self):
        with self.assertRaisesRegex(ValueError,"arguments must be an object"):
            self.call("roblox_studio",{"action":"create_part","arguments":[]},approved=True)

    def test_expired_session_releases_writer(self):
        self.service._session["last_activity"] = time.time() - 1900
        with self.assertRaisesRegex(RuntimeError,"expired"):
            self.service.heartbeat(self.session["session_id"],"agent-17")
        with self.writer.notion_write():
            pass


if __name__ == "__main__":
    unittest.main()
