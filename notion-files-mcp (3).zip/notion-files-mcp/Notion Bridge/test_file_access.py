import hashlib
import tempfile
import unittest
from pathlib import Path

from file_access import WorkspaceFiles


class WorkspaceFilesTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        (self.root / "sub").mkdir()
        (self.root / "sub" / "note.txt").write_text("Alpha needle\nsecond line\n", encoding="utf-8")
        (self.root / ".git").mkdir()
        (self.root / ".git" / "config").write_text("private", encoding="utf-8")
        (self.root / ".env").write_text("SECRET=hidden", encoding="utf-8")
        self.files = WorkspaceFiles(self.root)

    def tearDown(self):
        self.temp.cleanup()

    def test_rejects_parent_traversal_and_absolute_paths(self):
        with self.assertRaises(ValueError):
            self.files.read_file("../outside.txt")
        with self.assertRaises(ValueError):
            self.files.read_file(str(self.root / "sub" / "note.txt"))

    def test_blocks_secret_files_and_hides_them_from_listing(self):
        with self.assertRaises(ValueError):
            self.files.read_file(".env")
        with self.assertRaises(ValueError):
            self.files.read_file(".git/config")
        self.assertNotIn(".env", self.files.list_files(recursive=True))

    def test_rejects_symlink_escape(self):
        outside = Path(self.temp.name).parent / f"{Path(self.temp.name).name}-outside.txt"
        outside.write_text("outside", encoding="utf-8")
        link = self.root / "sub" / "outside-link.txt"
        try:
            link.symlink_to(outside)
        except (OSError, NotImplementedError):
            outside.unlink(missing_ok=True)
            self.skipTest("Symbolic links are not supported here")
        try:
            with self.assertRaises(ValueError):
                self.files.read_file("sub/outside-link.txt")
        finally:
            outside.unlink(missing_ok=True)

    def test_lists_reads_and_searches_relative_to_root(self):
        self.assertIn("sub/note.txt", self.files.list_files(recursive=True))
        self.assertIn("sha256:", self.files.read_file("sub/note.txt"))
        self.assertIn("sub/note.txt:1", self.files.search_files("needle"))

    def test_create_then_replace_requires_current_hash(self):
        path = "sub/new.txt"
        self.files.write_file(path, "first")
        digest = hashlib.sha256(b"first").hexdigest()
        with self.assertRaises(ValueError):
            self.files.write_file(path, "stale")
        with self.assertRaises(ValueError):
            self.files.write_file(path, "stale", "0" * 64)
        self.files.write_file(path, "updated", digest)
        self.assertIn("updated", self.files.read_file(path))


if __name__ == "__main__":
    unittest.main()
