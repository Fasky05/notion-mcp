import hashlib
import io
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

from file_access import WorkspaceFiles
from github_download import (
    MAX_DOWNLOAD_BYTES,
    _GitHubRedirectHandler,
    _extract_zip,
    _validate_github_url,
    download_github,
)


class FakeResponse:
    def __init__(self, data, url, content_length=None):
        self.stream = io.BytesIO(data)
        self.headers = {"Content-Length": str(content_length or len(data))}
        self.url = url

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        self.stream.close()

    def geturl(self):
        return self.url

    def read(self, size=-1):
        return self.stream.read(size)


class FakeOpener:
    def __init__(self, response):
        self.response = response

    def open(self, _request, timeout):
        self.timeout = timeout
        return self.response


class GitHubDownloadTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        (self.root / "rbx-proxy").mkdir()
        self.files = WorkspaceFiles(self.root)

    def tearDown(self):
        self.temp.cleanup()

    def test_only_https_github_hosts_and_redirects_are_allowed(self):
        self.assertEqual(
            _validate_github_url("https://github.com/acme/tool/archive/refs/heads/main.zip"),
            "https://github.com/acme/tool/archive/refs/heads/main.zip",
        )
        for url in [
            "http://github.com/acme/tool/file.zip",
            "https://github.com.evil.example/acme/tool/file.zip",
            "https://user:pass@github.com/acme/tool/file.zip",
            "https://example.com/acme/tool/file.zip",
        ]:
            with self.subTest(url=url), self.assertRaises(ValueError):
                _validate_github_url(url)
        request = type("Request", (), {"full_url": "https://github.com/acme/tool/file.zip"})()
        with self.assertRaises(ValueError):
            _GitHubRedirectHandler().redirect_request(
                request, None, 302, "Found", {}, "https://evil.example/file.zip"
            )

    def test_downloads_github_release_without_overwriting(self):
        url = "https://github.com/acme/tool/releases/download/v1/tool.exe"
        response = FakeResponse(b"release-binary", url)
        with patch("github_download.urllib.request.build_opener", return_value=FakeOpener(response)):
            result = download_github(self.files, url, "rbx-proxy/tool.exe")
        self.assertIn(hashlib.sha256(b"release-binary").hexdigest(), result)
        self.assertEqual((self.root / "rbx-proxy/tool.exe").read_bytes(), b"release-binary")
        with self.assertRaises(ValueError):
            download_github(self.files, url, "rbx-proxy/tool.exe")

    def test_rejects_declared_oversized_downloads(self):
        url = "https://github.com/acme/tool/releases/download/v1/tool.zip"
        response = FakeResponse(b"", url, content_length=MAX_DOWNLOAD_BYTES + 1)
        with patch("github_download.urllib.request.build_opener", return_value=FakeOpener(response)):
            with self.assertRaisesRegex(ValueError, "250 MB"):
                download_github(self.files, url, "rbx-proxy/tool.zip")

    def test_extracts_repo_zip_without_wrapper_folder(self):
        bundle = io.BytesIO()
        with zipfile.ZipFile(bundle, "w") as archive:
            archive.writestr("repo-main/", "")
            archive.writestr("repo-main/README.md", "repository source")
            archive.writestr("repo-main/src/main.luau", "print('hello')")
        url = "https://codeload.github.com/acme/repo/zip/refs/heads/main"
        response = FakeResponse(bundle.getvalue(), url)
        with patch("github_download.urllib.request.build_opener", return_value=FakeOpener(response)):
            result = download_github(self.files, url, "rbx-proxy/mirror", extract_zip=True)
        self.assertIn("Extracted 2 GitHub files", result)
        self.assertEqual((self.root / "rbx-proxy/mirror/README.md").read_text(), "repository source")
        self.assertEqual((self.root / "rbx-proxy/mirror/src/main.luau").read_text(), "print('hello')")

    def test_rejects_zip_traversal(self):
        bundle = io.BytesIO()
        with zipfile.ZipFile(bundle, "w") as archive:
            archive.writestr("../outside.txt", "bad")
        archive_path = self.root / "bad.zip"
        archive_path.write_bytes(bundle.getvalue())
        destination = self.root / "extracted"
        with self.assertRaisesRegex(ValueError, "unsafe path"):
            _extract_zip(archive_path, destination)
        self.assertFalse(destination.exists())
        self.assertFalse((self.root / "outside.txt").exists())


if __name__ == "__main__":
    unittest.main()
