import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

from mcp_router import MCPRegistry, find_studio_mcp


FAKE_MCP_SERVER = r'''import json
import sys

for line in sys.stdin:
    request = json.loads(line)
    method = request.get("method")
    if "id" not in request:
        continue
    if method == "initialize":
        result = {"protocolVersion": "2024-11-05", "capabilities": {}, "serverInfo": {"name": "fake", "version": "1"}}
    elif method == "tools/list":
        result = {"tools": [{"name": "echo", "description": "Return a value", "inputSchema": {"type": "object"}}]}
    elif method == "tools/call":
        text = request["params"]["arguments"].get("text", "")
        result = {"content": [{"type": "text", "text": text}]}
    else:
        result = {}
    print(json.dumps({"jsonrpc": "2.0", "id": request["id"], "result": result}), flush=True)
'''


class MCPRouterTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def test_generic_mcp_tools_are_discovered_and_called(self):
        script = self.root / "fake_mcp.py"
        script.write_text(FAKE_MCP_SERVER, encoding="utf-8")
        registry = MCPRegistry(self.root, {
            "sample": {"command": sys.executable, "args": ["-u", str(script)], "cwd": "."},
        })
        try:
            with self.assertRaisesRegex(ValueError, "Discover this tool first"):
                registry.call_tool("sample", "echo", {"text": "before-discovery"})
            tools = json.loads(registry.list_tools("sample"))["tools"]
            self.assertEqual(tools[0]["name"], "echo")
            with self.assertRaisesRegex(ValueError, "Discover this tool first"):
                registry.call_tool("sample", "not-listed", {})
            result = json.loads(registry.call_tool("sample", "echo", {"text": "hello"}))
            self.assertEqual(result["content"][0]["text"], "hello")
            self.assertEqual(json.loads(registry.list_tools("sample", offset=1))["tools"], [])
            self.assertIn('"process_running": true', registry.list_servers())
        finally:
            registry.close()

    def test_roblox_server_discovery_honors_override_and_latest_version(self):
        override = self.root / "custom" / "StudioMCP.exe"
        override.parent.mkdir()
        override.touch()
        self.assertEqual(find_studio_mcp({"ZS_STUDIO_MCP_PATH": str(override)}), override.resolve())

        local = self.root / "local" / "Roblox" / "Versions"
        old = local / "version-old"
        new = local / "version-new"
        old.mkdir(parents=True)
        new.mkdir()
        for folder in (old, new):
            (folder / "StudioMCP.exe").touch()
            (folder / "RobloxStudioBeta.exe").touch()
        os.utime(old / "StudioMCP.exe", (1, 1))
        os.utime(new / "StudioMCP.exe", (2, 2))
        self.assertEqual(
            find_studio_mcp({"LOCALAPPDATA": str(self.root / "local")}),
            (new / "StudioMCP.exe").resolve(),
        )

    def test_registry_defaults_to_roblox_and_rejects_escape_cwds(self):
        self.assertIn('"roblox"', MCPRegistry(self.root).list_servers())
        registry = MCPRegistry(self.root, {
            "escape": {"command": sys.executable, "args": [], "cwd": ".."},
        })
        with self.assertRaisesRegex(ValueError, "inside the selected project"):
            registry.list_tools("escape")

    def test_disabled_and_invalid_ids_are_rejected(self):
        registry = MCPRegistry(self.root, {"future": {"enabled": False}})
        with self.assertRaisesRegex(ValueError, "disabled"):
            registry.list_tools("future")
        with self.assertRaisesRegex(ValueError, "Invalid MCP server id"):
            MCPRegistry(self.root, {"bad/id": {}})


if __name__ == "__main__":
    unittest.main()
