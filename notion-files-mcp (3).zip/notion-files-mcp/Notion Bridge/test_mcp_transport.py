import tempfile
import logging
import unittest
from pathlib import Path

from starlette.testclient import TestClient

from server import HTTPStatusDiagnostics, build_app


class MCPTransportTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        (Path(self.temp.name) / "hello.txt").write_text("MCP works", encoding="utf-8")
        self.client_context = TestClient(
            build_app({"root_directory": self.temp.name, "bearer_token": "test-secret"})
        )
        self.client = self.client_context.__enter__()

    def tearDown(self):
        self.client_context.__exit__(None, None, None)
        self.temp.cleanup()

    def rpc(self, request_id, method, params=None):
        response = self.client.post(
            "/mcp",
            json={"jsonrpc": "2.0", "id": request_id, "method": method, "params": params or {}},
            headers={
                "Authorization": "Bearer test-secret",
                "Accept": "application/json, text/event-stream",
                "MCP-Protocol-Version": "2025-03-26",
            },
        )
        self.assertEqual(response.status_code, 200, response.text)
        self.assertIn("application/json",response.headers.get("content-type",""))
        return response.text

    def test_status_diagnostics_only_reports_429_and_server_errors(self):
        async def app(scope, receive, send):
            await send({"type":"http.response.start","status":429,"headers":[]})
            await send({"type":"http.response.body","body":b"rate limited"})

        diagnostics = HTTPStatusDiagnostics(app)
        messages = []

        async def collect(message):
            messages.append(message)

        async def run():
            await diagnostics({"type":"http","path":"/mcp","method":"POST"},None,collect)

        import asyncio
        from contextlib import redirect_stdout
        from io import StringIO

        output = StringIO()
        with redirect_stdout(output):
            asyncio.run(run())
            asyncio.run(run())
        self.assertEqual(output.getvalue(),"Bridge returned HTTP 429 for POST /mcp.\n")

    def test_authentication_and_file_tools(self):
        self.assertGreaterEqual(logging.getLogger("mcp.server.streamable_http").getEffectiveLevel(), logging.WARNING)
        self.assertEqual(self.client.post("/mcp", json={}).status_code, 401)
        listing = self.rpc(1, "tools/list")
        for name in (
            "list_files", "search_files", "read_file", "write_file", "download_github_file",
            "mcp_servers", "mcp_list_tools", "mcp_call", "use_powershell", "use_cmd",
            "roblox_studio", "roblox_native_tools", "roblox_native_call", "roblox_execute_luau",
            "roblox_workflow", "roblox_project_memory",
        ):
            self.assertIn(name, listing)
        self.assertNotIn('"name":"execute_luau"', listing)
        result = self.rpc(2, "tools/call", {"name": "read_file", "arguments": {"path": "hello.txt"}})
        self.assertIn("MCP works", result)


if __name__ == "__main__":
    unittest.main()
