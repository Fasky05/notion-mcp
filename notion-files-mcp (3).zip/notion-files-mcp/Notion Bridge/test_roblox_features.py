import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from mcp_router import MCPRegistry
from roblox_features import RobloxStudioTools, _path_segments, roblox_tool_actions


FAKE_ROBLOX_MCP = r'''import json, sys
log = sys.argv[1]
tools = [
 {"name":"list_roblox_studios","inputSchema":{"type":"object","properties":{}}},
 {"name":"get_studio_state","inputSchema":{"type":"object","required":["studio_id"],"properties":{"studio_id":{"type":"string"}}}},
 {"name":"execute_luau","inputSchema":{"type":"object","required":["studio_id","code","datamodel_type"],"properties":{"studio_id":{"type":"string"},"code":{"type":"string"},"datamodel_type":{"type":"string","enum":["Edit","Server","Client"]}}}},
 {"name":"multi_edit","inputSchema":{"type":"object","properties":{"changes":{"type":"array"}}}},
 {"name":"http_get","inputSchema":{"type":"object","properties":{}}},
 {"name":"store_image","inputSchema":{"type":"object","properties":{}}},
]
for line in sys.stdin:
    r=json.loads(line); method=r.get("method")
    if "id" not in r: continue
    if method=="initialize": result={"protocolVersion":"2024-11-05","capabilities":{},"serverInfo":{"name":"fake-roblox"}}
    elif method=="tools/list": result={"tools":tools}
    elif method=="tools/call":
        p=r["params"]; name=p["name"]; args=p.get("arguments",{})
        with open(log,"a",encoding="utf8") as f: f.write(json.dumps({"name":name,"args":args})+"\n")
        if name=="list_roblox_studios": result={"content":[{"type":"text","text":"[{\"studio_id\":\"studio-1\"}]"}],"structuredContent":{"studios":[{"studio_id":"studio-1"}]}}
        elif name=="get_studio_state": result={"content":[{"type":"text","text":"place open"}],"structuredContent":{"blob":"x"*1000}}
        else:
            payload=json.dumps({"ok":True,"result":{"snapshotId":"snap-test","path":"game.Workspace","restored":[]}})
            result={"content":[{"type":"text","text":"BWJSON<<"+payload+">>BWJSON"}]}
    else: result={}
    print(json.dumps({"jsonrpc":"2.0","id":r["id"],"result":result}),flush=True)
'''


class RobloxFeatureTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.script = self.root / "fake_roblox.py"
        self.log = self.root / "calls.jsonl"
        self.script.write_text(FAKE_ROBLOX_MCP, encoding="utf-8")
        self.registry = MCPRegistry(self.root, {
            "roblox": {"command": sys.executable, "args": ["-u", str(self.script), str(self.log)], "cwd": "."},
        })
        helper = Path(__file__).with_name("roblox_helpers.luau")
        self.studio = RobloxStudioTools(self.registry, self.root / "data", helper)

    def tearDown(self):
        self.registry.close()
        self.temp.cleanup()

    def calls(self):
        if not self.log.exists(): return []
        return [json.loads(line) for line in self.log.read_text(encoding="utf-8").splitlines()]

    def test_paths_are_resolved_as_segments_not_luau_source(self):
        self.assertEqual(_path_segments('Workspace["A.B"]'), ["game", "Workspace", "A.B"])
        output = json.loads(self.studio.run_action("get_game_tree", {"path": 'Workspace["A.B"]'}))
        self.assertEqual(output["path"], "game.Workspace")
        execute = next(call for call in self.calls() if call["name"] == "execute_luau")
        self.assertIn('"A.B"', execute["args"]["code"])
        self.assertNotIn("Workspace.A.B", execute["args"]["code"])
        self.assertEqual(execute["args"]["studio_id"], "studio-1")

    def test_writes_snapshot_first_and_return_snapshot_id(self):
        result = json.loads(self.studio.run_action("create_part", {"name":"Crate","position":[0,2,0]}))
        self.assertEqual(result["snapshotId"], "snap-test")
        execute_calls = [call for call in self.calls() if call["name"] == "execute_luau"]
        self.assertEqual(len(execute_calls), 2)
        self.assertIn("__BrickwireSnapshots", execute_calls[0]["args"]["code"])
        self.assertIn("Crate", execute_calls[0]["args"]["code"])

    def test_helper_library_and_datamodel_are_passed_to_studio(self):
        output = json.loads(self.studio.execute_luau("print(BW.version)", "Server", 12, True))
        self.assertTrue(output["helpers_loaded"])
        execute = [call for call in self.calls() if call["name"] == "execute_luau"][-1]
        self.assertIn("BW.version", execute["args"]["code"])
        self.assertIn("function BW.model", execute["args"]["code"])
        self.assertEqual(execute["args"]["datamodel_type"], "Server")

    def test_native_catalogue_excludes_web_and_local_image_tools(self):
        page = json.loads(self.studio.native_tools(limit=50))
        names = [tool["name"] for tool in page["tools"]]
        self.assertIn("execute_luau", names)
        self.assertNotIn("http_get", names)
        self.assertNotIn("store_image", names)
        self.assertEqual(set(roblox_tool_actions()), {"status", "project_info", "get_game_tree", "read_instance", "create_instance", "create_part", "create_instance_tree", "create_model", "create_ui", "create_vfx", "modify_instance", "delete_instance", "clone_instance", "create_script", "read_script", "set_script_source", "patch_script", "search_scripts", "delete_script", "take_snapshot", "list_snapshots", "restore_snapshot", "get_errors"})

    def test_execute_luau_is_blocked_from_generic_router_call(self):
        self.studio.native_tools(limit=50)
        with self.assertRaisesRegex(ValueError, "roblox_execute_luau"):
            self.registry.call_tool("roblox", "execute_luau", {"code":"print(1)"})
        with self.assertRaisesRegex(ValueError, "disabled by bridge policy"):
            self.registry.call_tool("roblox", "http_get", {})
        with self.assertRaisesRegex(ValueError, "roblox_studio or roblox_native_call"):
            self.registry.call_tool("roblox", "delete_script", {"path":"game.Workspace.Script"})

    def test_place_memory_persists_notes_and_scans(self):
        result = json.loads(self.studio.project_memory("note", "system", "Server-authoritative economy"))
        self.assertEqual(result["memory"]["systems"][0]["text"], "Server-authoritative economy")
        saved = json.loads((self.root / "data" / "roblox-project-memory.json").read_text(encoding="utf-8"))
        self.assertEqual(saved["Untitled_place"]["systems"][0]["text"], "Server-authoritative economy")

    def test_native_write_uses_snapshot_when_it_names_a_path(self):
        result = json.loads(self.studio.native_call("multi_edit", {"changes":[{"path":"game.Workspace.Script","old":"a","new":"b"}]}))
        self.assertEqual(result["snapshotId"], "snap-test")
        names = [call["name"] for call in self.calls()]
        self.assertEqual(names.count("execute_luau"), 1)
        self.assertEqual(names[-1], "multi_edit")

    def test_invalid_mutation_arguments_are_rejected_before_studio_calls(self):
        with self.assertRaisesRegex(ValueError, "50 instances"):
            self.studio.run_action("take_snapshot", {"paths":[f"game.Workspace.P{i}" for i in range(51)]})
        with self.assertRaisesRegex(ValueError, "properties and attributes"):
            self.studio.run_action("modify_instance", {"path":"game.Workspace.Part","properties":[]})
        with self.assertRaisesRegex(ValueError, "non-empty string"):
            self.studio.run_action("patch_script", {"path":"game.Workspace.Script","find":"","replace":"x"})
        with self.assertRaisesRegex(ValueError, "non-empty string"):
            self.studio.run_action("search_scripts", {"text":""})
        self.assertEqual(self.calls(), [])

    def test_native_structured_content_is_capped(self):
        with patch("roblox_features.MAX_RESULT", 200):
            result = json.loads(self.studio.native_call("get_studio_state", {}))
        structured = result["structuredContent"]
        self.assertTrue(structured["truncated"])
        self.assertLessEqual(len(structured["preview"]), 200)


if __name__ == "__main__":
    unittest.main()
