import io
import subprocess
import unittest
from contextlib import redirect_stdout
from unittest.mock import patch

import run_cloudflare
import run_tunnel


class FakeProcess:
    def __init__(self, lines, return_code=0):
        self.stdout = io.StringIO("".join(lines))
        self.return_code = return_code

    def wait(self):
        return self.return_code

    def poll(self):
        return self.return_code


class CloudflareTunnelTests(unittest.TestCase):
    @patch("run_cloudflare.credentials_file")
    @patch("run_cloudflare.find_cloudflared", return_value="cloudflared.exe")
    def test_starts_existing_named_tunnel(self, _find, credentials_file):
        credentials_file.return_value.is_file.return_value = True
        calls = []
        output = io.StringIO()

        def popen(command, **kwargs):
            calls.append(command)
            return FakeProcess(["Connected to Cloudflare edge\\n"])

        with redirect_stdout(output):
            self.assertEqual(run_cloudflare.main(popen=popen), 0)

        self.assertEqual(calls, [[
            "cloudflared.exe", "tunnel", "--no-autoupdate", "run", "--url",
            "http://127.0.0.1:8765", run_cloudflare.TUNNEL_ID,
        ]])
        self.assertIn("https://notion-mcp.fasky05.fr/mcp", output.getvalue())

    @patch("run_cloudflare.credentials_file")
    @patch("run_cloudflare.find_cloudflared", return_value="cloudflared.exe")
    def test_refuses_to_start_without_named_tunnel_credentials(self, _find, credentials_file):
        credentials_file.return_value.is_file.return_value = False
        popen = unittest.mock.Mock()
        output = io.StringIO()
        with redirect_stdout(output):
            self.assertEqual(run_cloudflare.main(popen=popen), 1)
        popen.assert_not_called()
        self.assertIn("credentials are missing", output.getvalue())


class TailscaleTunnelTests(unittest.TestCase):
    @patch("run_tunnel.run_cloudflare.main", return_value=0)
    @patch("run_tunnel.Path.read_text", return_value="cloudflare")
    @patch("run_tunnel.Path.is_file", return_value=True)
    def test_dispatches_to_cloudflare_when_provider_is_selected(self, _is_file, _read_text, cloudflare):
        self.assertEqual(run_tunnel.main(), 0)
        cloudflare.assert_called_once_with(popen=subprocess.Popen)

    @patch("run_tunnel.Path.read_text", return_value="unsupported")
    @patch("run_tunnel.Path.is_file", return_value=True)
    def test_refuses_unknown_tunnel_provider(self, _is_file, _read_text):
        output = io.StringIO()
        with redirect_stdout(output):
            self.assertEqual(run_tunnel.main(), 1)
        self.assertIn("Unknown tunnel provider", output.getvalue())

    @patch("run_tunnel.Path.is_file", return_value=False)
    @patch("run_tunnel.subprocess.run")
    @patch("run_tunnel.find_tailscale", return_value="tailscale.exe")
    def test_starts_funnel_and_prints_mcp_url(self, _is_file, run, _find):
        calls = []
        output = io.StringIO()
        run.return_value.returncode = 0

        def popen(command, **kwargs):
            calls.append(command)
            return FakeProcess(["Available on the internet:\n", "https://bridge.example-tailnet.ts.net\n"])

        with redirect_stdout(output):
            self.assertEqual(run_tunnel.main(popen=popen), 0)

        self.assertEqual(
            [call.args[0] for call in run.call_args_list],
            [
                ["tailscale.exe", "funnel", "reset"],
                ["tailscale.exe", "serve", "reset"],
            ],
        )
        self.assertEqual(calls, [["tailscale.exe", "funnel", "--bg", "--https=443", "127.0.0.1:8765"]])
        self.assertIn("https://bridge.example-tailnet.ts.net/mcp", output.getvalue())
        self.assertIn("HTTPS port 443", output.getvalue())
        self.assertIn("survives closing this window and PC restarts", output.getvalue())

    @patch("run_tunnel.Path.is_file", return_value=False)
    @patch("run_tunnel.find_tailscale", return_value=None)
    def test_explains_when_tailscale_is_missing(self, _is_file, _find):
        output = io.StringIO()
        with redirect_stdout(output):
            self.assertEqual(run_tunnel.main(), 1)
        self.assertIn("tailscale.com/download", output.getvalue())

    @patch("run_tunnel.Path.is_file", return_value=False)
    @patch("run_tunnel.subprocess.run")
    @patch("run_tunnel.find_tailscale", return_value="tailscale.exe")
    def test_reports_funnel_setup_failure(self, _is_file, _run, _find):
        output = io.StringIO()
        _run.return_value.returncode = 0
        with redirect_stdout(output):
            self.assertEqual(
                run_tunnel.main(lambda *_args, **_kwargs: FakeProcess(["Funnel is disabled\n"], 1)),
                1,
            )
        self.assertIn("Funnel is enabled", output.getvalue())

    @patch("run_tunnel.Path.is_file", return_value=False)
    @patch("run_tunnel.subprocess.run")
    @patch("run_tunnel.find_tailscale", return_value="tailscale.exe")
    def test_does_not_start_funnel_if_existing_config_cannot_be_reset(self, _is_file, run, _find):
        run.return_value.returncode = 1
        run.return_value.stderr = "reset denied"
        popen = unittest.mock.Mock()
        output = io.StringIO()
        with redirect_stdout(output):
            self.assertEqual(run_tunnel.main(popen=popen), 1)
        run.assert_called_once_with(
            ["tailscale.exe", "funnel", "reset"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
        )
        popen.assert_not_called()
        self.assertIn("Could not reset the existing Tailscale funnel configuration", output.getvalue())
        self.assertIn("reset denied", output.getvalue())


if __name__ == "__main__":
    unittest.main()
