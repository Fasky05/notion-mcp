@echo off
setlocal
title Notion + Roblox Bridge
set "APP_DIR=%~dp0Notion Bridge"
if not exist "%APP_DIR%\start_all.bat" (
  echo The Notion Bridge folder is missing. Extract the complete ZIP first.
  pause
  exit /b 1
)
call "%APP_DIR%\start_all.bat"
exit /b %errorlevel%
